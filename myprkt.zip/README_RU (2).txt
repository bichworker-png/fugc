GAMEZONE — SBP/QR Robokassa v3

Что добавлено:
- Пополнение через СБП / QR через Robokassa.
- QR-картинка отображается прямо в Mini App.
- Кнопка «ОТКРЫТЬ В БАНКЕ» ведёт на платёжную ссылку выбранной кассы.
- Robokassa: платёжная ссылка с методом SBP, ResultURL с проверкой подписи Паролем #2.
- Защита от повторного зачисления через credited=true и блокировку строки deposits.
- Сумма вводится в RUB, на игровой баланс зачисляется RUB / BANK_USDT_RATE в USDT.
- CryptoBot / X Rocket в меню сохранены как отдельные способы; их существующая логика не удаляется.

ВАЖНО:
1. Перед реальными платежами проверь, что выбранная касса одобряет ваш вид деятельности и условия использования сервиса.
2. Секреты не вставляй в код — только в .env.
3. Твой ngrok перезапускать не нужно. Для callback/webhook нужен публичный HTTPS URL.
4. Это интеграционный слой; доступность конкретных способов оплаты зависит от настроек и договора кассы.

Новые переменные .env:
ROBOKASSA_LOGIN=
ROBOKASSA_PASS1=
ROBOKASSA_PASS2=
ROBOKASSA_IS_TEST=1
BANK_USDT_RATE=100

ROBOKASSA:
- MerchantLogin = ROBOKASSA_LOGIN
- Пароль №1 = ROBOKASSA_PASS1
- Пароль №2 = ROBOKASSA_PASS2
- Для теста ROBOKASSA_IS_TEST=1
- ResultURL в технических настройках магазина:
  https://ТВОЙ-NGROK-АДРЕС/api/payment/robokassa/result
- Основная логика проверки оплаты — ResultURL. Скрипт отвечает OK{InvId} только после успешной проверки подписи и суммы.

QR:
- Для генерации картинки QR используется пакет qrcode.
- Установи: pip install "qrcode[pil]"

После установки:
1) Ctrl+C в окне Uvicorn.
2) pip install "qrcode[pil]"
3) Проверь .env.
4) Запусти:
   python -m uvicorn webapp:app --host 0.0.0.0 --port 8000

В Mini App:
Пополнение -> СБП / QR — Robokassa

Для Robokassa ссылка создаётся с предпочтительным методом SBP; QR-код строится в Mini App из платёжной ссылки.


=== НОВАЯ КАССА ПОПОЛНЕНИЯ ===

В этой версии пополнение разделено на:
1) СБП — ручной перевод по реквизитам + чек, подтверждение админом.
2) Банковская карта — ручной перевод по реквизитам + чек, подтверждение админом.
3) CryptoBot — Crypto Pay API, автоматическое зачисление по webhook.
4) X Rocket — Pay API Current, автоматическое зачисление по подписанному webhook.

Добавь в .env (без кавычек, если значение однострочное):
BANK_PAYMENT_NAME=Имя получателя
BANK_SBP_DETAILS=Телефон СБП / банк / получатель
BANK_CARD_DETAILS=Номер карты / банк / получатель
BANK_PAYMENT_NOTE=После перевода обязательно отправьте чек.
BANK_SBP_QR_URL=
BANK_USDT_RATE=100

CryptoBot:
CRYPTOBOT_API_TOKEN=
CRYPTOBOT_WEBHOOK_SECRET_PATH=

X Rocket Pay API Current:
XROCKET_API_TOKEN=
XROCKET_WEBHOOK_SECRET=
XROCKET_API_BASE=https://pay.api.xrocket.exchange
PUBLIC_BASE_URL=https://YOUR-NGROK-DOMAIN

Webhook URLs:
CryptoBot: https://YOUR-NGROK-DOMAIN/api/payment/cryptobot/webhook/YOUR_SECRET_PATH
X Rocket: https://YOUR-NGROK-DOMAIN/api/payment/xrocket/webhook

ВАЖНО: не вставляй API-токены в app.js или HTML. Храни их только в .env.


X Rocket Pay API Current: в приложении xRocket выберите API Version = Current. API Token и Webhook Secret хранятся только в .env. Если PUBLIC_BASE_URL не задан, xRocket использует webhook URL уровня приложения.
