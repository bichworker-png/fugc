import os, json, time, hmac, hashlib, secrets, asyncio, html, base64, math
from decimal import Decimal, ROUND_DOWN
from urllib.parse import parse_qsl
from dotenv import load_dotenv
from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form
from fastapi.responses import HTMLResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
CHANNEL_ID = os.getenv("CHANNEL_ID", "").strip()
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "7896929680"))
CLOUDPAYMENTS_PUBLIC_ID = os.getenv("CLOUDPAYMENTS_PUBLIC_ID", "").strip()
CLOUDPAYMENTS_API_SECRET = os.getenv("CLOUDPAYMENTS_API_SECRET", "").strip()
BANK_USDT_RATE = Decimal(os.getenv("BANK_USDT_RATE", "100")).quantize(Decimal("0.01"))
BANK_RATE_MARKDOWN_PCT = Decimal(os.getenv("BANK_RATE_MARKDOWN_PCT", "1.0")).quantize(Decimal("0.01"))
CLOUDPAYMENTS_SUCCESS_URL = os.getenv("CLOUDPAYMENTS_SUCCESS_URL", "").strip()
ROBOKASSA_LOGIN = os.getenv("ROBOKASSA_LOGIN", "").strip()
ROBOKASSA_PASS1 = os.getenv("ROBOKASSA_PASS1", "").strip()
ROBOKASSA_PASS2 = os.getenv("ROBOKASSA_PASS2", "").strip()
ROBOKASSA_IS_TEST = os.getenv("ROBOKASSA_IS_TEST", "0").strip()
PAYMENT_RETURN_URL = os.getenv("PAYMENT_RETURN_URL", "").strip()

# Manual bank/SBP deposits (no acquiring required in this module).
BANK_PAYMENT_NAME = os.getenv("BANK_PAYMENT_NAME", "").strip()
BANK_SBP_DETAILS = os.getenv("BANK_SBP_DETAILS", "").strip()
BANK_CARD_DETAILS = os.getenv("BANK_CARD_DETAILS", "").strip()
BANK_PAYMENT_NOTE = os.getenv("BANK_PAYMENT_NOTE", "После перевода обязательно отправьте чек.").strip()
BANK_SBP_QR_URL = os.getenv("BANK_SBP_QR_URL", "").strip()

# CryptoBot / Crypto Pay
CRYPTOBOT_API_TOKEN = os.getenv("CRYPTOBOT_API_TOKEN", "").strip()
CRYPTOBOT_WEBHOOK_SECRET_PATH = os.getenv("CRYPTOBOT_WEBHOOK_SECRET_PATH", "").strip()

# xRocket Pay API (Current, not Legacy)
XROCKET_API_TOKEN = os.getenv("XROCKET_API_TOKEN", "").strip()
XROCKET_WEBHOOK_SECRET = os.getenv("XROCKET_WEBHOOK_SECRET", "").strip()
XROCKET_API_BASE = os.getenv("XROCKET_API_BASE", "https://pay.api.xrocket.exchange").strip().rstrip("/")

PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "").strip().rstrip("/")
# Optional per-invoice callback. Leave empty to use the webhook configured in xRocket Pay app.
XROCKET_CALLBACK_URL = os.getenv("XROCKET_CALLBACK_URL", "").strip().rstrip("/")
PAYMENT_TEST_MODE = os.getenv("PAYMENT_TEST_MODE", "0").strip().lower() in {"1", "true", "yes", "on"}
# Referral program: 1.5% of game turnover on each of 3 levels by default.
REF_LEVEL_PCT = {
    1: Decimal(os.getenv("REF_LEVEL_1_PCT", "1.5")).quantize(Decimal("0.01")),
    2: Decimal(os.getenv("REF_LEVEL_2_PCT", "1.5")).quantize(Decimal("0.01")),
    3: Decimal(os.getenv("REF_LEVEL_3_PCT", "1.5")).quantize(Decimal("0.01")),
}
BOT_USERNAME = os.getenv("BOT_USERNAME", "").strip().lstrip("@")

ADMIN_RECEIPT_WAIT = {}
TG_OFFSET = 0
TG_POLL_TASK = None
CRYPTO_RECONCILE_TASK = None

app = FastAPI(title="GAMEZONE Mini App")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(BASE_DIR, "webapp")
STATIC_DIR = os.path.join(WEB_DIR, "static")
if os.path.isdir(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
engine = (create_async_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_recycle=1800,
    pool_timeout=30,
    pool_size=5,
    max_overflow=10,
) if DATABASE_URL else None)

async def ensure_mines_schema():
    if engine is None: return
    async with engine.begin() as conn:
        await conn.execute(text("""CREATE TABLE IF NOT EXISTS mines_rounds (
            id VARCHAR(64) PRIMARY KEY,user_id BIGINT NOT NULL,bet NUMERIC(18,2) NOT NULL,
            mines INTEGER NOT NULL,safe_count INTEGER NOT NULL DEFAULT 0,
            mine_positions JSONB NOT NULL,opened_cells JSONB NOT NULL DEFAULT '[]'::jsonb,
            status VARCHAR(16) NOT NULL DEFAULT 'active',payout NUMERIC(18,2) NOT NULL DEFAULT 0,
            game_round_id BIGINT,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),finished_at TIMESTAMPTZ)"""))
        await conn.execute(text("ALTER TABLE mines_rounds ADD COLUMN IF NOT EXISTS opened_cells JSONB NOT NULL DEFAULT '[]'::jsonb"))
        await conn.execute(text("CREATE INDEX IF NOT EXISTS idx_mines_user_status ON mines_rounds(user_id,status)"))

async def ensure_coinflip_schema():
    if engine is None: return
    async with engine.begin() as conn:
        await conn.execute(text("""CREATE TABLE IF NOT EXISTS coinflip_rounds (
            id VARCHAR(64) PRIMARY KEY, user_id BIGINT NOT NULL, bet NUMERIC(18,2) NOT NULL,
            chosen_side VARCHAR(8) NOT NULL, step INTEGER NOT NULL DEFAULT 0,
            multiplier NUMERIC(12,4) NOT NULL DEFAULT 1.00, status VARCHAR(16) NOT NULL DEFAULT 'active',
            payout NUMERIC(18,2) NOT NULL DEFAULT 0, history JSONB NOT NULL DEFAULT '[]'::jsonb,
            game_round_id BIGINT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), finished_at TIMESTAMPTZ)"""))
        await conn.execute(text("ALTER TABLE coinflip_rounds ADD COLUMN IF NOT EXISTS history JSONB NOT NULL DEFAULT '[]'::jsonb"))
        await conn.execute(text("CREATE INDEX IF NOT EXISTS idx_coinflip_user_status ON coinflip_rounds(user_id,status)"))


COINFLIP_MULTIPLIERS = [Decimal(x) for x in (
    "1.90", "3.61", "6.86", "13.03", "24.76", "47.04", "89.38", "169.82"
)]

def coinflip_mult(step):
    if step <= 0: return Decimal("1.00")
    return COINFLIP_MULTIPLIERS[min(step, len(COINFLIP_MULTIPLIERS))-1]


async def coinflip_cb(conn, uid, bet):
    total=(await conn.execute(text("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE user_id=:id AND credited=true"),{"id":uid})).scalar() or 0
    return q(bet*Decimal(str(vip_info(total)["cashback_pct"]))/100)

async def ensure_crash_schema():
    if engine is None: return
    async with engine.begin() as conn:
        await conn.execute(text("""CREATE TABLE IF NOT EXISTS crash_rounds (
            id VARCHAR(64) PRIMARY KEY, user_id BIGINT NOT NULL, bet NUMERIC(18,2) NOT NULL,
            crash_multiplier NUMERIC(12,2) NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'active',
            cashout_multiplier NUMERIC(12,2) NOT NULL DEFAULT 0, payout NUMERIC(18,2) NOT NULL DEFAULT 0,
            game_round_id BIGINT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), finished_at TIMESTAMPTZ)"""))
        await conn.execute(text("CREATE INDEX IF NOT EXISTS idx_crash_user_status ON crash_rounds(user_id,status)"))
        await conn.execute(text("CREATE INDEX IF NOT EXISTS idx_crash_finished ON crash_rounds(status,finished_at DESC)"))


async def ensure_finance_schema():
    if engine is None:
        return
    async with engine.begin() as conn:
        await conn.execute(text("ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS provider VARCHAR(32) DEFAULT 'manual'"))
        await conn.execute(text("ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS tx_id VARCHAR(255)"))
        await conn.execute(text("ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS receipt_file_id VARCHAR(255)"))
        await conn.execute(text("ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS admin_note TEXT"))
        await conn.execute(text("ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS processed_at TIMESTAMPTZ"))
        await conn.execute(text("ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS processed_by VARCHAR(255)"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS fiat_amount NUMERIC(20,8)"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS fiat_currency VARCHAR(8)"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS exchange_rate NUMERIC(20,8)"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS provider_tx_id VARCHAR(255)"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS provider_invoice_id VARCHAR(255)"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS payment_method VARCHAR(64)"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS receipt_file_id VARCHAR(255)"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS receipt_file_name VARCHAR(255)"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS admin_note TEXT"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS processed_at TIMESTAMPTZ"))
        await conn.execute(text("ALTER TABLE deposits ADD COLUMN IF NOT EXISTS processed_by VARCHAR(255)"))
        await conn.execute(text("ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_balance NUMERIC(20,8) DEFAULT 0"))
        await conn.execute(text("ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_total_earned NUMERIC(20,8) DEFAULT 0"))
        await conn.execute(text("""
            CREATE TABLE IF NOT EXISTS referrals (
                id BIGSERIAL PRIMARY KEY,
                user_id BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
                referrer_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                CONSTRAINT referrals_no_self CHECK (user_id <> referrer_id)
            )
        """))
        await conn.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id)
        """))
        await conn.execute(text("""
            CREATE TABLE IF NOT EXISTS referral_earnings (
                id BIGSERIAL PRIMARY KEY,
                game_round_id BIGINT NOT NULL,
                referrer_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                referred_user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                level SMALLINT NOT NULL CHECK(level BETWEEN 1 AND 3),
                turnover NUMERIC(20,8) NOT NULL,
                amount NUMERIC(20,8) NOT NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE(game_round_id, referrer_id, level)
            )
        """))
        await conn.execute(text("CREATE INDEX IF NOT EXISTS idx_ref_earn_referrer_date ON referral_earnings(referrer_id, created_at)"))

@app.on_event("startup")
async def startup():
    global TG_POLL_TASK, CRYPTO_RECONCILE_TASK
    print("START FINANCE")
    await ensure_finance_schema()
    print("FINANCE OK")
    await ensure_mines_schema()
    print("MINES OK")
    await ensure_coinflip_schema()
    print("COINFLIP OK")
    await ensure_crash_schema()
    print("CRASH OK")

if BOT_TOKEN:
    pass
    # CRYPTO_RECONCILE_TASK disabled: handled by bot.py

# Telegram channel publishing

async def telegram_api_call(method, payload=None, files=None):
    if not BOT_TOKEN:
        return False, "BOT_TOKEN not configured"
    try:
        import urllib.request, urllib.parse, json as _json
        url=f"https://api.telegram.org/bot{BOT_TOKEN}/{method}"
        if files:
            boundary="----GameZone"+secrets.token_hex(12)
            body=b""
            for k,v in (payload or {}).items():
                body += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n").encode()
            for k,(filename,ctype,data) in files.items():
                body += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"; filename=\"{filename}\"\r\nContent-Type: {ctype}\r\n\r\n").encode()+data+b"\r\n"
            body += f"--{boundary}--\r\n".encode()
            req=urllib.request.Request(url,data=body,headers={"Content-Type":f"multipart/form-data; boundary={boundary}"},method="POST")
        else:
            body=urllib.parse.urlencode(payload or {}).encode("utf-8")
            req=urllib.request.Request(url,data=body,method="POST")
        def _call():
            with urllib.request.urlopen(req,timeout=25) as resp:
                return _json.loads(resp.read().decode("utf-8"))
        data=await asyncio.to_thread(_call)
        if not data.get("ok"): return False, data.get("description","Telegram API error")
        return True, data.get("result")
    except Exception as e:
        return False, str(e)

WITHDRAW_PROVIDER_NAMES = {"cryptobot":"CryptoBot","xrocket":"X Rocket","bank_sber":"Сбер","bank_vtb":"ВТБ","bank_gazprombank":"Газпромбанк","bank_alfa":"Альфа-Банк","bank_psb":"ПСБ","bank_rshb":"Россельхозбанк","bank_mkb":"МКБ","bank_tbank":"Т-Банк","bank_sovcombank":"Совкомбанк","bank_domrf":"Банк ДОМ.РФ","manual":"Вручную"}

async def notify_admin_withdrawal(wid, tg, amount, provider, destination):
    username = "@"+tg["username"] if tg.get("username") else (tg.get("first_name") or "Игрок")
    text_msg = (
        "💸 <b>Новая заявка на вывод</b>\n\n"
        f"ID заявки: <code>#{wid}</code>\n"
        f"Игрок: <a href=\"tg://user?id={int(tg['id'])}\">{html.escape(username)}</a>\n"
        f"Сумма: <b>{amount:.2f} USDT</b>\n"
        f"Способ: <b>{html.escape(WITHDRAW_PROVIDER_NAMES.get(provider, provider))}</b>\n"
        f"Реквизиты: <code>{html.escape(destination)}</code>\n\n" +
        ("После реальной выплаты отправь чек CryptoBot."
         if provider in {"cryptobot","xrocket"} else
         "После реальной выплаты нажми «Подтвердить».")
    )
    keyboard=json.dumps({"inline_keyboard":[
        [{"text":"✅ Подтвердить вывод","callback_data":f"wd:approve:{wid}"}],
        [{"text":"❌ Отклонить","callback_data":f"wd:reject:{wid}"}]
    ]}, ensure_ascii=False)
    return await telegram_api_call("sendMessage", {
        "chat_id": str(ADMIN_ID), "text": text_msg, "parse_mode":"HTML",
        "reply_markup": keyboard, "disable_web_page_preview":"true"
    })

async def admin_poll_loop():
    global TG_OFFSET
    while True:
        try:
            ok, updates = await telegram_api_call("getUpdates", {
                "offset": str(TG_OFFSET), "timeout": "20", "allowed_updates": json.dumps(["message","callback_query"])
            })
            if not ok:
                await asyncio.sleep(3); continue
            for upd in updates or []:
                TG_OFFSET=max(TG_OFFSET, int(upd["update_id"])+1)
                await handle_admin_update(upd)
        except asyncio.CancelledError:
            break
        except Exception as e:
            print("[ADMIN POLL]", e)
            await asyncio.sleep(3)

async def notify_admin_deposit_receipt(deposit_id, tg, amount, rub, method, receipt_bytes, filename, mime):
    username = "@"+tg["username"] if tg.get("username") else (tg.get("first_name") or "Игрок")
    method_name = "СБП" if method == "sbp" else "Карта"
    caption = (
        "💰 <b>Новое пополнение — чек получен</b>\n\n"
        f"ID заявки: <code>#{deposit_id}</code>\n"
        f"Игрок: <a href=\"tg://user?id={int(tg['id'])}\">{html.escape(username)}</a>\n"
        f"Сумма: <b>{rub:.2f} ₽</b> → <b>{amount:.2f} USDT</b>\n"
        f"Способ: <b>{html.escape(method_name)}</b>\n\n"
        "Проверь поступление по банковскому приложению и подтверди только после фактического получения денег."
    )
    keyboard=json.dumps({"inline_keyboard":[
        [{"text":"✅ Зачислить","callback_data":f"dep:approve:{deposit_id}"}],
        [{"text":"❌ Отклонить","callback_data":f"dep:reject:{deposit_id}"}]
    ]}, ensure_ascii=False)
    return await telegram_api_call("sendDocument", {
        "chat_id": str(ADMIN_ID), "caption": caption, "parse_mode":"HTML", "reply_markup": keyboard
    }, files={"document": (filename or "receipt", mime or "application/octet-stream", receipt_bytes)})

async def notify_admin_deposit_created(deposit_id, tg, amount, rub, method):
    username = "@"+tg["username"] if tg.get("username") else (tg.get("first_name") or "Игрок")
    method_name = "СБП" if method == "sbp" else "Карта"
    text_msg=(
        "💰 <b>Новая заявка на пополнение</b>\n\n"
        f"ID заявки: <code>#{deposit_id}</code>\n"
        f"Игрок: <a href=\"tg://user?id={int(tg['id'])}\">{html.escape(username)}</a>\n"
        f"Сумма: <b>{rub:.2f} ₽</b> → <b>{amount:.2f} USDT</b>\n"
        f"Способ: <b>{html.escape(method_name)}</b>\n\n"
        "Ожидается чек от игрока."
    )
    return await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),"text":text_msg,"parse_mode":"HTML"})

async def credit_manual_deposit(deposit_id:int):
    if engine is None: return False
    async with engine.begin() as conn:
        row=(await conn.execute(text("""
            SELECT id,user_id,amount,status,credited FROM deposits WHERE id=:id FOR UPDATE
        """),{"id":deposit_id})).mappings().first()
        if not row or row["credited"] or row["status"] not in {"pending", "receipt_submitted"}:
            return False
        await conn.execute(text("""
            UPDATE deposits SET status='paid',credited=true,processed_at=NOW(),processed_by='admin'
            WHERE id=:id
        """),{"id":deposit_id})
        await conn.execute(text("UPDATE users SET balance=balance+:amount WHERE id=:uid"),{"amount":row["amount"],"uid":row["user_id"]})
        await conn.execute(text("""
            INSERT INTO transactions (user_id, amount, type, comment)
            VALUES (:uid,:amount,'deposit',:comment)
        """),{"uid":row["user_id"],"amount":row["amount"],"comment":f"Ручное пополнение #{deposit_id}"})
    return True

async def reject_manual_deposit(deposit_id:int):
    if engine is None: return False
    async with engine.begin() as conn:
        row=(await conn.execute(text("SELECT id,user_id,status,credited FROM deposits WHERE id=:id FOR UPDATE"),{"id":deposit_id})).mappings().first()
        if not row or row["status"] not in {"pending", "receipt_submitted"} or row["credited"]:
            return False
        await conn.execute(text("UPDATE deposits SET status='rejected',processed_at=NOW(),processed_by='admin' WHERE id=:id"),{"id":deposit_id})
    return True

async def handle_admin_update(upd):
    if upd.get("callback_query"):
        cq=upd["callback_query"]; msg=cq.get("message") or {}
        if int((cq.get("from") or {}).get("id",0)) != ADMIN_ID: return
        data=cq.get("data","")
        await telegram_api_call("answerCallbackQuery", {"callback_query_id":cq["id"]})
        if data.startswith("dep:approve:"):
            did=int(data.split(":")[-1])
            ok_dep=await credit_manual_deposit(did)
            if ok_dep and engine:
                async with engine.begin() as conn:
                    row=(await conn.execute(text("SELECT user_id,amount FROM deposits WHERE id=:id"),{"id":did})).mappings().first()
                if row:
                    await telegram_api_call("sendMessage", {"chat_id":str(row["user_id"]),"text":f"✅ Пополнение #{did} подтверждено. На баланс зачислено {dec(row['amount']):.2f} USDT."})
                await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),"text":f"✅ Пополнение #{did} подтверждено и зачислено."})
            else:
                await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),"text":f"ℹ️ Пополнение #{did} уже обработано или не найдено."})
            return
        if data.startswith("dep:reject:"):
            did=int(data.split(":")[-1])
            ok_dep=await reject_manual_deposit(did)
            if ok_dep and engine:
                async with engine.begin() as conn:
                    row=(await conn.execute(text("SELECT user_id FROM deposits WHERE id=:id"),{"id":did})).mappings().first()
                if row:
                    await telegram_api_call("sendMessage", {"chat_id":str(row["user_id"]),"text":f"❌ Пополнение #{did} отклонено администратором."})
                await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),"text":f"❌ Пополнение #{did} отклонено."})
            return
        if data.startswith("wd:approve:"):
            wid=int(data.split(":")[-1])
            if engine:
                async with engine.begin() as conn:
                    row=(await conn.execute(text("SELECT user_id,amount,provider,status FROM withdrawals WHERE id=:id FOR UPDATE"),{"id":wid})).mappings().first()
                    if row and row["status"]=="pending" and row["provider"] not in {"cryptobot","xrocket"}:
                        await conn.execute(text("UPDATE withdrawals SET status='paid',processed_at=NOW(),processed_by='admin' WHERE id=:id"),{"id":wid})
                        await telegram_api_call("sendMessage", {"chat_id":str(row["user_id"]),
                            "text":f"✅ Вывод #{wid} подтверждён. Подтверждение оплаты отправлено администратором."})
                        await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),
                            "text":f"✅ Заявка #{wid} подтверждена. Подтверждение оплаты отправлено клиенту."})
                        return
            ADMIN_RECEIPT_WAIT[ADMIN_ID]=wid
            await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),
                "text":f"📎 Заявка #{wid} выбрана.\nТеперь отправь сюда <b>чек CryptoBot</b> файлом или фото.",
                "parse_mode":"HTML"})
        elif data.startswith("wd:reject:"):
            wid=int(data.split(":")[-1])
            if engine:
                async with engine.begin() as conn:
                    row=(await conn.execute(text("SELECT user_id,amount,status FROM withdrawals WHERE id=:id FOR UPDATE"),{"id":wid})).mappings().first()
                    if row and row["status"]=="pending":
                        await conn.execute(text("UPDATE withdrawals SET status='rejected',processed_at=NOW(),processed_by='admin' WHERE id=:id"),{"id":wid})
                        await conn.execute(text("UPDATE users SET balance=balance+:amount WHERE id=:uid"),{"amount":row["amount"],"uid":row["user_id"]})
                        await telegram_api_call("sendMessage", {"chat_id":str(row["user_id"]),
                            "text":f"❌ Вывод #{wid} отклонён. Сумма {dec(row['amount']):.2f} USDT возвращена на баланс."})
                        await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),"text":f"❌ Вывод #{wid} отклонён, сумма возвращена клиенту."})
        return
    msg=upd.get("message") or {}
    from_user=msg.get("from") or {}
    from_id=int(from_user.get("id",0))
    msg_text=(msg.get("text") or "").strip()
    # Public /start referral binding. A referral is fixed on first successful bind.
    if from_id and msg_text.startswith("/start"):
        parts=msg_text.split(maxsplit=1)
        payload=parts[1].strip() if len(parts)>1 else ""
        if payload.startswith("ref_"):
            try:
                rid=int(payload[4:])
                # Ensure the referred user exists before binding.
                if engine is not None:
                    async with engine.begin() as conn:
                        await ensure_user(conn, from_user)
                bound=await bind_referral(rid,from_id)
                if bound:
                    await telegram_api_call("sendMessage", {"chat_id":str(from_id),"text":"🎫 <b>Реферальная система активирована.</b>\n\nВы зарегистрированы по приглашению. Откройте GameZone, чтобы посмотреть статистику.","parse_mode":"HTML"})
                else:
                    await telegram_api_call("sendMessage", {"chat_id":str(from_id),"text":"🎫 <b>Реферальная ссылка обработана.</b>\n\nЕсли вы уже были привязаны к другому пригласившему, изменить его нельзя.","parse_mode":"HTML"})
            except Exception as e:
                print("[REFERRAL START]",e)
        # Keep normal /start available even without a referral.
        if from_id != ADMIN_ID:
            return
    if from_id != ADMIN_ID: return
    wid=ADMIN_RECEIPT_WAIT.get(ADMIN_ID)
    if not wid: return
    doc=msg.get("document")
    photo=(msg.get("photo") or [])
    file_id=None; file_name="receipt"; mime="application/octet-stream"
    if doc:
        file_id=doc.get("file_id"); file_name=doc.get("file_name") or "receipt"; mime=doc.get("mime_type") or mime
    elif photo:
        file_id=photo[-1].get("file_id"); file_name="cryptobot_receipt.jpg"; mime="image/jpeg"
    if not file_id:
        await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),"text":"Пришли чек CryptoBot именно файлом или фото."})
        return
    ok, info=await telegram_api_call("getFile", {"file_id":file_id})
    if not ok:
        await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),"text":"Не удалось получить файл чека."}); return
    path=info.get("file_path")
    try:
        import urllib.request
        def dl():
            with urllib.request.urlopen(f"https://api.telegram.org/file/bot{BOT_TOKEN}/{path}",timeout=25) as r: return r.read()
        content=await asyncio.to_thread(dl)
    except Exception as e:
        await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),"text":f"Ошибка загрузки чека: {e}"}); return
    if len(content)>8*1024*1024:
        await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),"text":"Чек больше 8 МБ."}); return
    if engine is None: return
    async with engine.begin() as conn:
        row=(await conn.execute(text("SELECT user_id,amount,status,provider FROM withdrawals WHERE id=:id FOR UPDATE"),{"id":wid})).mappings().first()
        if not row or row["status"]!="pending":
            await telegram_api_call("sendMessage", {"chat_id":str(ADMIN_ID),"text":"Р—аявка уже обработана или не найдена."}); ADMIN_RECEIPT_WAIT.pop(ADMIN_ID,None); return
        await conn.execute(text("UPDATE withdrawals SET status='paid',admin_note='CryptoBot receipt',processed_at=NOW(),processed_by='admin',receipt_file_id=:fid WHERE id=:id"),{"fid":file_id,"id":wid})
    caption=f"✅ <b>Вывод #{wid} подтверждён</b>\nСумма: <b>{dec(row['amount']):.2f} USDT</b>\nСпособ: CryptoBot"
    ok1,_=await telegram_api_call("sendMessage",{"chat_id":str(row["user_id"]),"text":caption,"parse_mode":"HTML"})
    ok2,_=await telegram_api_call("sendDocument",{"chat_id":str(row["user_id"]),"caption":"🧾 Чек CryptoBot","parse_mode":"HTML"},files={"document":(file_name,mime,content)})
    ADMIN_RECEIPT_WAIT.pop(ADMIN_ID,None)
    await telegram_api_call("sendMessage",{"chat_id":str(ADMIN_ID),"text":f"✅ Заявка #{wid} подтверждена. Чек отправлен клиенту." if ok2 else f"⚠️ Заявка #{wid} отмечена выплаченной, но чек клиенту отправить не удалось."})

CHANNEL_EMOJI = {
    "dice": "🎲",
    "bowling": "🎳",
    "darts": "🎯",
    "football": "⚽",
    "basketball": "🏀",
}
CHANNEL_GAME_NAMES = {
    "dice": "Кубик",
    "bowling": "Боулинг",
    "darts": "Дартс",
    "football": "Футбол",
    "basketball": "Баскетбол",
}

async def telegram_channel_call(method, payload):
    if not BOT_TOKEN or not CHANNEL_ID:
        return False, "CHANNEL_ID/BOT_TOKEN not configured"
    try:
        import urllib.request, urllib.parse, json as _json
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/{method}"
        body = urllib.parse.urlencode(payload).encode("utf-8")
        def _call():
            req = urllib.request.Request(url, data=body, method="POST")
            with urllib.request.urlopen(req, timeout=15) as resp:
                return _json.loads(resp.read().decode("utf-8"))
        data = await asyncio.to_thread(_call)
        if not data.get("ok"):
            return False, str(data.get("description") or "Telegram API error")
        return True, data.get("result")
    except Exception as e:
        return False, str(e)

CHANNEL_EMOJI = {
    "dice": "🎲", "bowling": "🎳", "darts": "🎯", "football": "⚽", "basketball": "🏀"
}
CHANNEL_GAME_NAMES = {
    "dice": "Кубик", "bowling": "Боулинг", "darts": "Дартс", "football": "Футбол", "basketball": "Баскетбол"
}

MULTIPLIERS = {
    "dice": {"higher": Decimal("1.80"), "lower": Decimal("1.80"), "even": Decimal("1.80"), "odd": Decimal("1.80"), "exact": Decimal("5.40")},
    "bowling": {"strike": Decimal("2.00"), "miss": Decimal("2.00"), "pins": Decimal("3.00")},
    "darts": {"bullseye": Decimal("3.00"), "hit": Decimal("1.80"), "miss": Decimal("2.50")},
    "football": {"goal": Decimal("2.00"), "miss": Decimal("2.50"), "corner": Decimal("3.00"), "post": Decimal("4.00")},
    "basketball": {"clean": Decimal("2.00"), "stuck": Decimal("2.50"), "miss": Decimal("1.80")},
}

def possible_multiplier(game, choice):
    if game == "dice" and choice.startswith("exact:"):
        return MULTIPLIERS[game]["exact"]
    if game == "bowling" and choice.startswith("pins:"):
        return MULTIPLIERS[game]["pins"]
    return MULTIPLIERS.get(game, {}).get(choice, Decimal("1.00"))

def choice_label(game, choice):
    labels={
        "higher":"выпадет больше 3", "lower":"выпадет меньше 4", "even":"выпадет чётное", "odd":"выпадет нечётное",
        "strike":"страйк", "miss":"мимо", "bullseye":"яблочко", "hit":"любое место",
        "goal":"в ворота", "corner":"в угол", "post":"от штанги", "clean":"чистый", "stuck":"застрянет"
    }
    if choice.startswith("exact:"): return f"выпадет число {choice.split(':',1)[1]}"
    if choice.startswith("pins:"): return f"сбито {choice.split(':',1)[1]} кеглей"
    return labels.get(choice, choice)

def resolve_outcome(game, roll):
    if game == "dice":
        return {"higher": roll >= 4, "lower": roll <= 3, "even": roll % 2 == 0, "odd": roll % 2 == 1}, f"выпало число {roll}"
    if game == "bowling":
        actual = "miss" if roll == 1 else ("strike" if roll == 6 else f"pins:{roll}")
        text = "мимо" if actual == "miss" else ("страйк" if actual == "strike" else f"сбито {roll} кеглей")
        return actual, text
    if game == "darts":
        actual = "bullseye" if roll == 6 else ("miss" if roll == 1 else "hit")
        return actual, {"bullseye":"яблочко","hit":"любое место","miss":"мимо"}[actual]
    if game == "football":
        actual = {1:"miss",2:"miss",3:"corner",4:"post",5:"goal"}[roll]
        return actual, {"goal":"в ворота","miss":"мимо ворот","corner":"в угол","post":"от штанги"}[actual]
    actual = {1:"miss",2:"miss",3:"stuck",4:"clean",5:"miss"}[roll]
    return actual, {"clean":"чистый","stuck":"застрянет","miss":"промах"}[actual]

def evaluate_bet(game, choice, roll):
    if game == "dice":
        if choice.startswith("exact:"):
            n=int(choice.split(":",1)[1]); return roll == n, choice_label(game, choice)
        rules,_ = resolve_outcome(game, roll); return bool(rules.get(choice)), choice_label(game, choice)
    actual, outcome = resolve_outcome(game, roll)
    return actual == choice, choice_label(game, choice)

async def publish_bet_and_roll(tg, game, choice, bet):
    game_name=CHANNEL_GAME_NAMES[game]
    profile=f'<a href="tg://user?id={int(tg["id"])}">{html.escape("@"+tg["username"] if tg.get("username") else tg.get("first_name") or "Игрок")}</a>'
    mult=possible_multiplier(game, choice)
    possible=q(bet*mult)
    text1=(f"Игрок: {profile}\n"
           f"сделал ставку: {bet:.2f} USDT | {html.escape(game_name)} ({html.escape(choice_label(game, choice))})\n"
           f"ожидаемый выигрыш: {possible:.2f} USDT")
    ok, info=await telegram_channel_call("sendMessage", {"chat_id":CHANNEL_ID,"text":text1,"parse_mode":"HTML","disable_web_page_preview":"true"})
    if not ok: return None, info
    ok, info=await telegram_channel_call("sendDice", {"chat_id":CHANNEL_ID,"emoji":CHANNEL_EMOJI[game]})
    if not ok: return None, info
    dice=info.get("dice") if isinstance(info,dict) else None
    if not dice or "value" not in dice: return None, "Telegram did not return dice.value"
    roll=int(dice["value"])
    # Give Telegram clients time to play the native dice animation before the result message appears.
    await asyncio.sleep(1.4 if game in {"football","basketball"} else 1.6)
    return roll, None

async def publish_result_to_channel(game, choice, bet, payout, won, outcome):
    result="ПОБЕДА, ВЕЗУНЧИК" if won else "ПОРАЖЕНИЕ, попробуйте снова"
    text2=(f"{result}\n\nРсход который получился: {html.escape(outcome)}\n"
           f"Ставка: {html.escape(choice_label(game, choice))}\n"
           f"Ставка: {bet:.2f} USDT\nВыигрыш: {payout:.2f} USDT")
    ok, info=await telegram_channel_call("sendMessage", {"chat_id":CHANNEL_ID,"text":text2,"parse_mode":"HTML"})
    return ok, info

def validate_init_data(init_data: str) -> dict:
    if not init_data: raise ValueError("Telegram initData is empty")
    if not BOT_TOKEN: raise ValueError("BOT_TOKEN is empty on server")
    pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    received = pairs.pop("hash", None)
    if not received: raise ValueError("hash is missing")
    auth_date = pairs.get("auth_date")
    if not auth_date: raise ValueError("auth_date is missing")
    try:
        if abs(time.time() - int(auth_date)) > 86400: raise ValueError("initData is expired")
    except (TypeError, ValueError): raise ValueError("bad auth_date")
    check = "\n".join(f"{k}={pairs[k]}" for k in sorted(pairs))
    secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    calc = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc, received): raise ValueError("hash mismatch")
    raw = pairs.get("user")
    if not raw: raise ValueError("user is missing")
    user = json.loads(raw)
    if not user.get("id"): raise ValueError("Telegram user id is missing")
    return user

async def telegram_user(request: Request):
    init_data = request.headers.get("X-Telegram-Init-Data") or request.headers.get("X-Telegram-InitData") or request.headers.get("Telegram-Init-Data")
    try: return validate_init_data(init_data or "")
    except Exception as e:
        print("[AUTH]", e)
        raise HTTPException(401, "Telegram authorization failed")

def dec(value): return Decimal(str(value or 0))
def q(value): return value.quantize(Decimal("0.01"), rounding=ROUND_DOWN)

async def ensure_user(conn, tg):
    uid = int(tg["id"])
    row = (await conn.execute(text("SELECT id, username, first_name, balance, is_blocked FROM users WHERE id=:id FOR UPDATE"), {"id": uid})).mappings().first()
    if row is None:
        row = (await conn.execute(text("""
            INSERT INTO users (id, username, first_name, balance, is_blocked)
            VALUES (:id, :username, :first_name, 0, false)
            RETURNING id, username, first_name, balance, is_blocked
        """), {"id": uid, "username": tg.get("username"), "first_name": tg.get("first_name") or "Игрок"})).mappings().first()
    else:
        await conn.execute(text("UPDATE users SET username=:username, first_name=:first_name WHERE id=:id"),
                           {"id": uid, "username": tg.get("username"), "first_name": tg.get("first_name") or row["first_name"] or "Игрок"})
        row = (await conn.execute(text("SELECT id, username, first_name, balance, is_blocked FROM users WHERE id=:id"), {"id": uid})).mappings().first()
    if row["is_blocked"]: raise HTTPException(403, "Ваш аккаунт заблокирован")
    return row

@app.get("/")
async def index():
    path = os.path.join(WEB_DIR, "index.html")
    if not os.path.exists(path): return HTMLResponse("index.html not found", status_code=500)
    html = open(path, encoding="utf-8").read()
    # Cache-bust the game frontend so new game cards/functions appear immediately in Telegram Mini App.
    html = html.replace('/static/app.js', '/static/app.js?v=rocket-v2')
    html = html.replace('static/app.js', 'static/app.js?v=rocket-v2')
    return HTMLResponse(html)

@app.get("/health")
async def health(): return {"ok": True}

VIP_TIERS = [
    (Decimal("100000"), "💎 Алмаз", Decimal("4.0")),
    (Decimal("10000"), "💠 Платина", Decimal("3.5")),
    (Decimal("1000"), "🥇 Золото", Decimal("3.0")),
    (Decimal("100"), "🥈 Серебро", Decimal("2.5")),
    (Decimal("10"), "🥉 Бронза", Decimal("2.0")),
    (Decimal("0"), "👀 Зритель", Decimal("1.0")),
]

@app.get("/api/vip/tiers")
async def vip_tiers():
    return {"ok": True, "tiers": [
        {"name": name, "threshold": float(threshold), "cashback_pct": float(cashback)}
        for threshold, name, cashback in reversed(VIP_TIERS)
    ]}

def vip_info(total_deposits):
    total = dec(total_deposits or 0)
    for threshold, name, cashback in VIP_TIERS:
        if total >= threshold:
            next_threshold = None
            for t, _, _ in reversed(VIP_TIERS):
                if t > threshold:
                    next_threshold = t
                    break
            return {
                "name": name,
                "cashback_pct": float(cashback),
                "total_deposits": float(total),
                "threshold": float(threshold),
                "next_threshold": float(next_threshold) if next_threshold is not None else None,
            }
    return {"name":"👀 Зритель","cashback_pct":1.0,"total_deposits":float(total),"threshold":0.0,"next_threshold":10.0}

async def bind_referral(referrer_id: int, user_id: int):
    """Bind a player to a direct referrer once. Existing binding is never replaced."""
    if engine is None or referrer_id == user_id:
        return False
    async with engine.begin() as conn:
        await conn.execute(text("SELECT id FROM users WHERE id=:id FOR UPDATE"), {"id": user_id})
        await conn.execute(text("SELECT id FROM users WHERE id=:id"), {"id": referrer_id})
        exists = (await conn.execute(text("SELECT 1 FROM referrals WHERE user_id=:uid"), {"uid": user_id})).scalar()
        if exists:
            return False
        # Prevent circular referral chains.
        cycle = (await conn.execute(text("""
            WITH RECURSIVE chain(id, depth) AS (
                SELECT referrer_id, 1 FROM referrals WHERE user_id=:rid
                UNION ALL
                SELECT r.referrer_id, c.depth+1 FROM referrals r JOIN chain c ON r.user_id=c.id WHERE c.depth < 10
            ) SELECT 1 FROM chain WHERE id=:uid LIMIT 1
        """), {"rid": referrer_id, "uid": user_id})).scalar()
        if cycle:
            return False
        await conn.execute(text("INSERT INTO referrals (user_id, referrer_id) VALUES (:uid,:rid) ON CONFLICT DO NOTHING"), {"uid": user_id, "rid": referrer_id})
    return True

async def get_bot_username():
    global BOT_USERNAME
    if BOT_USERNAME:
        return BOT_USERNAME
    ok, result = await telegram_api_call("getMe")
    if ok and isinstance(result, dict):
        BOT_USERNAME = (result.get("username") or "").strip().lstrip("@")
    return BOT_USERNAME

async def referral_summary(conn, user_id: int, period: str = "all"):
    where = ""
    if period == "today": where = "AND created_at >= CURRENT_DATE"
    elif period == "month": where = "AND created_at >= date_trunc('month', NOW())"
    stats = (await conn.execute(text(f"""
        SELECT level, COUNT(DISTINCT referred_user_id) AS refs, COALESCE(SUM(amount),0) AS earned,
               COALESCE(SUM(turnover),0) AS turnover
        FROM referral_earnings
        WHERE referrer_id=:uid {where}
        GROUP BY level ORDER BY level
    """), {"uid": user_id})).mappings().all()
    by = {int(r["level"]): r for r in stats}
    direct = (await conn.execute(text("SELECT COUNT(*) FROM referrals WHERE referrer_id=:uid"), {"uid": user_id})).scalar() or 0
    total_refs = sum(int(by.get(i, {}).get("refs", 0) or 0) for i in (1,2,3))
    total_earned = sum(dec(by.get(i, {}).get("earned", 0)) for i in (1,2,3))
    total_turnover = sum(dec(by.get(i, {}).get("turnover", 0)) for i in (1,2,3))
    levels=[]
    for i in (1,2,3):
        r=by.get(i)
        levels.append({"level":i,"refs":int(r["refs"]) if r else 0,"earned":float(dec(r["earned"])) if r else 0.0,"turnover":float(dec(r["turnover"])) if r else 0.0,"pct":float(REF_LEVEL_PCT[i])})
    return {"refs": total_refs, "direct_refs": int(direct), "earned": float(total_earned), "turnover": float(total_turnover), "levels": levels, "period": period}

@app.post("/api/referral/bind")
async def referral_bind(request: Request):
    tg = await telegram_user(request)
    data = await request.json()
    try: referrer_id = int(data.get("referrer_id"))
    except Exception: raise HTTPException(400, "Некорректный реферер")
    ok = await bind_referral(referrer_id, int(tg["id"]))
    return {"ok": True, "bound": ok}

@app.get("/api/referral")
async def referral_api(request: Request, period: str = "all"):
    tg = await telegram_user(request)
    if period not in {"today","month","all"}: period="all"
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg)
        summary=await referral_summary(conn,int(u["id"]),period)
        bal=dec((await conn.execute(text("SELECT referral_balance FROM users WHERE id=:id"),{"id":u["id"]})).scalar() or 0)
        # Rank is based on total turnover generated by the referral network.
        thresholds=[(Decimal("100000"),"💎 Алмаз"),(Decimal("10000"),"💠 Платина"),(Decimal("1000"),"🥇 Золото"),(Decimal("100"),"🥈 Серебро"),(Decimal("10"),"🥉 Бронза"),(Decimal("0"),"👀 Зритель")]
        rank=next((n for t,n in thresholds if summary["turnover"]>=t),"👀 Зритель")
        next_t=next((t for t,_ in reversed(thresholds) if t>Decimal(str(summary["turnover"]))),None)
    username=await get_bot_username()
    link=f"https://t.me/{username}?start=ref_{u['id']}" if username else f"ref_{u['id']}"
    return {"ok":True,"balance":float(bal),"income_pct":float(REF_LEVEL_PCT[1]),"rank":rank,"rank_turnover":summary["turnover"],"next_threshold":float(next_t) if next_t is not None else None,"invite_link":link,**summary}

@app.post("/api/referral/withdraw")
async def referral_withdraw(request: Request):
    tg=await telegram_user(request)
    data=await request.json()
    amount=q(data.get("amount") or 0)
    if amount<=0: raise HTTPException(400,"Введите сумму")
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg)
        row=(await conn.execute(text("SELECT referral_balance FROM users WHERE id=:id FOR UPDATE"),{"id":u["id"]})).scalar() or 0
        bal=dec(row)
        if amount>bal: raise HTTPException(400,"Недостаточно реферального баланса")
        await conn.execute(text("UPDATE users SET referral_balance=referral_balance-:amount, balance=balance+:amount WHERE id=:id"),{"amount":amount,"id":u["id"]})
        await conn.execute(text("INSERT INTO transactions (user_id,amount,type,comment) VALUES (:uid,:amount,'referral_withdraw',:comment)"),{"uid":u["id"],"amount":amount,"comment":"Вывод с реферального баланса на игровой"})
    return {"ok":True,"amount":float(amount),"message":f"На игровой баланс зачислено {amount:.2f} USDT."}

@app.get("/api/me")
async def me(request: Request):
    tg = await telegram_user(request)
    if engine is None: raise HTTPException(500, "DATABASE_URL is empty")
    async with engine.begin() as conn:
        u = await ensure_user(conn, tg)
        stats = (await conn.execute(text("""
            SELECT COUNT(*) AS games_count, COALESCE(SUM(bet),0) AS turnover,
                   COALESCE(SUM(CASE WHEN payout > 0 THEN 1 ELSE 0 END),0) AS wins_count
            FROM game_rounds WHERE user_id=:id
        """), {"id": u["id"]})).mappings().first()
        total_deposits = (await conn.execute(text("""
            SELECT COALESCE(SUM(amount),0) FROM deposits
            WHERE user_id=:id AND credited=true
        """), {"id": u["id"]})).scalar() or 0
        last = (await conn.execute(text("SELECT game FROM game_rounds WHERE user_id=:id ORDER BY created_at DESC LIMIT 1"), {"id": u["id"]})).scalar()
        ref_balance = dec((await conn.execute(text("SELECT referral_balance FROM users WHERE id=:id"), {"id":u["id"]})).scalar() or 0)
    vip = vip_info(total_deposits)
    return {"ok": True, "user": {"id": u["id"], "username": u["username"], "first_name": u["first_name"],
        "balance": float(u["balance"]), "referral_balance": float(ref_balance), "games_count": int(stats["games_count"]), "wins_count": int(stats["wins_count"]),
        "turnover": float(stats["turnover"]), "last_game": last or "—", "vip": vip}}

class GameRequest(BaseModel):
    game: str
    bet: Decimal | None = None
    amount: Decimal | None = None
    choice: str | None = None

# Temporary test multipliers. Final coefficients will be set separately.
DICE_MULTIPLIERS = {
    "higher": Decimal("1.80"),
    "lower": Decimal("1.80"),
    "even": Decimal("1.80"),
    "odd": Decimal("1.80"),
    "exact": Decimal("5.40"),
}

def dice_result(roll, choice):
    """Return (win, human-readable choice text) for the dice bet."""
    labels = {
        "higher": "выпадет больше 3",
        "lower": "выпадет меньше 4",
        "even": "выпадет чётное",
        "odd": "выпадет нечётное",
    }
    if choice == "higher":
        return roll >= 4, labels[choice]
    if choice == "lower":
        return roll <= 3, labels[choice]
    if choice == "even":
        return roll % 2 == 0, labels[choice]
    if choice == "odd":
        return roll % 2 == 1, labels[choice]
    if choice.startswith("exact:"):
        try:
            n = int(choice.split(":", 1)[1])
        except (TypeError, ValueError):
            return False, "неверный выбор"
        if n < 1 or n > 6:
            return False, "неверный выбор"
        return roll == n, f"выпадет число {n}"
    return False, "неверный выбор"

def normalize_dice_choice(choice):
    c=(choice or "higher").strip().lower()
    aliases={"greater":"higher","more":"higher","less":"lower","higher":"higher","lower":"lower","even":"even","odd":"odd"}
    if c in aliases: return aliases[c]
    if c.startswith("number:"): return "exact:"+c.split(":",1)[1]
    if c.startswith("exact:"): return c
    if c.isdigit() and 1 <= int(c) <= 6: return "exact:"+c
    return c

def bowling_result(roll, choice):
    # Temporary test model: 0 = miss, 1..9 = pins, 10 = strike.
    if choice == "strike":
        return roll == 10, "страйк"
    if choice == "miss":
        return roll == 0, "мимо"
    if choice.startswith("pins:"):
        try: n=int(choice.split(":",1)[1])
        except (TypeError,ValueError): return False, "неверный выбор"
        if n < 0 or n > 10: return False, "неверный выбор"
        return roll == n, f"{n} кеглей"
    return False, "неверный выбор"

def normalize_bowling_choice(choice):
    c=(choice or "strike").strip().lower()
    if c in {"strike","miss"}: return c
    if c.startswith("pins:"):
        try: n=int(c.split(":",1)[1])
        except (TypeError,ValueError): return c
        if 0 <= n <= 10: return f"pins:{n}"
    return c


class MinesStartRequest(BaseModel):
    bet: Decimal = Field(gt=0, le=Decimal("100000"))
    mines: int = Field(default=3, ge=1, le=24)
class MinesOpenRequest(BaseModel):
    round_id: str
    cell: int = Field(ge=0, le=24)
class MinesCashoutRequest(BaseModel):
    round_id: str

def mines_mult(mines,safe):
    p=Decimal("1")
    for i in range(safe): p*=Decimal(25-mines-i)/Decimal(25-i)
    return Decimal("1.00") if safe<1 else (Decimal(".97")/p).quantize(Decimal(".01"),rounding=ROUND_DOWN)

async def mines_cb(conn,uid,bet):
    total=(await conn.execute(text("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE user_id=:id AND credited=true"),{"id":uid})).scalar() or 0
    return q(bet*Decimal(str(vip_info(total)["cashback_pct"]))/100)

@app.post("/api/mines/start")
async def mines_start(data:MinesStartRequest,request:Request):
    tg=await telegram_user(request)
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg); uid=u["id"]; bet=q(data.bet)
        active=(await conn.execute(text("SELECT id FROM mines_rounds WHERE user_id=:u AND status='active' LIMIT 1"),{"u":uid})).scalar()
        if active: raise HTTPException(409,"У вас уже есть активная игра Mines")
        if dec(u["balance"])<bet: raise HTTPException(400,"Недостаточно средств")
        rid=secrets.token_urlsafe(18); mines=sorted(secrets.SystemRandom().sample(range(25),data.mines))
        gid=(await conn.execute(text("INSERT INTO game_rounds(user_id,game,bet,roll_value,payout) VALUES(:u,'mines',:b,0,0) RETURNING id"),{"u":uid,"b":bet})).scalar_one()
        bal=q(dec(u["balance"])-bet)
        await conn.execute(text("UPDATE users SET balance=:b WHERE id=:u"),{"b":bal,"u":uid})
        await conn.execute(text("INSERT INTO mines_rounds(id,user_id,bet,mines,mine_positions,game_round_id) VALUES(:id,:u,:b,:m,CAST(:p AS jsonb),:g)"),{"id":rid,"u":uid,"b":bet,"m":data.mines,"p":json.dumps(mines),"g":gid})
        await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:a,'game_bet','💣 Mines')"),{"u":uid,"a":-bet})
    return {"ok":True,"round_id":rid,"balance":float(bal),"mines":data.mines}

@app.post("/api/mines/open")
async def mines_open(data:MinesOpenRequest,request:Request):
    tg=await telegram_user(request)
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg); uid=u["id"]
        r=(await conn.execute(text("SELECT * FROM mines_rounds WHERE id=:r AND user_id=:u FOR UPDATE"),{"r":data.round_id,"u":uid})).mappings().first()
        if not r: raise HTTPException(404,"Ргра не найдена")
        if r["status"]!="active": raise HTTPException(400,"Ргра уже завершена")
        opened=set(r["opened_cells"] or [])
        if data.cell in opened: raise HTTPException(400,"Клетка уже открыта")
        mines=set(r["mine_positions"] or [])
        if data.cell in mines:
            cb=await mines_cb(conn,uid,dec(r["bet"]))
            await conn.execute(text("UPDATE mines_rounds SET status='lost',finished_at=NOW() WHERE id=:r"),{"r":data.round_id})
            await conn.execute(text("UPDATE game_rounds SET roll_value=:v WHERE id=:g"),{"v":data.cell,"g":r["game_round_id"]})
            if cb:
                await conn.execute(text("UPDATE users SET balance=balance+:a WHERE id=:u"),{"a":cb,"u":uid})
                await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:a,'cashback','💣 Mines — кэшбэк')"),{"u":uid,"a":cb})
            bal=(await conn.execute(text("SELECT balance FROM users WHERE id=:u"),{"u":uid})).scalar()
            return {"status":"lost","mine_cells":sorted(mines),"cashback":float(cb),"balance":float(bal)}
        opened.add(data.cell); safe=len(opened); mult=mines_mult(int(r["mines"]),safe)
        await conn.execute(text("UPDATE mines_rounds SET safe_count=:s,opened_cells=CAST(:o AS jsonb) WHERE id=:r"),{"s":safe,"o":json.dumps(sorted(opened)),"r":data.round_id})
        if safe>=25-int(r["mines"]):
            payout=q(dec(r["bet"])*mult)
            await conn.execute(text("UPDATE mines_rounds SET status='won',payout=:p,finished_at=NOW() WHERE id=:r"),{"p":payout,"r":data.round_id})
            await conn.execute(text("UPDATE game_rounds SET roll_value=:v,payout=:p WHERE id=:g"),{"v":safe,"p":payout,"g":r["game_round_id"]})
            await conn.execute(text("UPDATE users SET balance=balance+:p WHERE id=:u"),{"p":payout,"u":uid})
            await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:p,'game_win','💣 Mines')"),{"u":uid,"p":payout})
            return {"status":"won","cell":data.cell,"safe_count":safe,"multiplier":float(mult),"payout":float(payout),"mine_cells":sorted(mines),"balance":float(dec((await conn.execute(text("SELECT balance FROM users WHERE id=:u"),{"u":uid})).scalar()))}
        return {"status":"active","cell":data.cell,"safe_count":safe,"multiplier":float(mult),"potential_payout":float(q(dec(r["bet"])*mult))}

@app.post("/api/mines/cashout")
async def mines_cashout(data:MinesCashoutRequest,request:Request):
    tg=await telegram_user(request)
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg)
        r=(await conn.execute(text("SELECT * FROM mines_rounds WHERE id=:r AND user_id=:u FOR UPDATE"),{"r":data.round_id,"u":u["id"]})).mappings().first()
        if not r or r["status"]!="active": raise HTTPException(400,"Ргра уже завершена")
        safe=int(r["safe_count"])
        if safe<1: raise HTTPException(400,"Сначала откройте клетку")
        mult=mines_mult(int(r["mines"]),safe); payout=q(dec(r["bet"])*mult)
        await conn.execute(text("UPDATE mines_rounds SET status='cashout',payout=:p,finished_at=NOW() WHERE id=:r"),{"p":payout,"r":data.round_id})
        await conn.execute(text("UPDATE game_rounds SET roll_value=:v,payout=:p WHERE id=:g"),{"v":safe,"p":payout,"g":r["game_round_id"]})
        await conn.execute(text("UPDATE users SET balance=balance+:p WHERE id=:u"),{"p":payout,"u":u["id"]})
        await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:p,'game_win','💣 Mines — забрал')"),{"u":u["id"],"p":payout})
        bal=(await conn.execute(text("SELECT balance FROM users WHERE id=:u"),{"u":u["id"]})).scalar()
    return {"status":"cashout","safe_count":safe,"multiplier":float(mult),"payout":float(payout),"balance":float(bal)}

class CoinFlipStartRequest(BaseModel):
    bet: Decimal = Field(gt=0, le=Decimal("100000"))
    side: str

class CoinFlipRoundRequest(BaseModel):
    round_id: str
    side: str | None = None

@app.get("/api/coinflip/active")
async def coinflip_active(request: Request):
    tg=await telegram_user(request)
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg)
        r=(await conn.execute(text("SELECT * FROM coinflip_rounds WHERE user_id=:u AND status='active' ORDER BY created_at DESC LIMIT 1"),{"u":u["id"]})).mappings().first()
        if not r: return {"active":False,"balance":float(u["balance"])}
    return {"active":True,"round_id":r["id"],"bet":float(r["bet"]),"side":r["chosen_side"],"step":int(r["step"]),"multiplier":float(r["multiplier"]),"history":r["history"] or [],"balance":float(u["balance"])}

@app.post("/api/coinflip/start")
async def coinflip_start(data: CoinFlipStartRequest, request: Request):
    tg=await telegram_user(request); side=(data.side or "").strip().lower()
    if side not in {"hot","dice"}: raise HTTPException(400,"Выберите HOT или DICE")
    bet=q(data.bet)
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg); uid=u["id"]
        active=(await conn.execute(text("SELECT id FROM coinflip_rounds WHERE user_id=:u AND status='active' LIMIT 1"),{"u":uid})).scalar()
        if active: raise HTTPException(409,"У вас уже есть активная игра Coin Flip")
        if dec(u["balance"])<bet: raise HTTPException(400,"Недостаточно средств")
        rid=secrets.token_urlsafe(18)
        gid=(await conn.execute(text("INSERT INTO game_rounds(user_id,game,bet,roll_value,payout) VALUES(:u,'coinflip',:b,0,0) RETURNING id"),{"u":uid,"b":bet})).scalar_one()
        bal=q(dec(u["balance"])-bet)
        await conn.execute(text("UPDATE users SET balance=:b WHERE id=:u"),{"b":bal,"u":uid})
        await conn.execute(text("INSERT INTO coinflip_rounds(id,user_id,bet,chosen_side,game_round_id) VALUES(:id,:u,:b,:s,:g)"),{"id":rid,"u":uid,"b":bet,"s":side,"g":gid})
        await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:a,'game_bet','🪙 Coin Flip')"),{"u":uid,"a":-bet})
        # Referral income is earned once from the game's turnover.
        ancestors=(await conn.execute(text("""WITH RECURSIVE chain(referrer_id, level) AS (
            SELECT r.referrer_id, 1 FROM referrals r WHERE r.user_id=:uid
            UNION ALL SELECT r.referrer_id, c.level+1 FROM referrals r JOIN chain c ON r.user_id=c.referrer_id WHERE c.level < 3
        ) SELECT referrer_id, level FROM chain ORDER BY level"""),{"uid":uid})).mappings().all()
        for a in ancestors:
            level=int(a["level"]); commission=q(bet*REF_LEVEL_PCT[level]/Decimal("100"))
            if commission<=0: continue
            inserted=(await conn.execute(text("""INSERT INTO referral_earnings (game_round_id,referrer_id,referred_user_id,level,turnover,amount)
                VALUES (:gid,:rid,:uid,:level,:turnover,:amount) ON CONFLICT DO NOTHING RETURNING id"""),{"gid":gid,"rid":a["referrer_id"],"uid":uid,"level":level,"turnover":bet,"amount":commission})).scalar()
            if inserted:
                await conn.execute(text("UPDATE users SET referral_balance=referral_balance+:amount, referral_total_earned=referral_total_earned+:amount WHERE id=:id"),{"amount":commission,"id":a["referrer_id"]})
                await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:uid,:amount,'referral_income',:comment)"),{"uid":a["referrer_id"],"amount":commission,"comment":f"Реферальный доход {level} уровня"})
    return {"active":True,"round_id":rid,"bet":float(bet),"side":side,"step":0,"multiplier":1.0,"balance":float(bal),"history":[]}

@app.post("/api/coinflip/step")
async def coinflip_step(data: CoinFlipRoundRequest, request: Request):
    tg=await telegram_user(request)
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg); uid=u["id"]
        r=(await conn.execute(text("SELECT * FROM coinflip_rounds WHERE id=:r AND user_id=:u FOR UPDATE"),{"r":data.round_id,"u":uid})).mappings().first()
        if not r: raise HTTPException(404,"Игра не найдена")
        if r["status"]!="active": raise HTTPException(400,"Игра уже завершена")
        side=(data.side or r["chosen_side"] or "").strip().lower()
        if side not in {"hot","dice"}: raise HTTPException(400,"Выберите HOT или DICE перед броском")
        # Выбор стороны действует только на текущий бросок. Результат монеты всегда случаен.
        result=secrets.choice(("hot","dice"))
        step=int(r["step"])+1
        correct=result==side
        history=list(r["history"] or [])
        history.append({"step":step,"choice":side,"result":result,"correct":correct})
        await conn.execute(text("UPDATE coinflip_rounds SET chosen_side=:s WHERE id=:r"), {"s":side,"r":data.round_id})
        if not correct:
            cb=await coinflip_cb(conn,uid,dec(r["bet"]))
            await conn.execute(text("UPDATE coinflip_rounds SET step=:s,multiplier=1,status='lost',history=CAST(:h AS jsonb),finished_at=NOW() WHERE id=:r"),{"s":step,"h":json.dumps(history),"r":data.round_id})
            await conn.execute(text("UPDATE game_rounds SET roll_value=:v,payout=0 WHERE id=:g"),{"v":-step,"g":r["game_round_id"]})
            if cb:
                await conn.execute(text("UPDATE users SET balance=balance+:a WHERE id=:u"),{"a":cb,"u":uid})
                await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:a,'cashback','🪙 Coin Flip — кэшбэк')"),{"u":uid,"a":cb})
            bal=(await conn.execute(text("SELECT balance FROM users WHERE id=:u"),{"u":uid})).scalar()
            return {"status":"lost","result":result,"correct":False,"step":step,"multiplier":1.0,"history":history,"cashback":float(cb),"balance":float(bal)}
        mult=coinflip_mult(step)
        max_steps=len(COINFLIP_MULTIPLIERS)
        if step>=max_steps:
            payout=q(dec(r["bet"])*mult)
            await conn.execute(text("UPDATE coinflip_rounds SET step=:s,multiplier=:m,status='won',payout=:p,history=CAST(:h AS jsonb),finished_at=NOW() WHERE id=:r"),{"s":step,"m":mult,"p":payout,"h":json.dumps(history),"r":data.round_id})
            await conn.execute(text("UPDATE game_rounds SET roll_value=:v,payout=:p WHERE id=:g"),{"v":step,"p":payout,"g":r["game_round_id"]})
            await conn.execute(text("UPDATE users SET balance=balance+:p WHERE id=:u"),{"p":payout,"u":uid})
            await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:p,'game_win','🪙 Coin Flip')"),{"u":uid,"p":payout})
            bal=(await conn.execute(text("SELECT balance FROM users WHERE id=:u"),{"u":uid})).scalar()
            return {"status":"won","result":result,"correct":True,"step":step,"multiplier":float(mult),"payout":float(payout),"history":history,"balance":float(bal)}
        await conn.execute(text("UPDATE coinflip_rounds SET step=:s,multiplier=:m,history=CAST(:h AS jsonb) WHERE id=:r"),{"s":step,"m":mult,"h":json.dumps(history),"r":data.round_id})
        return {"status":"active","result":result,"correct":True,"step":step,"multiplier":float(mult),"potential_payout":float(q(dec(r["bet"])*mult)),"history":history,"balance":float(dec(u["balance"]))}

@app.post("/api/coinflip/cashout")
async def coinflip_cashout(data: CoinFlipRoundRequest, request: Request):
    tg=await telegram_user(request)
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg); uid=u["id"]
        r=(await conn.execute(text("SELECT * FROM coinflip_rounds WHERE id=:r AND user_id=:u FOR UPDATE"),{"r":data.round_id,"u":uid})).mappings().first()
        if not r or r["status"]!="active": raise HTTPException(400,"Игра уже завершена")
        step=int(r["step"])
        if step<1: raise HTTPException(400,"Сначала подбросьте монетку")
        mult=coinflip_mult(step); payout=q(dec(r["bet"])*mult)
        await conn.execute(text("UPDATE coinflip_rounds SET status='cashout',payout=:p,finished_at=NOW() WHERE id=:r"),{"p":payout,"r":data.round_id})
        await conn.execute(text("UPDATE game_rounds SET roll_value=:v,payout=:p WHERE id=:g"),{"v":step,"p":payout,"g":r["game_round_id"]})
        await conn.execute(text("UPDATE users SET balance=balance+:p WHERE id=:u"),{"p":payout,"u":uid})
        await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:p,'game_win','🪙 Coin Flip — забрал')"),{"u":uid,"p":payout})
        bal=(await conn.execute(text("SELECT balance FROM users WHERE id=:u"),{"u":uid})).scalar()
    return {"status":"cashout","step":step,"multiplier":float(mult),"payout":float(payout),"history":r["history"] or [],"balance":float(bal)}


class CrashStartRequest(BaseModel):
    bet: Decimal = Field(gt=0, le=Decimal("100000"))

class CrashRoundRequest(BaseModel):
    round_id: str
    target_multiplier: Decimal | None = Field(default=None, ge=Decimal("1.01"), le=Decimal("1000"))

CRASH_GROWTH = Decimal("0.22")


def crash_multiplier_at(started_at, now_ts=None):
    # 1.00x at launch, exponential growth after that.
    if started_at is None:
        return Decimal("1.00")
    ts = now_ts if now_ts is not None else time.time()
    try:
        elapsed = max(0.0, ts - started_at.timestamp())
    except Exception:
        elapsed = 0.0
    return Decimal(str(math.exp(float(CRASH_GROWTH) * elapsed))).quantize(Decimal("0.01"), rounding=ROUND_DOWN)


def generate_crash_point():
    # House-edge distribution: most rounds are short, rare rounds can run high.
    u = secrets.randbelow(1_000_000) / 1_000_000
    raw = Decimal("0.97") / Decimal(str(max(1e-6, 1.0 - u)))
    raw = max(Decimal("1.01"), min(raw, Decimal("1000.00")))
    return raw.quantize(Decimal("0.01"), rounding=ROUND_DOWN)


async def crash_finish_loss(conn, r, uid, crash_point):
    cb = await coinflip_cb(conn, uid, dec(r["bet"]))
    await conn.execute(text("UPDATE crash_rounds SET status='lost',finished_at=NOW() WHERE id=:r"), {"r": r["id"]})
    await conn.execute(text("UPDATE game_rounds SET roll_value=:v,payout=0 WHERE id=:g"), {"v": crash_point, "g": r["game_round_id"]})
    if cb:
        await conn.execute(text("UPDATE users SET balance=balance+:a WHERE id=:u"), {"a": cb, "u": uid})
        await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:a,'cashback','🚀 Rocket — кэшбэк')"), {"u": uid, "a": cb})
    bal = (await conn.execute(text("SELECT balance FROM users WHERE id=:u"), {"u": uid})).scalar()
    return {"status":"lost","crash_multiplier":float(crash_point),"cashback":float(cb),"balance":float(bal)}


async def crash_history(conn):
    rows=(await conn.execute(text("""SELECT crash_multiplier, status, finished_at FROM crash_rounds
        WHERE status IN ('lost','cashout') ORDER BY finished_at DESC LIMIT 12"""))).mappings().all()
    return [{"multiplier":float(r["crash_multiplier"]),"status":r["status"]} for r in rows]


@app.get("/api/crash/history")
async def crash_history_api(request: Request):
    await telegram_user(request)
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        return {"history":await crash_history(conn)}


@app.get("/api/crash/active")
async def crash_active(request: Request):
    tg=await telegram_user(request)
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg); uid=u["id"]
        r=(await conn.execute(text("SELECT * FROM crash_rounds WHERE user_id=:u AND status='active' ORDER BY created_at DESC LIMIT 1"),{"u":uid})).mappings().first()
        if not r: return {"active":False,"balance":float(u["balance"]),"history":await crash_history(conn)}
        return {"active":True,"round_id":r["id"],"bet":float(r["bet"]),"started_at":r["created_at"].isoformat(),"multiplier":float(crash_multiplier_at(r["created_at"])),"balance":float(u["balance"]),"history":await crash_history(conn)}


@app.post("/api/crash/start")
async def crash_start(data: CrashStartRequest, request: Request):
    tg=await telegram_user(request); bet=q(data.bet)
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg); uid=u["id"]
        active=(await conn.execute(text("SELECT id FROM crash_rounds WHERE user_id=:u AND status='active' LIMIT 1"),{"u":uid})).scalar()
        if active: raise HTTPException(409,"У вас уже есть активная игра Rocket")
        if dec(u["balance"])<bet: raise HTTPException(400,"Недостаточно средств")
        rid=secrets.token_urlsafe(18); crash_point=generate_crash_point()
        gid=(await conn.execute(text("INSERT INTO game_rounds(user_id,game,bet,roll_value,payout) VALUES(:u,'crash',:b,0,0) RETURNING id"),{"u":uid,"b":bet})).scalar_one()
        bal=q(dec(u["balance"])-bet)
        await conn.execute(text("UPDATE users SET balance=:b WHERE id=:u"),{"b":bal,"u":uid})
        await conn.execute(text("INSERT INTO crash_rounds(id,user_id,bet,crash_multiplier,game_round_id) VALUES(:id,:u,:b,:c,:g)"),{"id":rid,"u":uid,"b":bet,"c":crash_point,"g":gid})
        await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:a,'game_bet','🚀 Rocket')"),{"u":uid,"a":-bet})
        ancestors=(await conn.execute(text("""WITH RECURSIVE chain(referrer_id, level) AS (
            SELECT r.referrer_id, 1 FROM referrals r WHERE r.user_id=:uid
            UNION ALL SELECT r.referrer_id, c.level+1 FROM referrals r JOIN chain c ON r.user_id=c.referrer_id WHERE c.level < 3
        ) SELECT referrer_id, level FROM chain ORDER BY level"""),{"uid":uid})).mappings().all()
        for a in ancestors:
            level=int(a["level"]); commission=q(bet*REF_LEVEL_PCT[level]/Decimal("100"))
            if commission<=0: continue
            inserted=(await conn.execute(text("""INSERT INTO referral_earnings (game_round_id,referrer_id,referred_user_id,level,turnover,amount)
                VALUES (:gid,:rid,:uid,:level,:turnover,:amount) ON CONFLICT DO NOTHING RETURNING id"""),{"gid":gid,"rid":a["referrer_id"],"uid":uid,"level":level,"turnover":bet,"amount":commission})).scalar()
            if inserted:
                await conn.execute(text("UPDATE users SET referral_balance=referral_balance+:amount, referral_total_earned=referral_total_earned+:amount WHERE id=:id"),{"amount":commission,"id":a["referrer_id"]})
                await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:uid,:amount,'referral_income',:comment)"),{"uid":a["referrer_id"],"amount":commission,"comment":f"Реферальный доход {level} уровня"})
        created=(await conn.execute(text("SELECT created_at FROM crash_rounds WHERE id=:r"),{"r":rid})).scalar()
        return {"active":True,"round_id":rid,"bet":float(bet),"started_at":created.isoformat(),"multiplier":1.0,"balance":float(bal),"history":await crash_history(conn)}


@app.get("/api/crash/state")
async def crash_state(request: Request):
    tg=await telegram_user(request)
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg); uid=u["id"]
        r=(await conn.execute(text("SELECT * FROM crash_rounds WHERE user_id=:u AND status='active' ORDER BY created_at DESC LIMIT 1 FOR UPDATE"),{"u":uid})).mappings().first()
        if not r: return {"active":False,"balance":float(u["balance"]),"history":await crash_history(conn)}
        current=crash_multiplier_at(r["created_at"])
        crash_point=dec(r["crash_multiplier"])
        if current>=crash_point:
            return {"active":True,**(await crash_finish_loss(conn,r,uid,crash_point)),"history":await crash_history(conn)}
        return {"active":True,"status":"running","round_id":r["id"],"multiplier":float(current),"balance":float(u["balance"])}


@app.post("/api/crash/cashout")
async def crash_cashout(data: CrashRoundRequest, request: Request):
    tg=await telegram_user(request)
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg); uid=u["id"]
        r=(await conn.execute(text("SELECT * FROM crash_rounds WHERE id=:r AND user_id=:u FOR UPDATE"),{"r":data.round_id,"u":uid})).mappings().first()
        if not r:
            raise HTTPException(400,"Раунд не найден")
        if r["status"]!="active":
            bal=(await conn.execute(text("SELECT balance FROM users WHERE id=:u"),{"u":uid})).scalar()
            return {
                "status":str(r["status"]),
                "multiplier":float(r["cashout_multiplier"] or r["crash_multiplier"] or 1),
                "payout":float(r["payout"] or 0),
                "balance":float(bal),
                "history":await crash_history(conn)
            }
        current=crash_multiplier_at(r["created_at"]); crash_point=dec(r["crash_multiplier"])
        if current>=crash_point:
            return await crash_finish_loss(conn,r,uid,crash_point)
        # For auto-cashout, lock the payout to the selected target instead of
        # paying a later polling value. This keeps the feature predictable.
        if data.target_multiplier is not None and current >= data.target_multiplier:
            current=q(min(data.target_multiplier, crash_point - Decimal("0.01")))
            if current < Decimal("1.01"):
                return await crash_finish_loss(conn,r,uid,crash_point)
        payout=q(dec(r["bet"])*current)
        await conn.execute(text("UPDATE crash_rounds SET status='cashout',cashout_multiplier=:m,payout=:p,finished_at=NOW() WHERE id=:r"),{"m":current,"p":payout,"r":r["id"]})
        await conn.execute(text("UPDATE game_rounds SET roll_value=:v,payout=:p WHERE id=:g"),{"v":current,"p":payout,"g":r["game_round_id"]})
        await conn.execute(text("UPDATE users SET balance=balance+:p WHERE id=:u"),{"p":payout,"u":uid})
        await conn.execute(text("INSERT INTO transactions(user_id,amount,type,comment) VALUES(:u,:p,'game_win','🚀 Rocket — забрал')"),{"u":uid,"p":payout})
        bal=(await conn.execute(text("SELECT balance FROM users WHERE id=:u"),{"u":uid})).scalar()
        return {"status":"cashout","multiplier":float(current),"payout":float(payout),"balance":float(bal),"history":await crash_history(conn)}


@app.post("/api/game")
async def play_game(data: GameRequest, request: Request):
    tg=await telegram_user(request)
    raw_bet=data.bet if data.bet is not None else data.amount
    if raw_bet is None: raise HTTPException(422, "Поле bet/amount отсутствует")
    bet=q(raw_bet)
    if bet < Decimal("0.01"): raise HTTPException(400, "Минимальная ставка 0.01")
    if engine is None: raise HTTPException(500, "DATABASE_URL is empty")
    if not CHANNEL_ID: raise HTTPException(500, "CHANNEL_ID не настроен")
    if data.game not in CHANNEL_EMOJI: raise HTTPException(400, "Ргра пока не подключена")

    choice=(data.choice or "").strip().lower()
    if data.game == "dice":
        choice=normalize_dice_choice(choice)
        valid = choice in {"higher","lower","even","odd"} or (choice.startswith("exact:") and choice[6:].isdigit() and 1 <= int(choice[6:]) <= 6)
    elif data.game == "bowling":
        choice=normalize_bowling_choice(choice)
        valid = choice in {"strike","miss"} or (choice.startswith("pins:") and choice[5:].isdigit() and 2 <= int(choice[5:]) <= 5)
    elif data.game == "darts": valid = choice in {"bullseye","hit","miss"}
    elif data.game == "football": valid = choice in {"goal","miss","corner","post"}
    else: valid = choice in {"clean","backboard","miss"}
    if not valid: raise HTTPException(400, "Выберите корректный исход")

    # Check balance before publishing the public bet.
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg)
        balance=dec(u["balance"])
        if balance < bet: raise HTTPException(400,"Недостаточно средств")

    roll, err = await publish_bet_and_roll(tg, data.game, choice, bet)
    if roll is None:
        print("[CHANNEL] dice error:", err)
        raise HTTPException(502, f"Не удалось получить результат Telegram: {err}")

    won, choice_text = evaluate_bet(data.game, choice, roll)
    actual, outcome = resolve_outcome(data.game, roll)
    if data.game == "dice" and choice.startswith("exact:"):
        outcome=f"выпало число {roll}"
    multiplier=possible_multiplier(data.game, choice)
    payout=q(bet*multiplier) if won else Decimal("0.00")
    game_name=CHANNEL_GAME_NAMES[data.game]
    emoji=CHANNEL_EMOJI[data.game]

    async with engine.begin() as conn:
        u=await ensure_user(conn,tg)
        balance=dec(u["balance"])
        if balance < bet: raise HTTPException(409,"Недостаточно средств")
        new_balance=q(balance-bet+payout)
        await conn.execute(text("UPDATE users SET balance=:balance WHERE id=:id"),{"balance":new_balance,"id":u["id"]})
        gr=(await conn.execute(text("INSERT INTO game_rounds (user_id, game, bet, roll_value, payout) VALUES (:uid,:game,:bet,:roll,:payout) RETURNING id"),{"uid":u["id"],"game":data.game,"bet":bet,"roll":roll,"payout":payout})).scalar_one()
        # Pay referral income from every game turnover, regardless of win/loss.
        ancestors=(await conn.execute(text("""
            WITH RECURSIVE chain(referrer_id, level) AS (
                SELECT r.referrer_id, 1 FROM referrals r WHERE r.user_id=:uid
                UNION ALL
                SELECT r.referrer_id, c.level+1 FROM referrals r JOIN chain c ON r.user_id=c.referrer_id WHERE c.level < 3
            ) SELECT referrer_id, level FROM chain ORDER BY level
        """), {"uid":u["id"]})).mappings().all()
        for a in ancestors:
            level=int(a["level"]); commission=q(bet*REF_LEVEL_PCT[level]/Decimal("100"))
            if commission<=0: continue
            inserted=(await conn.execute(text("""
                INSERT INTO referral_earnings (game_round_id,referrer_id,referred_user_id,level,turnover,amount)
                VALUES (:gid,:rid,:uid,:level,:turnover,:amount) ON CONFLICT DO NOTHING RETURNING id
            """),{"gid":gr,"rid":a["referrer_id"],"uid":u["id"],"level":level,"turnover":bet,"amount":commission})).scalar()
            if inserted:
                await conn.execute(text("UPDATE users SET referral_balance=referral_balance+:amount, referral_total_earned=referral_total_earned+:amount WHERE id=:id"),{"amount":commission,"id":a["referrer_id"]})
                await conn.execute(text("INSERT INTO transactions (user_id, amount, type, comment) VALUES (:uid,:amount,'referral_income',:comment)"),{"uid":a["referrer_id"],"amount":commission,"comment":f"Реферальный доход {level} уровня"})
        await conn.execute(text("INSERT INTO transactions (user_id, amount, type, comment) VALUES (:uid,:amount,:type,:comment)"),{"uid":u["id"],"amount":-bet,"type":"game_bet","comment":game_name})
        if payout>0:
            await conn.execute(text("INSERT INTO transactions (user_id, amount, type, comment) VALUES (:uid,:amount,:type,:comment)"),{"uid":u["id"],"amount":payout,"type":"game_win","comment":game_name})

    ok_result, result_err=await publish_result_to_channel(data.game, choice, bet, payout, won, outcome)
    return {"ok":True,"game":data.game,"game_name":game_name,"emoji":emoji,"roll":roll,"outcome":outcome,"win":won,"bet":float(bet),"payout":float(payout),"balance":float(new_balance),"choice":choice_text,"message":f"Вы выиграли {payout:.2f} USDT" if won else f"Ставка {bet:.2f} USDT проиграна","channel_posted":ok_result,"channel_error":None if ok_result else result_err}

@app.get("/api/activity")
async def activity(request: Request):
    tg = await telegram_user(request)
    if engine is None: raise HTTPException(500, "DATABASE_URL is empty")
    async with engine.begin() as conn:
        u = await ensure_user(conn, tg)
        rows = (await conn.execute(text("SELECT game, bet, payout, roll_value, created_at FROM game_rounds WHERE user_id=:id ORDER BY created_at DESC LIMIT 30"), {"id": u["id"]})).mappings().all()
        total_deposits = (await conn.execute(text("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE user_id=:id AND credited=true"), {"id": u["id"]})).scalar() or 0
    vip = vip_info(total_deposits)
    return {"ok": True, "vip": vip, "items": [{"game": r["game"], "bet": float(r["bet"]), "payout": float(r["payout"]), "roll": r["roll_value"], "created_at": r["created_at"].isoformat()} for r in rows]}

class AmountRequest(BaseModel):
    amount: Decimal = Field(gt=0, le=Decimal("100000"))
    provider: str = Field(default="manual", max_length=64)


def qr_png_base64(url: str) -> str:
    try:
        import qrcode
        from io import BytesIO
        img = qrcode.make(url)
        buf = BytesIO()
        img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        return ""

async def credit_fiat_deposit(external_id: str, received_rub: Decimal, provider_tx_id: str = ""):
    if engine is None:
        return False
    async with engine.begin() as conn:
        row=(await conn.execute(text("""
            SELECT id,user_id,amount,fiat_amount,status,credited
            FROM deposits WHERE external_id=:ext FOR UPDATE
        """),{"ext":external_id})).mappings().first()
        if not row or row["credited"]:
            return bool(row and row["credited"])
        expected=dec(row["fiat_amount"] if row["fiat_amount"] is not None else row["amount"])
        if abs(dec(received_rub)-expected) > Decimal("0.01"):
            return False
        await conn.execute(text("""
            UPDATE deposits SET status='paid', credited=true, provider_tx_id=:tx
            WHERE id=:id
        """),{"id":row["id"],"tx":provider_tx_id or None})
        await conn.execute(text("UPDATE users SET balance=balance+:amount WHERE id=:uid"),
                           {"amount":row["amount"],"uid":row["user_id"]})
        await conn.execute(text("""
            INSERT INTO transactions (user_id, amount, type, comment)
            VALUES (:uid,:amount,'deposit',:comment)
        """),{"uid":row["user_id"],"amount":row["amount"],
              "comment":f"Пополнение СБП #{row['id']} ({expected:.2f} RUB)"})
    return True

async def _http_json(method:str, url:str, headers=None, payload=None):
    import aiohttp
    timeout=aiohttp.ClientTimeout(total=25)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.request(method, url, headers=headers or {}, json=payload) as resp:
            raw=await resp.text()
            try: data=json.loads(raw) if raw else {}
            except Exception: data={"raw":raw}
            return resp.status, data

async def cryptobot_create_invoice(amount:Decimal, deposit_id:int):
    if not CRYPTOBOT_API_TOKEN:
        raise HTTPException(503,"CryptoBot не настроен: добавь CRYPTOBOT_API_TOKEN")
    payload={
        "currency_type":"crypto","asset":"USDT","amount":f"{amount:.2f}",
        "description":f"GAMEZONE пополнение #{deposit_id}","payload":f"deposit:{deposit_id}",
        "allow_comments":False,"allow_anonymous":False,"expires_in":3600
    }
    status,data=await _http_json("POST","https://pay.crypt.bot/api/createInvoice",{
        "Crypto-Pay-API-Token":CRYPTOBOT_API_TOKEN,"Content-Type":"application/json"
    },payload)
    if status<200 or status>=300 or not data.get("ok"):
        raise HTTPException(502,f"CryptoBot API: {data.get('error','HTTP '+str(status))}")
    inv=data.get("result") or {}
    pay_url=inv.get("mini_app_invoice_url") or inv.get("bot_invoice_url") or inv.get("web_app_invoice_url")
    if not pay_url or not inv.get("invoice_id"):
        raise HTTPException(502,"CryptoBot не вернул ссылку/ID счёта")
    return str(inv["invoice_id"]), pay_url

async def xrocket_create_invoice(amount:Decimal, deposit_id:int):
    if not XROCKET_API_TOKEN:
        raise HTTPException(503,"X Rocket не настроен: добавь XROCKET_API_TOKEN")
    # Pay API Current. Keep the first invoice request deliberately minimal:
    # xRocket documents priceAmount/priceCurrency as the core invoice fields;
    # optional fields are added only when needed. Amounts are decimal strings.
    payload={
        "priceAmount":f"{amount:.2f}",
        "priceCurrency":"USDT",
        "clientInvoiceId":f"deposit_{deposit_id}"
    }
    # Do NOT send a per-invoice callback by default. xRocket will use the
    # webhook configured in the Pay application. A per-invoice callback can
    # be enabled explicitly with XROCKET_CALLBACK_URL and must be HTTPS.
    callback_url = XROCKET_CALLBACK_URL
    if callback_url.startswith("https://"):
        payload["callback"]={"callbackUrl":callback_url,"payload":{"depositId":str(deposit_id)}}
    status,data=await _http_json("POST",XROCKET_API_BASE+"/api/v1/invoices",{
        "Authorization":f"Bearer {XROCKET_API_TOKEN}",
        "Content-Type":"application/json",
        "Accept":"application/json"
    },payload)
    if status<200 or status>=300:
        detail=data.get("detail") or data.get("title") or data.get("message") or data.get("type") or f"HTTP {status}"
        if isinstance(detail,(dict,list)): detail=json.dumps(detail,ensure_ascii=False)
        # Keep the provider's RFC 9457 error visible in the server console
        # without ever printing the API token.
        print(f"[XROCKET] HTTP {status}: {json.dumps(data, ensure_ascii=False)}")
        raise HTTPException(502,f"X Rocket API: {detail}")
    inv=data if isinstance(data,dict) else {}
    inv_id=inv.get("id") or inv.get("invoiceId")
    links=inv.get("links") or {}
    # Current Pay API currently populates telegramBotLink.
    pay_url=links.get("telegramBotLink") or inv.get("telegramBotLink") or inv.get("url") or inv.get("payUrl")
    if not inv_id or not pay_url:
        raise HTTPException(502,"X Rocket не вернул ID/ссылку счёта")
    return str(inv_id), pay_url

async def credit_provider_deposit(provider:str, provider_invoice_id:str, amount:Decimal, tx_id:str="", trust_invoice_paid:bool=False):
    if engine is None: return False
    async with engine.begin() as conn:
        row=(await conn.execute(text("""
            SELECT id,user_id,amount,status,credited FROM deposits
            WHERE provider=:provider AND provider_invoice_id=:pid FOR UPDATE
        """),{"provider":provider,"pid":provider_invoice_id})).mappings().first()
        if not row or row["credited"] or row["status"] != "pending":
            return False
        expected=dec(row["amount"])
        received=dec(amount)
        # For xRocket, webhook payment.receiveAmount is net of provider fees.
        # The invoice priceAmount is the amount the player was asked to pay,
        # so callers can explicitly trust a verified paid invoice.
        if not trust_invoice_paid and abs(received-expected)>Decimal("0.01"):
            return False
        await conn.execute(text("""UPDATE deposits SET status='paid',credited=true,provider_tx_id=:tx,processed_at=NOW(),processed_by=:by WHERE id=:id"""),{"tx":tx_id or None,"by":provider,"id":row["id"]})
        await conn.execute(text("UPDATE users SET balance=balance+:amount WHERE id=:uid"),{"amount":row["amount"],"uid":row["user_id"]})
        await conn.execute(text("INSERT INTO transactions (user_id,amount,type,comment) VALUES (:uid,:amount,'deposit',:comment)"),{"uid":row["user_id"],"amount":row["amount"],"comment":f"{provider} пополнение #{row['id']}"})
    await telegram_api_call("sendMessage", {"chat_id":str(row["user_id"]),"text":f"✅ Пополнение #{row['id']} подтверждено. На баланс зачислено {expected:.2f} USDT."})
    return True

@app.post("/api/payment/crypto/create")
async def crypto_create(data: AmountRequest, request:Request):
    tg=await telegram_user(request)
    amount=q(data.amount)
    provider=(data.provider or "cryptobot").strip().lower()
    if provider not in {"cryptobot","xrocket"}: raise HTTPException(400,"Неизвестный криптосервис")
    if amount < Decimal("0.01"): raise HTTPException(400,"Минимум 0.01 USDT")
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg)
        result=await conn.execute(text("""
            INSERT INTO deposits (user_id,amount,asset,provider,external_id,status,credited,pay_url,payment_method)
            VALUES (:uid,:amount,'USDT',:provider,:external,'pending',false,NULL,:method) RETURNING id
        """),{"uid":u["id"],"amount":amount,"provider":provider,"external":secrets.token_hex(16),"method":provider})
        did=result.scalar()
    try:
        if provider=="cryptobot": pid,pay_url=await cryptobot_create_invoice(amount,did)
        else: pid,pay_url=await xrocket_create_invoice(amount,did)
        async with engine.begin() as conn:
            await conn.execute(text("UPDATE deposits SET provider_invoice_id=:pid,external_id=:pid,pay_url=:url WHERE id=:id"),{"pid":pid,"url":pay_url,"id":did})
    except Exception:
        async with engine.begin() as conn:
            await conn.execute(text("UPDATE deposits SET status='failed' WHERE id=:id"),{"id":did})
        raise
    return {"ok":True,"id":did,"provider":provider,"amount":float(amount),"pay_url":pay_url,"status":"pending","test_mode":PAYMENT_TEST_MODE}

@app.post("/api/payment/crypto/test-credit/{deposit_id}")
async def crypto_test_credit(deposit_id:int, request:Request):
    # Safety: test credit is completely disabled unless explicitly enabled in .env,
    # and only the configured Telegram admin can trigger it.
    if not PAYMENT_TEST_MODE:
        raise HTTPException(404,"Not found")
    tg=await telegram_user(request)
    if int(tg.get("id",0)) != ADMIN_ID:
        raise HTTPException(403,"Только для администратора")
    if engine is None:
        raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        row=(await conn.execute(text("""
            SELECT id,user_id,provider,provider_invoice_id,amount,status,credited
            FROM deposits WHERE id=:id
        """),{"id":deposit_id})).mappings().first()
    if not row:
        raise HTTPException(404,"Платёж не найден")
    if row["provider"] not in {"cryptobot","xrocket"}:
        raise HTTPException(400,"Тестовый режим доступен только для CryptoBot/X Rocket")
    if row["credited"]:
        return {"ok":True,"already_credited":True,"status":"paid","credited":True}
    if row["status"] != "pending":
        raise HTTPException(409,f"Платёж имеет статус {row['status']}")
    ok=await credit_provider_deposit(
        str(row["provider"]), str(row["provider_invoice_id"]),
        dec(row["amount"]), f"TEST-{deposit_id}", trust_invoice_paid=True
    )
    if not ok:
        raise HTTPException(409,"Не удалось выполнить тестовое зачисление")
    return {"ok":True,"test":True,"status":"paid","credited":True,"deposit_id":deposit_id}

@app.get("/api/payment/crypto/status/{deposit_id}")
async def crypto_status(deposit_id:int, request:Request):
    tg=await telegram_user(request)
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        row=(await conn.execute(text("SELECT id,user_id,status,credited,amount,pay_url,provider FROM deposits WHERE id=:id"),{"id":deposit_id})).mappings().first()
    if not row or int(row["user_id"])!=int(tg["id"]): raise HTTPException(404,"Платёж не найден")
    return {"ok":True,"status":row["status"],"credited":bool(row["credited"]),"amount":float(row["amount"]),"pay_url":row["pay_url"],"provider":row["provider"]}

async def get_cryptobot_usdt_rub_rate():
    if not CRYPTOBOT_API_TOKEN:
        raise HTTPException(503,"CryptoBot не настроен: добавь CRYPTOBOT_API_TOKEN для актуального курса")
    status,data=await _http_json("GET","https://pay.crypt.bot/api/getExchangeRates",{
        "Crypto-Pay-API-Token":CRYPTOBOT_API_TOKEN
    })
    if status<200 or status>=300 or not data.get("ok"):
        raise HTTPException(502,"Не удалось получить актуальный курс CryptoBot")
    rates=data.get("result") or []
    for r in rates:
        if str(r.get("source")).upper()=="USDT" and str(r.get("target")).upper()=="RUB" and r.get("is_valid",True):
            live=dec(r.get("rate"))
            if live>0:
                adjusted=(live*(Decimal("1")-BANK_RATE_MARKDOWN_PCT/Decimal("100"))).quantize(Decimal("0.01"), rounding=ROUND_DOWN)
                return live,adjusted
    raise HTTPException(502,"CryptoBot не вернул актуальный курс USDT/RUB")

@app.get("/api/payment/manual/rate")
async def manual_rate():
    live,adjusted=await get_cryptobot_usdt_rub_rate()
    return {"ok":True,"live_rate":float(live),"rate":float(adjusted),"markdown_pct":float(BANK_RATE_MARKDOWN_PCT),"source":"CryptoBot"}

@app.post("/api/payment/manual/create")
async def manual_create(data:AmountRequest, request:Request):
    tg=await telegram_user(request)
    rub=q(data.amount)
    method=(data.provider or "sbp").strip().lower()
    if method not in {"sbp","card"}: raise HTTPException(400,"Неизвестный способ оплаты")
    if rub < Decimal("100"): raise HTTPException(400,"Минимум 100 ₽")
    live_rate,bank_rate=await get_cryptobot_usdt_rub_rate()
    usdt=q(rub/bank_rate)
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg)
        result=await conn.execute(text("""
            INSERT INTO deposits (user_id,amount,asset,provider,external_id,status,credited,pay_url,fiat_amount,fiat_currency,exchange_rate,payment_method)
            VALUES (:uid,:amount,'USDT','manual',:external,'pending',false,NULL,:fiat,'RUB',:rate,:method) RETURNING id
        """),{"uid":u["id"],"amount":usdt,"external":secrets.token_hex(16),"fiat":rub,"rate":bank_rate,"method":method})
        did=result.scalar()
    details=BANK_SBP_DETAILS if method=="sbp" else BANK_CARD_DETAILS
    return {"ok":True,"id":did,"rub":float(rub),"usdt":float(usdt),"rate":float(bank_rate),"live_rate":float(live_rate),"markdown_pct":float(BANK_RATE_MARKDOWN_PCT),"method":method,"name":BANK_PAYMENT_NAME,"details":details,"note":BANK_PAYMENT_NOTE,"qr_url":BANK_SBP_QR_URL if method=="sbp" else "","status":"pending"}

@app.post("/api/payment/manual/{deposit_id}/receipt")
async def manual_receipt(deposit_id:int, request:Request, receipt:UploadFile=File(...)):
    tg=await telegram_user(request)
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    if receipt.content_type not in {"image/jpeg","image/png","image/webp","application/pdf"}:
        raise HTTPException(400,"Чек должен быть JPG, PNG, WEBP или PDF")
    content=await receipt.read()
    if len(content)>8*1024*1024: raise HTTPException(400,"Чек больше 8 МБ")
    async with engine.begin() as conn:
        row=(await conn.execute(text("""
            SELECT d.id,d.user_id,d.amount,d.fiat_amount,d.payment_method,d.status,u.username,u.first_name
            FROM deposits d JOIN users u ON u.id=d.user_id WHERE d.id=:id FOR UPDATE
        """),{"id":deposit_id})).mappings().first()
        if not row or int(row["user_id"])!=int(tg["id"]): raise HTTPException(404,"Заявка не найдена")
        if row["status"] not in {"pending"}: raise HTTPException(409,"Чек по этой заявке уже отправлен или заявка обработана")
        await conn.execute(text("UPDATE deposits SET receipt_file_name=:fn,status='receipt_submitted' WHERE id=:id"),{"fn":receipt.filename or "receipt" ,"id":deposit_id})
    ok,err=await notify_admin_deposit_receipt(deposit_id,tg,dec(row["amount"]),dec(row["fiat_amount"] or 0),row["payment_method"] or "sbp",content,receipt.filename or "receipt",receipt.content_type)
    if not ok: raise HTTPException(502,f"Не удалось отправить чек администратору: {err}")
    return {"ok":True,"status":"receipt_submitted","message":"Чек отправлен администратору. Ожидайте подтверждения в боте."}

@app.get("/api/payment/manual/status/{deposit_id}")
async def manual_status(deposit_id:int, request:Request):
    tg=await telegram_user(request)
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        row=(await conn.execute(text("SELECT id,user_id,status,credited,amount,fiat_amount,payment_method FROM deposits WHERE id=:id"),{"id":deposit_id})).mappings().first()
    if not row or int(row["user_id"])!=int(tg["id"]): raise HTTPException(404,"Заявка не найдена")
    return {"ok":True,"status":row["status"],"credited":bool(row["credited"]),"usdt":float(row["amount"]),"rub":float(row["fiat_amount"] or 0),"method":row["payment_method"]}

async def mark_provider_failed(provider:str, provider_invoice_id:str):
    if engine is None: return
    async with engine.begin() as conn:
        await conn.execute(text("UPDATE deposits SET status='failed',processed_at=NOW(),processed_by=:by WHERE provider=:provider AND provider_invoice_id=:pid AND credited=false AND status='pending'"),{"by":provider,"provider":provider,"pid":provider_invoice_id})

async def reconcile_cryptobot_invoice(invoice_id:str):
    if not CRYPTOBOT_API_TOKEN or not invoice_id: return
    status,data=await _http_json("GET","https://pay.crypt.bot/api/getInvoices",{
        "Crypto-Pay-API-Token":CRYPTOBOT_API_TOKEN
    },None)
    # _http_json cannot add query params, so use a direct URL with the invoice id.

async def _get_json_url(url:str, headers=None):
    import aiohttp
    timeout=aiohttp.ClientTimeout(total=20)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url, headers=headers or {}) as resp:
            raw=await resp.text()
            try: data=json.loads(raw) if raw else {}
            except Exception: data={"raw":raw}
            return resp.status,data

async def crypto_reconcile_loop():
    await asyncio.sleep(8)
    while True:
        try:
            if engine is not None:
                async with engine.begin() as conn:
                    rows=(await conn.execute(text("""
                        SELECT id,provider,provider_invoice_id,amount,status,created_at
                        FROM deposits
                        WHERE provider IN ('cryptobot','xrocket') AND status='pending' AND credited=false
                        ORDER BY id ASC LIMIT 4
                    """))).mappings().all()
                for row in rows:
                    provider=row["provider"]; pid=str(row["provider_invoice_id"] or "")
                    if not pid: continue
                    try:
                        if provider=="cryptobot" and CRYPTOBOT_API_TOKEN:
                            st,data=await _get_json_url("https://pay.crypt.bot/api/getInvoices?invoice_ids="+pid,{"Crypto-Pay-API-Token":CRYPTOBOT_API_TOKEN})
                            if 200 <= st < 300 and data.get("ok"):
                                items=(data.get("result") or {}).get("items") or []
                                inv=items[0] if items else {}
                                if inv.get("status")=="paid":
                                    await credit_provider_deposit("cryptobot",pid,dec(inv.get("amount") or row["amount"]),str(inv.get("hash") or pid),trust_invoice_paid=True)
                                elif inv.get("status") in {"expired","cancelled"}:
                                    await mark_provider_failed("cryptobot",pid)
                        elif provider=="xrocket" and XROCKET_API_TOKEN:
                            st,data=await _get_json_url(XROCKET_API_BASE+"/api/v1/invoice?invoiceId="+pid,{"Authorization":f"Bearer {XROCKET_API_TOKEN}","Accept":"application/json"})
                            if 200 <= st < 300 and isinstance(data,dict):
                                if data.get("status")=="paid":
                                    await credit_provider_deposit("xrocket",pid,dec(data.get("priceAmount") or row["amount"]),"reconcile",trust_invoice_paid=True)
                                elif data.get("status") in {"expired","cancelled"}:
                                    await mark_provider_failed("xrocket",pid)
                    except Exception as e:
                        print(f"[PAYMENT RECONCILE] {provider} #{row['id']}: {e}")
        except Exception as e:
            print(f"[PAYMENT RECONCILE] loop: {e}")
        await asyncio.sleep(15)

@app.post("/api/payment/cryptobot/webhook/{secret_path}")
async def cryptobot_webhook(secret_path:str, request:Request):
    if not CRYPTOBOT_API_TOKEN or not CRYPTOBOT_WEBHOOK_SECRET_PATH or not hmac.compare_digest(secret_path,CRYPTOBOT_WEBHOOK_SECRET_PATH):
        raise HTTPException(404,"Not found")
    raw=await request.body()
    sig=request.headers.get("crypto-pay-api-signature","")
    secret=hashlib.sha256(CRYPTOBOT_API_TOKEN.encode()).digest()
    expected=hmac.new(secret,raw,hashlib.sha256).hexdigest()
    if not sig or not hmac.compare_digest(sig,expected): raise HTTPException(401,"Invalid signature")
    try: upd=json.loads(raw.decode("utf-8"))
    except Exception: raise HTTPException(400,"Invalid JSON")
    if upd.get("update_type")!="invoice_paid": return {"ok":True}
    inv=upd.get("payload") or {}
    await credit_provider_deposit("cryptobot",str(inv.get("invoice_id") or ""),dec(inv.get("amount")),str(inv.get("hash") or inv.get("invoice_id") or ""))
    return {"ok":True}

@app.post("/api/payment/xrocket/webhook")
async def xrocket_webhook(request:Request):
    if not XROCKET_WEBHOOK_SECRET: raise HTTPException(503,"XROCKET_WEBHOOK_SECRET не настроен")
    signature=request.headers.get("Signature",""); version=request.headers.get("Signature-Version",""); timestamp=request.headers.get("Signature-Timestamp","")
    if not signature or version!="v1" or not timestamp: raise HTTPException(401,"Invalid signature")
    try: ts=int(timestamp)
    except Exception: raise HTTPException(401,"Invalid timestamp")
    if abs(int(time.time()*1000)-ts)>300000: raise HTTPException(401,"Stale webhook")
    raw=await request.body()
    signed=f"{timestamp}.".encode()+raw
    expected=hmac.new(XROCKET_WEBHOOK_SECRET.encode(),signed,hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,signature): raise HTTPException(401,"Invalid signature")
    try: event=json.loads(raw.decode("utf-8"))
    except Exception: raise HTTPException(400,"Invalid JSON")
    if event.get("type")!="invoice": return {"ok":True}
    data=event.get("data") or {}; inv=data.get("invoice") or {}; pay=data.get("payment") or {}
    if data.get("event")=="payment_status_changed" and pay.get("status")=="paid":
        amount=dec(inv.get("priceAmount") or pay.get("payAmount") or 0)
        await credit_provider_deposit("xrocket",str(inv.get("id") or ""),amount,str(pay.get("id") or ""),trust_invoice_paid=True)
    elif data.get("event")=="invoice_status_changed" and inv.get("status")=="paid":
        # Fallback reconciliation when only the invoice-status event is seen.
        # The payment event normally carries the net receiveAmount and is the
        # preferred source for crediting.
        amount=dec(inv.get("priceAmount") or 0)
        if amount>0:
            await credit_provider_deposit("xrocket",str(inv.get("id") or ""),amount,"invoice_status",trust_invoice_paid=True)
    return {"ok":True}

def robokassa_signature(out_sum: str, inv_id: str) -> str:
    raw=f"{ROBOKASSA_LOGIN}:{out_sum}:{inv_id}:{ROBOKASSA_PASS1}".encode()
    return hashlib.md5(raw).hexdigest()

def robokassa_result_signature(out_sum: str, inv_id: str, shp: dict) -> str:
    parts=[out_sum, inv_id, ROBOKASSA_PASS2]
    for key in sorted(shp):
        if key.lower().startswith("shp_"):
            parts.append(f"{key}={shp[key]}")
    return hashlib.md5(":".join(parts).encode()).hexdigest()

async def robokassa_create(rub: Decimal, deposit_id: int, email: str = ""):
    if not ROBOKASSA_LOGIN or not ROBOKASSA_PASS1:
        raise HTTPException(503,"Robokassa не настроена: добавь ROBOKASSA_LOGIN и ROBOKASSA_PASS1")
    out_sum=f"{rub:.2f}"
    inv_id=str(deposit_id)
    sig=robokassa_signature(out_sum,inv_id)
    from urllib.parse import urlencode
    params={
        "MerchantLogin":ROBOKASSA_LOGIN,"OutSum":out_sum,"InvId":inv_id,
        "Description":f"Пополнение GAMEZONE #{deposit_id}","SignatureValue":sig,
        "IncCurrLabel":"SBP","Culture":"ru"
    }
    if email:
        params["Email"]=email
    if ROBOKASSA_IS_TEST in {"1","true","yes"}:
        params["IsTest"]="1"
    url="https://auth.robokassa.ru/Merchant/Index.aspx?"+urlencode(params)
    return url

@app.post("/api/payment/robokassa/result")
async def robokassa_result(request: Request):
    form=await request.form()
    out_sum=str(form.get("OutSum") or "")
    inv_id=str(form.get("InvId") or form.get("InvoiceID") or "")
    if not out_sum or not inv_id or not ROBOKASSA_PASS2:
        return PlainTextResponse("ERROR",status_code=400)
    shp={str(k):str(v) for k,v in form.items() if str(k).lower().startswith("shp_")}
    expected=robokassa_result_signature(out_sum,inv_id,shp)
    got=str(form.get("SignatureValue") or "").lower()
    if not hmac.compare_digest(got,expected.lower()):
        return PlainTextResponse("ERROR",status_code=403)
    ok=await credit_fiat_deposit(inv_id,dec(out_sum),inv_id)
    return PlainTextResponse(f"OK{inv_id}" if ok else "ERROR")

@app.post("/api/payment/sbp/create")
async def sbp_create(data: AmountRequest, request: Request):
    tg=await telegram_user(request)
    rub=q(data.amount)
    provider=(data.provider or "robokassa").strip().lower()
    if rub < Decimal("1"):
        raise HTTPException(400,"Минимум 1 ₽")
    if BANK_USDT_RATE <= 0: raise HTTPException(500,"BANK_USDT_RATE должен быть больше 0")
    usdt=q(rub / BANK_USDT_RATE)
    if usdt <= 0: raise HTTPException(400,"Сумма СЃР»РёС€РєРѕРј РјР°Р»Р°")
    if provider != "robokassa":
        raise HTTPException(400,"Доступна только Robokassa")
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        u=await ensure_user(conn,tg)
        external=secrets.token_hex(16)
        result=await conn.execute(text("""
            INSERT INTO deposits
            (user_id,amount,asset,provider,external_id,status,credited,pay_url,fiat_amount,fiat_currency,exchange_rate)
            VALUES (:uid,:amount,'USDT',:provider,:external,'pending',false,NULL,:fiat,'RUB',:rate)
            RETURNING id
        """),{"uid":u["id"],"amount":usdt,"provider":f"bank_{provider}","external":external,"fiat":rub,"rate":BANK_USDT_RATE})
        deposit_id=result.scalar()
    try:
        pay_url=await robokassa_create(rub,deposit_id)
        external_id=str(deposit_id)
        async with engine.begin() as conn:
            await conn.execute(text("UPDATE deposits SET external_id=:ext,pay_url=:url WHERE id=:id"),{"ext":external_id,"url":pay_url,"id":deposit_id})
    except HTTPException:
        async with engine.begin() as conn:
            await conn.execute(text("UPDATE deposits SET status='failed' WHERE id=:id"),{"id":deposit_id})
        raise
    return {"ok":True,"id":deposit_id,"invoice_id":external_id,"rub":float(rub),"usdt":float(usdt),"rate":float(BANK_USDT_RATE),"qr_url":pay_url,"qr_image":qr_png_base64(pay_url),"status":"pending","provider":provider}

@app.get("/api/payment/sbp/status/{deposit_id}")
async def sbp_status(deposit_id:int, request:Request):
    tg=await telegram_user(request)
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        row=(await conn.execute(text("""
            SELECT d.id,d.user_id,d.amount,d.fiat_amount,d.fiat_currency,d.exchange_rate,d.status,d.credited,d.external_id,d.pay_url,d.provider
            FROM deposits d WHERE d.id=:id
        """),{"id":deposit_id})).mappings().first()
    if not row or int(row["user_id"]) != int(tg["id"]): raise HTTPException(404,"Платёж не найден")
    async with engine.begin() as conn:
        row=(await conn.execute(text("SELECT id,status,credited,amount,fiat_amount,pay_url,provider FROM deposits WHERE id=:id"),{"id":deposit_id})).mappings().first()
    return {"ok":True,"status":row["status"],"credited":bool(row["credited"]),"usdt":float(row["amount"]),"rub":float(row["fiat_amount"] or 0),"pay_url":row["pay_url"],"provider":row["provider"]}

@app.get("/api/payment/return")
async def payment_return(request: Request):
    return HTMLResponse("<html><body style='background:#050505;color:#fff;font-family:Arial;text-align:center;padding:40px'><h2>Платёж обрабатывается</h2><p>Вернитесь в GAMEZONE — баланс обновится автоматически.</p></body></html>")

class WithdrawRequest(BaseModel):
    amount: Decimal = Field(gt=0, le=Decimal("100000"))
    address: str = Field(min_length=3, max_length=500)
    provider: str = Field(default="manual", max_length=32)

@app.post("/api/withdraw")
async def withdraw(data: WithdrawRequest, request: Request):
    tg = await telegram_user(request); amount = q(data.amount)
    provider = data.provider.strip().lower()
    if provider not in {"cryptobot", "xrocket", "manual", "bank_sber", "bank_vtb", "bank_gazprombank", "bank_alfa", "bank_psb", "bank_rshb", "bank_mkb", "bank_tbank", "bank_sovcombank", "bank_domrf"}:
        raise HTTPException(400, "Неизвестный способ вывода")
    if engine is None: raise HTTPException(500, "DATABASE_URL is empty")
    async with engine.begin() as conn:
        u = await ensure_user(conn, tg)
        balance = dec(u["balance"])
        if balance < amount: raise HTTPException(400, "Недостаточно средств")
        new_balance = q(balance - amount)
        await conn.execute(text("UPDATE users SET balance=:balance WHERE id=:id"), {"balance": new_balance, "id": u["id"]})
        result = await conn.execute(text("INSERT INTO withdrawals (user_id, amount, destination, status, provider) VALUES (:uid,:amount,:dest,'pending',:provider) RETURNING id"), {"uid": u["id"], "amount": amount, "dest": data.address.strip(), "provider": provider})
        wid = result.scalar()
        await conn.execute(text("INSERT INTO transactions (user_id, amount, type, comment) VALUES (:uid,:amount,'withdrawal',:comment)"), {"uid": u["id"], "amount": -amount, "comment": f"Р—аявка на вывод ({provider})"})
    ok_admin, admin_err = await notify_admin_withdrawal(wid, tg, amount, provider, data.address.strip())
    if not ok_admin:
        print("[ADMIN NOTIFY]", admin_err)
    return {"ok": True, "id": wid, "status": "pending", "provider": provider, "balance": float(new_balance),
            "admin_notified": ok_admin, "message": "Р—аявка на вывод создана и отправлена администратору."}

def admin_check(request: Request):
    if not ADMIN_PASSWORD:
        raise HTTPException(503, "ADMIN_PASSWORD не настроен")
    key = request.headers.get("X-Admin-Key", "")
    if not hmac.compare_digest(key, ADMIN_PASSWORD):
        raise HTTPException(401, "Неверный ключ администратора")

@app.get("/admin", response_class=HTMLResponse)
async def admin_page():
    path=os.path.join(WEB_DIR,"admin.html")
    if not os.path.exists(path): raise HTTPException(404,"admin.html not found")
    return HTMLResponse(open(path, encoding="utf-8").read())

@app.get("/api/admin/withdrawals")
async def admin_withdrawals(request: Request):
    admin_check(request)
    async with engine.begin() as conn:
        rows=(await conn.execute(text("SELECT w.id,w.user_id,w.amount,w.destination,w.status,w.provider,w.tx_id,w.receipt_file_id,w.admin_note,w.created_at,u.username,u.first_name FROM withdrawals w JOIN users u ON u.id=w.user_id WHERE w.status='pending' ORDER BY w.created_at ASC LIMIT 100"))).mappings().all()
    return {"ok":True,"items":[dict(r) for r in rows]}

@app.post("/api/admin/withdrawals/{wid}/approve")
async def admin_approve_withdrawal(wid:int, request:Request, tx_id:str=Form(""), note:str=Form(""), receipt:UploadFile|None=File(None)):
    admin_check(request)
    if engine is None: raise HTTPException(500,"DATABASE_URL is empty")
    async with engine.begin() as conn:
        row=(await conn.execute(text("""
            SELECT w.id,w.user_id,w.amount,w.status,w.provider
            FROM withdrawals w WHERE w.id=:id FOR UPDATE
        """),{"id":wid})).mappings().first()
        if not row: raise HTTPException(404,"Заявка не найдена")
        if row["status"]!="pending": raise HTTPException(409,"Р—аявка уже обработана")
        if row["provider"] in {"cryptobot","xrocket"}:
            if receipt is None: raise HTTPException(400,"Для CryptoBot/X Rocket нужен чек.")
            if receipt.content_type not in {"image/jpeg","image/png","image/webp","application/pdf"}:
                raise HTTPException(400,"Чек должен быть JPG, PNG, WEBP или PDF")
            content=await receipt.read()
            if len(content)>8*1024*1024: raise HTTPException(400,"Чек больше 8 МБ")
        else:
            content=None
        await conn.execute(text("""
            UPDATE withdrawals SET status='paid',tx_id=:tx,admin_note=:note,
            processed_at=NOW(),processed_by='admin' WHERE id=:id
        """),{"id":wid,"tx":tx_id.strip() or None,"note":note.strip() or None})
    provider_name=WITHDRAW_PROVIDER_NAMES.get(row["provider"],row["provider"])
    if row["provider"] in {"cryptobot","xrocket"}:
        caption=f"✅ Вывод подтверждён\nСумма: {dec(row['amount']):.2f} USDT\nСпособ: {html.escape(provider_name)}" + (f"\nTX: {html.escape(tx_id.strip())}" if tx_id.strip() else "")
        ok_msg,err_msg=await telegram_channel_call("sendMessage",{"chat_id":str(row["user_id"]),"text":caption,"parse_mode":"HTML"})
        import urllib.request
        boundary="----GameZone"+secrets.token_hex(12)
        body=b""
        for k,v in [("chat_id",str(row["user_id"])),("caption","🧾 "+caption),("parse_mode","HTML")]:
            body += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n").encode()
        filename=receipt.filename or "receipt"
        body += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"document\"; filename=\"{filename}\"\r\nContent-Type: {receipt.content_type}\r\n\r\n").encode()+content+f"\r\n--{boundary}--\r\n".encode()
        receipt_file_id=None
        try:
            url=f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"
            def _upload():
                req=urllib.request.Request(url,data=body,headers={"Content-Type":f"multipart/form-data; boundary={boundary}"},method="POST")
                with urllib.request.urlopen(req,timeout=20) as resp: return json.loads(resp.read().decode())
            up=await asyncio.to_thread(_upload)
            if up.get("ok"): receipt_file_id=up.get("result",{}).get("document",{}).get("file_id")
        except Exception as e:
            print("[ADMIN RECEIPT]",e)
        if receipt_file_id:
            async with engine.begin() as conn:
                await conn.execute(text("UPDATE withdrawals SET receipt_file_id=:fid WHERE id=:id"),{"fid":receipt_file_id,"id":wid})
        return {"ok":True,"client_notified":ok_msg,"receipt_sent":bool(receipt_file_id),"telegram_error":None if ok_msg else err_msg}
    else:
        ok_msg,err_msg=await telegram_api_call("sendMessage",{
            "chat_id":str(row["user_id"]),
            "text":f"вњ… Р’С‹РІРѕРґ #{wid} РїРѕРґС‚РІРµСЂР¶РґС‘РЅ.\nСумма: {dec(row['amount']):.2f} USDT\nСпособ: {provider_name}\nПодтверждение оплаты получено."
        })
        return {"ok":True,"client_notified":ok_msg,"receipt_sent":False,"telegram_error":None if ok_msg else err_msg}


@app.on_event("shutdown")
async def shutdown():
    global TG_POLL_TASK
    if TG_POLL_TASK:
        TG_POLL_TASK.cancel()
    if engine: await engine.dispose()

