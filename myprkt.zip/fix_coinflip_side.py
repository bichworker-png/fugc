import asyncio
from sqlalchemy import text
from webapp import engine

async def main():
    if engine is None:
        raise RuntimeError("DATABASE_URL не найден в .env")

    async with engine.begin() as conn:
        # Совместимость со старой схемой coinflip_rounds:
        # старый код/таблица ожидает NOT NULL колонку side.
        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ADD COLUMN IF NOT EXISTS side VARCHAR(8)
        """))

        # Заполняем старые NULL-значения безопасным значением.
        await conn.execute(text("""
            UPDATE coinflip_rounds
            SET side = COALESCE(side, chosen_side, 'hot')
            WHERE side IS NULL
        """))

        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ALTER COLUMN side SET DEFAULT 'hot'
        """))

        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ALTER COLUMN side SET NOT NULL
        """))

    await engine.dispose()
    print("COINFLIP SIDE FIX OK")

if __name__ == "__main__":
    asyncio.run(main())
