GAMEZONE MINI APP — ПЕРВЫЙ ЗАПУСК

1. Распакуйте архив.
2. Скопируйте папку webapp, файл webapp.py, run_webapp.bat и requirements_webapp.txt в C:\telegram_games_bot
3. Откройте CMD:
   cd C:\telegram_games_bot
   venv\Scripts\activate
   pip install -r requirements_webapp.txt
4. Запустите:
   run_webapp.bat

После запуска Mini App будет на http://127.0.0.1:8000

ВАЖНО: Telegram на телефоне должен получить HTTPS-ссылку. Для теста используйте Cloudflare Tunnel:
   cloudflared tunnel --url http://localhost:8000
Он выдаст ссылку вида https://....trycloudflare.com

Затем BotFather:
   /mybots
   выбрать бота
   Bot Settings
   Menu Button
   Configure Menu Button
   текст: 🎮 Играть
   URL: HTTPS-адрес Mini App

Сначала в боте нажмите /start, затем откройте кнопку «Играть».

Внутри уже есть:
- зелёно-чёрный дизайн;
- баланс из PostgreSQL;
- профиль;
- статистика;
- четыре игры;
- ставки через сервер;
- окна депозита и вывода;
- проверка Telegram initData.

Платежи CryptoBot/xRocket и окончательная интеграция всех игровых правил подключаются следующим этапом после проверки запуска Mini App.
