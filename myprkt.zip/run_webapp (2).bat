@echo off
cd /d C:\telegram_games_bot
call venv\Scripts\activate
python -m uvicorn webapp:app --host 0.0.0.0 --port 8000
pause
