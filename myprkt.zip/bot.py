
import asyncio
import logging
import os
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from datetime import datetime

import aiohttp
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from dotenv import load_dotenv
from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Integer, Numeric, String, Text, func, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

# =========================
# НАСТРОЙКИ
# =========================
load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()

def parse_admin_ids(raw: str) -> set[int]:
    result = set()
    for part in raw.replace(";", ",").split(","):
        part = part.strip()
        if part:
            try:
                result.add(int(part))
            except ValueError:
                pass
    return result

ADMIN_IDS = parse_admin_ids(os.getenv("ADMIN_IDS", ""))

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://postgres:YOUR_POSTGRES_PASSWORD@localhost:5432/games_bot"
).strip()

CRYPTO_PAY_TOKEN = os.getenv("CRYPTO_PAY_TOKEN", "").strip()
CRYPTO_PAY_ASSET = os.getenv("CRYPTO_PAY_ASSET", "USDT").strip() or "USDT"
CRYPTO_PAY_TESTNET = os.getenv("CRYPTO_PAY_TESTNET", "false").lower() in ("1", "true", "yes")

MIN_BET = Decimal(os.getenv("MIN_BET", "1.00"))
MAX_BET = Decimal(os.getenv("MAX_BET", "1000.00"))

GAMES = {
    "dice":      ("🎲 Кубик", "🎲", 4, Decimal("1.80")),
    "bowling":   ("🎳 Боулинг", "🎳", 4, Decimal("1.80")),
    "darts":     ("🎯 Дартс", "🎯", 4, Decimal("1.80")),
    "football": ("⚽ Футбол", "⚽", 4, Decimal("2.00")),
}

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger(__name__)


# =========================
# DATABASE
# =========================
class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    username: Mapped[str | None] = mapped_column(String(255))
    first_name: Mapped[str | None] = mapped_column(String(255))
    balance: Mapped[Decimal] = mapped_column(Numeric(18, 2), default=Decimal("0.00"))
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Transaction(Base):
    __tablename__ = "transactions"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 2))
    type: Mapped[str] = mapped_column(String(50))
    comment: Mapped[str | None] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class GameRound(Base):
    __tablename__ = "game_rounds"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    game: Mapped[str] = mapped_column(String(30))
    bet: Mapped[Decimal] = mapped_column(Numeric(18, 2))
    roll_value: Mapped[int] = mapped_column(Integer)
    payout: Mapped[Decimal] = mapped_column(Numeric(18, 2))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Deposit(Base):
    __tablename__ = "deposits"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 2))
    asset: Mapped[str] = mapped_column(String(20), default="USDT")
    provider: Mapped[str] = mapped_column(String(30), default="manual")
    external_id: Mapped[str | None] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(30), default="pending")
    credited: Mapped[bool] = mapped_column(Boolean, default=False)
    pay_url: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Withdrawal(Base):
    __tablename__ = "withdrawals"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 2))
    destination: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(30), default="pending")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[str] = mapped_column(Text)


engine = create_async_engine(DATABASE_URL, pool_pre_ping=True)
Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
bot = Bot(BOT_TOKEN)
dp = Dispatcher()


# =========================
# FSM
# =========================
class BetState(StatesGroup):
    amount = State()


class DepositState(StatesGroup):
    amount = State()


class WithdrawState(StatesGroup):
    amount = State()
    destination = State()


class AdminBalanceState(StatesGroup):
    text = State()


class BroadcastState(StatesGroup):
    text = State()


# =========================
# KEYBOARDS
# =========================
def main_kb():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🎮 ИГРАТЬ"), KeyboardButton(text="👤 ПРОФИЛЬ")],
            [KeyboardButton(text="💰 КОШЕЛЁК"), KeyboardButton(text="🎁 БОНУС")],
            [KeyboardButton(text="📊 СТАТИСТИКА"), KeyboardButton(text="ℹ️ О ПРОЕКТЕ")],
            [KeyboardButton(text="🆘 ПОДДЕРЖКА")],
        ], resize_keyboard=True, is_persistent=True, input_field_placeholder="Выберите раздел"
    )


def games_kb():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🎲 Кубик"), KeyboardButton(text="🎳 Боулинг")],
            [KeyboardButton(text="🎯 Дартс"), KeyboardButton(text="⚽ Футбол")],
            [KeyboardButton(text="🏠 Главное меню")],
        ], resize_keyboard=True
    )


def admin_kb():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="👥 Пользователи"), KeyboardButton(text="📊 Статистика")],
            [KeyboardButton(text="💰 Управление балансом"), KeyboardButton(text="💳 Пополнения")],
            [KeyboardButton(text="💸 Выводы"), KeyboardButton(text="⚙️ Настройки")],
            [KeyboardButton(text="📢 Рассылка"), KeyboardButton(text="🔙 Главное меню")],
        ], resize_keyboard=True
    )


def request_kb(kind, rid):
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Одобрить", callback_data=f"ok:{kind}:{rid}"),
        InlineKeyboardButton(text="❌ Отклонить", callback_data=f"no:{kind}:{rid}"),
    ]])


# =========================
# HELPERS
# =========================
def admin(uid):
    return uid in ADMIN_IDS


async def ensure_user(message):
    if not message.from_user:
        return None
    async with Session() as s:
        u = await s.get(User, message.from_user.id)
        if not u:
            u = User(
                id=message.from_user.id,
                username=message.from_user.username,
                first_name=message.from_user.first_name,
            )
            s.add(u)
        else:
            u.username = message.from_user.username
            u.first_name = message.from_user.first_name
        await s.commit()
        return u


async def tables():
    async with engine.begin() as c:
        await c.run_sync(Base.metadata.create_all)
    async with Session() as s:
        for k, v in {
            "maintenance": "0",
            "min_bet": str(MIN_BET),
            "max_bet": str(MAX_BET),
        }.items():
            if not await s.get(Setting, k):
                s.add(Setting(key=k, value=v))
        await s.commit()


async def setting(key, default=""):
    async with Session() as s:
        x = await s.get(Setting, key)
        return x.value if x else default


async def set_setting(key, value):
    async with Session() as s:
        x = await s.get(Setting, key)
        if x:
            x.value = value
        else:
            s.add(Setting(key=key, value=value))
        await s.commit()


async def amount(text):
    try:
        x = Decimal((text or "").replace(",", "."))
        return x.quantize(Decimal("0.01"), rounding=ROUND_DOWN) if x > 0 else None
    except InvalidOperation:
        return None


async def change_balance(uid, value, tx_type, comment=""):
    async with Session() as s:
        u = await s.get(User, uid, with_for_update=True)
        if not u or Decimal(u.balance) + value < 0:
            return None
        u.balance = Decimal(u.balance) + value
        s.add(Transaction(user_id=uid, amount=value, type=tx_type, comment=comment))
        await s.commit()
        return Decimal(u.balance)


async def maintenance():
    return await setting("maintenance", "0") == "1"


# =========================
# CRYPTO PAY
# =========================
def crypto_base():
    return "https://testnet-pay.crypt.bot/api" if CRYPTO_PAY_TESTNET else "https://pay.crypt.bot/api"


async def crypto(method, http_method="GET", data=None, params=None):
    if not CRYPTO_PAY_TOKEN:
        return None
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as h:
            headers = {"Crypto-Pay-API-Token": CRYPTO_PAY_TOKEN}
            url = f"{crypto_base()}/{method}"
            if http_method == "POST":
                r = await h.post(url, headers=headers, json=data or {})
            else:
                r = await h.get(url, headers=headers, params=params or {})
            j = await r.json()
            return j.get("result") if j.get("ok") else None
    except Exception:
        log.exception("Crypto Pay API error")
        return None


async def crypto_invoice(uid, value):
    return await crypto("createInvoice", "POST", {
        "asset": CRYPTO_PAY_ASSET,
        "amount": str(value),
        "description": f"Пополнение #{uid}",
        "payload": f"user:{uid}",
    })


async def check_invoice(invoice_id):
    r = await crypto("getInvoices", params={"invoice_ids": str(invoice_id)})
    if isinstance(r, dict):
        r = r.get("items", [])
    return r[0] if r else None


async def crypto_worker():
    while True:
        try:
            if CRYPTO_PAY_TOKEN:
                async with Session() as s:
                    q = await s.execute(select(Deposit).where(
                        Deposit.provider == "cryptobot",
                        Deposit.status == "pending",
                        Deposit.credited.is_(False),
                        Deposit.external_id.is_not(None),
                    ).limit(50))
                    rows = q.scalars().all()
                for d in rows:
                    inv = await check_invoice(d.external_id)
                    if not inv or inv.get("status") != "paid":
                        continue
                    async with Session() as s:
                        d2 = await s.get(Deposit, d.id)
                        if not d2 or d2.credited:
                            continue
                        u = await s.get(User, d2.user_id, with_for_update=True)
                        if not u:
                            continue
                        d2.status = "paid"
                        d2.credited = True
                        u.balance = Decimal(u.balance) + Decimal(d2.amount)
                        s.add(Transaction(
                            user_id=u.id, amount=d2.amount,
                            type="CRYPTO_DEPOSIT",
                            comment=f"CryptoBot invoice {d2.external_id}",
                        ))
                        await s.commit()
                        try:
                            await bot.send_message(u.id, f"✅ Пополнение зачислено: {Decimal(d2.amount):.2f} {d2.asset}")
                        except Exception:
                            pass
        except Exception:
            log.exception("Payment worker")
        await asyncio.sleep(15)


# =========================
# USER
# =========================
# Кнопка "Главное меню" имеет приоритет над любым режимом ввода.
@dp.message(F.text.in_({"🔙 Главное меню", "🏠 Главное меню"}))
async def home_global(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("🏠 Главное меню", reply_markup=main_kb())


@dp.message(CommandStart())
async def start(m: Message, state: FSMContext):
    await state.clear()
    u = await ensure_user(m)
    if not u:
        return
    if u.is_blocked:
        return await m.answer("🚫 Ваш аккаунт заблокирован.")
    if await maintenance() and not admin(u.id):
        return await m.answer("🔧 Технические работы.")
    text = (
        "🟢 <b>PLAY BOT</b>\n\n"
        "Играй. Управляй балансом. Следи за статистикой.\n\n"
        f"💰 Баланс: <b>{Decimal(u.balance):.2f} $</b>"
    )
    try:
        banner = FSInputFile(os.path.join(os.path.dirname(__file__), "assets", "design_reference.png"))
        await m.answer_photo(banner, caption=text, reply_markup=main_kb(), parse_mode="HTML")
    except Exception:
        await m.answer(text, reply_markup=main_kb(), parse_mode="HTML")


@dp.message(F.text == "👤 ПРОФИЛЬ")
async def profile(m: Message):
    u = await ensure_user(m)
    await m.answer(
        f"👤 <b>Профиль</b>\n\n🆔 <code>{u.id}</code>\n"
        f"👤 @{u.username or 'нет'}\n💰 <b>{Decimal(u.balance):.2f}</b>",
        parse_mode="HTML"
    )


@dp.message(F.text == "💰 КОШЕЛЁК")
async def balance(m: Message):
    u = await ensure_user(m)
    await m.answer(f"💰 Баланс: <b>{Decimal(u.balance):.2f}</b>", parse_mode="HTML")


@dp.message(F.text == "🎮 ИГРАТЬ")
async def games(m: Message):
    await m.answer("🎮 Выберите игру:", reply_markup=games_kb())


async def choose_game(m, state, key):
    if await maintenance() and not admin(m.from_user.id):
        return await m.answer("🔧 Игры временно отключены.")
    await state.update_data(game=key)
    await state.set_state(BetState.amount)
    mn, mx = Decimal(await setting("min_bet", str(MIN_BET))), Decimal(await setting("max_bet", str(MAX_BET)))
    await m.answer(f"{GAMES[key][0]}\nВведите ставку от <b>{mn:.2f}</b> до <b>{mx:.2f}</b>.", parse_mode="HTML")


@dp.message(F.text == "🎲 Кубик")
async def g1(m, state): await choose_game(m, state, "dice")


@dp.message(F.text == "🎳 Боулинг")
async def g2(m, state): await choose_game(m, state, "bowling")


@dp.message(F.text == "🎯 Дартс")
async def g3(m, state): await choose_game(m, state, "darts")


@dp.message(F.text == "⚽ Футбол")
async def g4(m, state): await choose_game(m, state, "football")


@dp.message(BetState.amount, F.text.in_({"🔙 Главное меню", "🏠 Главное меню"}))
async def home_from_bet(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("🏠 Главное меню", reply_markup=main_kb())


@dp.message(BetState.amount)
async def play(m: Message, state: FSMContext):
    value = await amount(m.text)
    data = await state.get_data()
    key = data.get("game")
    if not value or key not in GAMES:
        return await m.answer("❌ Введите корректную ставку.")
    mn, mx = Decimal(await setting("min_bet", str(MIN_BET))), Decimal(await setting("max_bet", str(MAX_BET)))
    if value < mn or value > mx:
        return await m.answer(f"❌ Ставка: от {mn:.2f} до {mx:.2f}.")
    async with Session() as s:
        u = await s.get(User, m.from_user.id, with_for_update=True)
        if not u or u.is_blocked or Decimal(u.balance) < value:
            await state.clear()
            return await m.answer("❌ Недостаточно средств или аккаунт заблокирован.")
        u.balance = Decimal(u.balance) - value
        s.add(Transaction(user_id=u.id, amount=-value, type="GAME_BET", comment=key))
        await s.commit()
        after_bet = Decimal(u.balance)

    name, emoji, win_from, multiplier = GAMES[key]
    try:
        dice = await bot.send_dice(m.chat.id, emoji=emoji)
    except Exception:
        await change_balance(m.from_user.id, value, "GAME_REFUND", "Ошибка броска")
        await state.clear()
        return await m.answer("❌ Ошибка игры, ставка возвращена.")
    roll = dice.dice.value
    payout = (value * multiplier).quantize(Decimal("0.01"), rounding=ROUND_DOWN) if roll >= win_from else Decimal("0")
    async with Session() as s:
        u = await s.get(User, m.from_user.id, with_for_update=True)
        u.balance = Decimal(u.balance) + payout
        s.add(Transaction(user_id=u.id, amount=payout, type="GAME_WIN" if payout else "GAME_LOSS", comment=f"{key}:{roll}"))
        s.add(GameRound(user_id=u.id, game=key, bet=value, roll_value=roll, payout=payout))
        await s.commit()
        final = Decimal(u.balance)
    await state.clear()
    if payout:
        await m.answer(f"🎉 <b>Выигрыш!</b>\nРезультат: {roll}\nВыплата: <b>{payout:.2f}</b>\nБаланс: <b>{final:.2f}</b>", parse_mode="HTML")
    else:
        await m.answer(f"😔 Результат: {roll}\nСтавка: {value:.2f}\nБаланс: <b>{final:.2f}</b>", parse_mode="HTML")


# =========================
# DEPOSIT
# =========================
@dp.message(F.text == "💳 Пополнить")
async def dep_start(m, state):
    await state.set_state(DepositState.amount)
    await m.answer("💳 Введите сумму пополнения:")


@dp.message(DepositState.amount)
async def dep_amount(m, state):
    value = await amount(m.text)
    if not value:
        return await m.answer("❌ Некорректная сумма.")
    if CRYPTO_PAY_TOKEN:
        inv = await crypto_invoice(m.from_user.id, value)
        if not inv:
            await state.clear()
            return await m.answer("❌ CryptoBot не смог создать счёт. Проверь токен.")
        async with Session() as s:
            d = Deposit(user_id=m.from_user.id, amount=value, asset=CRYPTO_PAY_ASSET,
                        provider="cryptobot", external_id=str(inv["invoice_id"]),
                        pay_url=inv.get("pay_url"))
            s.add(d)
            await s.commit()
            await s.refresh(d)
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="💳 Оплатить", url=inv.get("pay_url"))],
            [InlineKeyboardButton(text="🔄 Проверить", callback_data=f"dep:{d.id}")],
        ])
        await state.clear()
        return await m.answer(f"💳 Счёт на <b>{value:.2f} {CRYPTO_PAY_ASSET}</b> создан.", reply_markup=kb, parse_mode="HTML")
    async with Session() as s:
        d = Deposit(user_id=m.from_user.id, amount=value, asset="USDT", provider="manual")
        s.add(d); await s.commit(); await s.refresh(d)
    await state.clear()
    for aid in ADMIN_IDS:
        try:
            await bot.send_message(aid, f"💳 <b>Пополнение #{d.id}</b>\n👤 {m.from_user.id}\n💰 {value:.2f}",
                                   reply_markup=request_kb("dep", d.id), parse_mode="HTML")
        except Exception:
            pass
    await m.answer(f"✅ Заявка #{d.id} отправлена администратору.")


@dp.callback_query(F.data.startswith("dep:approve:"))
async def dep_admin_approve(c: CallbackQuery):
    did = int(c.data.split(":")[2])

    async with Session() as s:
        d = await s.get(Deposit, did)
        if not d:
            return await c.answer("Заявка не найдена.", show_alert=True)
        if d.credited:
            return await c.answer("Уже зачислено.", show_alert=True)

        u = await s.get(User, d.user_id, with_for_update=True)
        u.balance = Decimal(u.balance) + Decimal(d.amount)
        d.status = "paid"
        d.credited = True

        s.add(Transaction(
            user_id=u.id,
            amount=d.amount,
            type="MANUAL_DEPOSIT",
            comment=f"deposit #{did}"
        ))
        await s.commit()

    await c.answer("Зачислено!")
    await c.message.edit_reply_markup(reply_markup=None)
    await bot.send_message(
        d.user_id,
        f"✅ Пополнение #{did} подтверждено. Зачислено {Decimal(d.amount):.2f} USDT."
    )


@dp.callback_query(F.data.startswith("dep:reject:"))
async def dep_admin_reject(c: CallbackQuery):
    did = int(c.data.split(":")[2])

    async with Session() as s:
        d = await s.get(Deposit, did)
        if not d:
            return await c.answer("Заявка не найдена.", show_alert=True)
        if d.credited:
            return await c.answer("Уже зачислено.", show_alert=True)

        d.status = "rejected"
        await s.commit()

    await c.answer("Отклонено.")
    await c.message.edit_reply_markup(reply_markup=None)
    await bot.send_message(
        d.user_id,
        f"❌ Пополнение #{did} отклонено."
    )


@dp.callback_query(F.data.startswith("dep:"))
async def dep_check(c: CallbackQuery):
    did = int(c.data.split(":")[1])
    async with Session() as s:
        d = await s.get(Deposit, did)
    if not d or d.user_id != c.from_user.id:
        return await c.answer("Заявка не найдена.", show_alert=True)
    inv = await check_invoice(d.external_id) if d.provider == "cryptobot" else None
    if not inv or inv.get("status") != "paid":
        return await c.answer("Оплата пока не найдена.", show_alert=True)
    async with Session() as s:
        d = await s.get(Deposit, did)
        if d.credited:
            return await c.answer("Уже зачислено.", show_alert=True)
        u = await s.get(User, d.user_id, with_for_update=True)
        u.balance = Decimal(u.balance) + Decimal(d.amount)
        d.status = "paid"; d.credited = True
        s.add(Transaction(user_id=u.id, amount=d.amount, type="CRYPTO_DEPOSIT", comment=f"invoice {d.external_id}"))
        await s.commit()
    await c.answer("Зачислено!")
    await c.message.answer(f"✅ Зачислено: {Decimal(d.amount):.2f} {d.asset}")


# =========================
# WITHDRAW
# =========================
@dp.message(F.text == "💸 Вывести")
async def wd_start(m, state):
    u = await ensure_user(m)
    if Decimal(u.balance) <= 0:
        return await m.answer("💰 Недостаточно средств.")
    await state.set_state(WithdrawState.amount)
    await m.answer(f"💸 Доступно: {Decimal(u.balance):.2f}\nВведите сумму:")


@dp.message(WithdrawState.amount)
async def wd_amount(m, state):
    value = await amount(m.text)
    u = await ensure_user(m)
    if not value or value > Decimal(u.balance):
        return await m.answer("❌ Некорректная сумма или недостаточно средств.")
    await state.update_data(amount=str(value))
    await state.set_state(WithdrawState.destination)
    await m.answer("📤 Отправьте реквизит/адрес для вывода:")


@dp.message(WithdrawState.destination)
async def wd_destination(m, state):
    dest = (m.text or "").strip()
    data = await state.get_data()
    value = Decimal(data["amount"])
    async with Session() as s:
        u = await s.get(User, m.from_user.id, with_for_update=True)
        if not u or Decimal(u.balance) < value:
            await state.clear(); return await m.answer("❌ Недостаточно средств.")
        u.balance = Decimal(u.balance) - value
        s.add(Transaction(user_id=u.id, amount=-value, type="WITHDRAW_RESERVE", comment="withdrawal"))
        w = Withdrawal(user_id=u.id, amount=value, destination=dest)
        s.add(w); await s.commit(); await s.refresh(w)
    await state.clear()
    for aid in ADMIN_IDS:
        try:
            await bot.send_message(aid, f"💸 <b>Вывод #{w.id}</b>\n👤 {m.from_user.id}\n💰 {value:.2f}\n📤 <code>{dest}</code>",
                                   reply_markup=request_kb("wd", w.id), parse_mode="HTML")
        except Exception:
            pass
    await m.answer(f"✅ Заявка на вывод #{w.id} создана. Сумма зарезервирована.")


# =========================
# HISTORY
# =========================
@dp.message(F.text == "📜 История")
async def history(m):
    async with Session() as s:
        q = await s.execute(select(Transaction).where(Transaction.user_id == m.from_user.id).order_by(Transaction.id.desc()).limit(15))
        rows = q.scalars().all()
    if not rows:
        return await m.answer("📜 История пуста.")
    text = "📜 <b>Последние операции</b>\n\n"
    for x in rows:
        a = Decimal(x.amount)
        text += f"#{x.id} | {x.type} | {'+' if a >= 0 else ''}{a:.2f}\n"
    await m.answer(text, parse_mode="HTML")


# =========================
# DESIGN MENU EXTRAS
# =========================
@dp.message(F.text == "🎁 БОНУС")
async def bonus_menu(m):
    await m.answer(
        "🎁 <b>БОНУСЫ</b>\n\n"
        "Здесь можно подключить ежедневный бонус, промокоды и реферальную систему.\n\n"
        "🟢 Модуль подготовлен для дальнейшего расширения.",
        parse_mode="HTML", reply_markup=main_kb()
    )


@dp.message(F.text == "📊 СТАТИСТИКА")
async def user_stats_menu(m):
    async with Session() as s:
        games_n = await s.scalar(select(func.count(GameRound.id)).where(GameRound.user_id == m.from_user.id)) or 0
        turnover = await s.scalar(select(func.coalesce(func.sum(GameRound.bet), 0)).where(GameRound.user_id == m.from_user.id)) or 0
        wins = await s.scalar(select(func.coalesce(func.sum(GameRound.payout), 0)).where(GameRound.user_id == m.from_user.id)) or 0
    await m.answer(
        f"📊 <b>ТВОЯ СТАТИСТИКА</b>\n\n"
        f"🎮 Игр: <b>{games_n}</b>\n"
        f"💵 Оборот: <b>{Decimal(turnover):.2f} $</b>\n"
        f"🏆 Выплаты: <b>{Decimal(wins):.2f} $</b>",
        parse_mode="HTML", reply_markup=main_kb()
    )


@dp.message(F.text == "ℹ️ О ПРОЕКТЕ")
async def about_menu(m):
    await m.answer(
        "🟢 <b>PLAY BOT</b>\n\n"
        "🎮 Игры в Telegram\n"
        "💰 Управление балансом\n"
        "📊 Личная статистика\n"
        "🛡 Поддержка\n\n"
        "Тёмный интерфейс с неоново-зелёным стилем.",
        parse_mode="HTML", reply_markup=main_kb()
    )


@dp.message(F.text == "🆘 ПОДДЕРЖКА")
async def support_menu(m):
    await m.answer(
        "🆘 <b>ПОДДЕРЖКА</b>\n\n"
        "Опиши вопрос одним сообщением. Администратор сможет обработать обращение.",
        parse_mode="HTML", reply_markup=main_kb()
    )


@dp.message(F.text == "💰 КОШЕЛЁК")
async def wallet_menu(m):
    u = await ensure_user(m)
    kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="💳 Пополнить"), KeyboardButton(text="💸 Вывести")],
        [KeyboardButton(text="📜 История")],
        [KeyboardButton(text="🏠 Главное меню")],
    ], resize_keyboard=True)
    await m.answer(
        f"💰 <b>КОШЕЛЁК</b>\n\nТекущий баланс: <b>{Decimal(u.balance):.2f} $</b>\n\n"
        "Выберите операцию:", parse_mode="HTML", reply_markup=kb
    )


# =========================
# ADMIN
# =========================
@dp.message(Command("myid"))
async def myid(m: Message):
    await m.answer(f"🆔 Твой Telegram ID: <code>{m.from_user.id}</code>", parse_mode="HTML")


@dp.message(Command("admin"))
async def admin_cmd(m):
    if not admin(m.from_user.id):
        return await m.answer("⛔ Доступ запрещён.")
    await m.answer("👑 <b>Админ-панель</b>", reply_markup=admin_kb(), parse_mode="HTML")


@dp.message(F.text == "👥 Пользователи")
async def users(m):
    if not admin(m.from_user.id): return await m.answer("⛔ Доступ запрещён.")
    async with Session() as s:
        total = await s.scalar(select(func.count(User.id)))
        q = await s.execute(select(User).order_by(User.id.desc()).limit(20))
        rows = q.scalars().all()
    text = f"👥 <b>Пользователей: {total or 0}</b>\n\n"
    for u in rows:
        text += f"{'🚫' if u.is_blocked else '🟢'} <code>{u.id}</code> @{u.username or '-'} | {Decimal(u.balance):.2f}\n"
    await m.answer(text, parse_mode="HTML")


@dp.message(F.text == "📊 Статистика")
async def stats(m):
    if not admin(m.from_user.id): return await m.answer("⛔ Доступ запрещён.")
    async with Session() as s:
        users_n = await s.scalar(select(func.count(User.id)))
        games_n = await s.scalar(select(func.count(GameRound.id)))
        dep_n = await s.scalar(select(func.count(Deposit.id)))
        wd_n = await s.scalar(select(func.count(Withdrawal.id)))
        bal = await s.scalar(select(func.coalesce(func.sum(User.balance), 0)))
    await m.answer(f"📊 <b>Статистика</b>\n\n👥 {users_n or 0}\n🎮 Игр: {games_n or 0}\n💳 Пополнений: {dep_n or 0}\n💸 Выводов: {wd_n or 0}\n💰 Баланс: {Decimal(bal or 0):.2f}", parse_mode="HTML")


@dp.message(F.text == "💰 Управление балансом")
async def admin_bal_start(m, state):
    if not admin(m.from_user.id): return await m.answer("⛔ Доступ запрещён.")
    await state.set_state(AdminBalanceState.text)
    await m.answer("Отправь: <code>USER_ID SUMMA</code>\nНапример: <code>123456789 100</code>", parse_mode="HTML")


@dp.message(AdminBalanceState.text)
async def admin_bal(m, state):
    if not admin(m.from_user.id): return
    p = (m.text or "").split()
    if len(p) != 2: return await m.answer("❌ Формат: USER_ID SUMMA")
    try: uid, value = int(p[0]), Decimal(p[1].replace(",", "."))
    except (ValueError, InvalidOperation): return await m.answer("❌ Ошибка.")
    r = await change_balance(uid, value, "ADMIN_ADJUSTMENT", f"admin {m.from_user.id}")
    if r is None: return await m.answer("❌ Пользователь не найден или нельзя списать эту сумму.")
    await state.clear()
    await m.answer(f"✅ Баланс {uid}: {r:.2f}")


@dp.message(F.text == "💳 Пополнения")
async def admin_deps(m):
    if not admin(m.from_user.id): return await m.answer("⛔ Доступ запрещён.")
    async with Session() as s:
        q = await s.execute(select(Deposit).where(Deposit.status == "pending").order_by(Deposit.id.desc()).limit(10))
        rows = q.scalars().all()
    if not rows: return await m.answer("Нет ожидающих пополнений.")
    for d in rows:
        await m.answer(f"💳 <b>#{d.id}</b>\n👤 {d.user_id}\n💰 {Decimal(d.amount):.2f}\n🔌 {d.provider}",
                        reply_markup=request_kb("dep", d.id), parse_mode="HTML")


@dp.message(F.text == "💸 Выводы")
async def admin_wds(m):
    if not admin(m.from_user.id): return await m.answer("⛔ Доступ запрещён.")
    async with Session() as s:
        q = await s.execute(select(Withdrawal).where(Withdrawal.status == "pending").order_by(Withdrawal.id.desc()).limit(10))
        rows = q.scalars().all()
    if not rows: return await m.answer("Нет ожидающих выводов.")
    for w in rows:
        await m.answer(f"💸 <b>#{w.id}</b>\n👤 {w.user_id}\n💰 {Decimal(w.amount):.2f}\n📤 <code>{w.destination}</code>",
                        reply_markup=request_kb("wd", w.id), parse_mode="HTML")


@dp.callback_query(F.data.startswith("ok:") | F.data.startswith("no:"))
async def request_action(c: CallbackQuery):
    if not admin(c.from_user.id):
        return await c.answer("Нет доступа.", show_alert=True)
    action, kind, raw = c.data.split(":")
    rid = int(raw)
    async with Session() as s:
        if kind == "dep":
            row = await s.get(Deposit, rid)
            if not row or row.status != "pending":
                return await c.answer("Уже обработано.", show_alert=True)
            row.status = "approved" if action == "ok" else "rejected"
            if action == "ok":
                u = await s.get(User, row.user_id, with_for_update=True)
                u.balance = Decimal(u.balance) + Decimal(row.amount)
                s.add(Transaction(user_id=u.id, amount=row.amount, type="MANUAL_DEPOSIT", comment=f"deposit #{rid}"))
            uid, value = row.user_id, Decimal(row.amount)
        else:
            row = await s.get(Withdrawal, rid)
            if not row or row.status != "pending":
                return await c.answer("Уже обработано.", show_alert=True)
            row.status = "approved" if action == "ok" else "rejected"
            uid, value = row.user_id, Decimal(row.amount)
            if action == "no":
                u = await s.get(User, row.user_id, with_for_update=True)
                u.balance = Decimal(u.balance) + value
                s.add(Transaction(user_id=u.id, amount=value, type="WITHDRAW_REFUND", comment=f"withdrawal #{rid}"))
        await s.commit()
    await c.answer("Готово")
    try:
        await bot.send_message(uid, f"{'✅ Одобрена' if action == 'ok' else '❌ Отклонена'} заявка #{rid}\n💰 {value:.2f}")
    except Exception:
        pass
    await c.message.edit_reply_markup(reply_markup=None)


@dp.message(F.text == "⚙️ Настройки")
async def settings(m):
    if not admin(m.from_user.id): return await m.answer("⛔ Доступ запрещён.")
    mn, mx = await setting("min_bet", str(MIN_BET)), await setting("max_bet", str(MAX_BET))
    mt = await setting("maintenance", "0")
    await m.answer(f"⚙️ <b>Настройки</b>\n\n🔧 Техработы: {'ВКЛ' if mt == '1' else 'ВЫКЛ'}\n💵 Ставки: {mn} — {mx}\n\n"
                   f"<code>/maintenance on</code>\n<code>/maintenance off</code>\n<code>/setbet MIN MAX</code>\n"
                   f"<code>/block USER_ID</code>\n<code>/unblock USER_ID</code>", parse_mode="HTML")


@dp.message(Command("maintenance"))
async def maintenance_cmd(m):
    if not admin(m.from_user.id): return
    p = (m.text or "").split()
    if len(p) != 2 or p[1] not in ("on", "off"): return await m.answer("Используй /maintenance on или /maintenance off")
    await set_setting("maintenance", "1" if p[1] == "on" else "0")
    await m.answer("🔧 Готово.")


@dp.message(Command("setbet"))
async def setbet(m):
    if not admin(m.from_user.id): return
    p = (m.text or "").split()
    if len(p) != 3: return await m.answer("Используй /setbet MIN MAX")
    try: mn, mx = Decimal(p[1]), Decimal(p[2])
    except InvalidOperation: return await m.answer("❌ Ошибка.")
    if mn <= 0 or mx < mn: return await m.answer("❌ Проверь диапазон.")
    await set_setting("min_bet", str(mn)); await set_setting("max_bet", str(mx))
    await m.answer("✅ Лимиты изменены.")


@dp.message(Command("block"))
async def block(m):
    if not admin(m.from_user.id): return
    p = (m.text or "").split()
    if len(p) != 2: return await m.answer("/block USER_ID")
    async with Session() as s:
        u = await s.get(User, int(p[1]))
        if not u: return await m.answer("Не найден.")
        u.is_blocked = True; await s.commit()
    await m.answer("🚫 Заблокирован.")


@dp.message(Command("unblock"))
async def unblock(m):
    if not admin(m.from_user.id): return
    p = (m.text or "").split()
    if len(p) != 2: return await m.answer("/unblock USER_ID")
    async with Session() as s:
        u = await s.get(User, int(p[1]))
        if not u: return await m.answer("Не найден.")
        u.is_blocked = False; await s.commit()
    await m.answer("🟢 Разблокирован.")


@dp.message(F.text == "📢 Рассылка")
async def broadcast_start(m, state):
    if not admin(m.from_user.id): return await m.answer("⛔ Доступ запрещён.")
    await state.set_state(BroadcastState.text)
    await m.answer("Отправь текст рассылки.")


@dp.message(BroadcastState.text)
async def broadcast(m, state):
    if not admin(m.from_user.id): return
    text = m.text or ""
    async with Session() as s:
        q = await s.execute(select(User.id).where(User.is_blocked.is_(False)))
        ids = [x[0] for x in q.all()]
    sent = 0
    for uid in ids:
        try:
            await bot.send_message(uid, text); sent += 1
        except Exception:
            pass
        await asyncio.sleep(0.04)
    await state.clear()
    await m.answer(f"📢 Отправлено: {sent}/{len(ids)}")


@dp.message(Command("addbalance"))
async def legacy_addbalance(m):
    if not admin(m.from_user.id): return
    p = (m.text or "").split()
    if len(p) != 3: return await m.answer("/addbalance USER_ID SUMMA")
    try: uid, value = int(p[1]), Decimal(p[2].replace(",", "."))
    except (ValueError, InvalidOperation): return await m.answer("❌ Ошибка.")
    r = await change_balance(uid, value, "ADMIN_ADJUSTMENT", f"admin {m.from_user.id}")
    await m.answer("❌ Не удалось." if r is None else f"✅ Новый баланс: {r:.2f}")


@dp.message()
async def fallback(m):
    await m.answer("Выбери раздел кнопками ниже.", reply_markup=main_kb())


# =========================
# RUN
# =========================
async def main():
    if not BOT_TOKEN:
        raise RuntimeError("Не указан BOT_TOKEN в файле .env")
    if not ADMIN_IDS:
        log.warning("ADMIN_IDS пустой: админ-панель будет недоступна.")
    if "YOUR_POSTGRES_PASSWORD" in DATABASE_URL:
        raise RuntimeError("Не указан пароль PostgreSQL в .env")
    await tables()
    log.info("Database initialized")
    log.info("Bot started")
    worker = asyncio.create_task(crypto_worker())
    try:
        await dp.start_polling(bot)
    finally:
        worker.cancel()
        await bot.session.close()
        await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
