@echo off
cd /d C:\telegram_games_bot

if not exist venv\Scripts\activate.bat (
    echo ERROR: venv was not found.
    echo Run install.bat first.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
python bot.py
pause
