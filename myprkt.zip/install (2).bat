@echo off
cd /d C:\telegram_games_bot

if not exist venv (
    echo Creating virtual environment...
    py -m venv venv
    if errorlevel 1 (
        echo ERROR: Python launcher was not found.
        pause
        exit /b 1
    )
)

call venv\Scripts\activate.bat

echo Installing packages...
python -m pip install --upgrade pip
if errorlevel 1 (
    echo ERROR: pip upgrade failed.
    pause
    exit /b 1
)

pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: package installation failed.
    pause
    exit /b 1
)

echo Installation finished successfully.
echo Now create .env from .env.example and fill in your settings.
pause
