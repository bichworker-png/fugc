import asyncio
from sqlalchemy import text
from webapp import engine

async def main():
    if engine is None:
        raise RuntimeError("DATABASE_URL не найден в .env")

    async with engine.begin() as conn:
        # Добавляем/приводим структуру Coin Flip к версии v18.
        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ADD COLUMN IF NOT EXISTS chosen_side VARCHAR(8) NOT NULL DEFAULT 'hot'
        """))
        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ADD COLUMN IF NOT EXISTS step INTEGER NOT NULL DEFAULT 0
        """))
        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ADD COLUMN IF NOT EXISTS multiplier NUMERIC(12,4) NOT NULL DEFAULT 1.00
        """))
        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ADD COLUMN IF NOT EXISTS status VARCHAR(16) NOT NULL DEFAULT 'active'
        """))
        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ADD COLUMN IF NOT EXISTS payout NUMERIC(18,2) NOT NULL DEFAULT 0
        """))
        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ADD COLUMN IF NOT EXISTS history JSONB NOT NULL DEFAULT '[]'::jsonb
        """))
        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ADD COLUMN IF NOT EXISTS game_round_id BIGINT
        """))
        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        """))
        await conn.execute(text("""
            ALTER TABLE coinflip_rounds
            ADD COLUMN IF NOT EXISTS finished_at TIMESTAMPTZ
        """))
        await conn.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_coinflip_user_status
            ON coinflip_rounds(user_id, status)
        """))

        cols = (await conn.execute(text("""
            SELECT column_name
            FROM information_schema.columns
            WHERE table_name = 'coinflip_rounds'
            ORDER BY ordinal_position
        """))).scalars().all()

    print("COINFLIP DB FIX OK")
    print("Колонки coinflip_rounds:", ", ".join(cols))
    await engine.dispose()

if __name__ == "__main__":
    asyncio.run(main())
