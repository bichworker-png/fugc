const tg = window.Telegram?.WebApp;
if (tg) { try { tg.ready(); tg.expand(); } catch(e) {} }

async function api(url, options = {}) {
  const r = await fetch(url, options);
  const text = await r.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch(e) {}
  if (!r.ok) throw new Error(data.detail || data.error || `HTTP ${r.status}`);
  return data;
}

function getUser(d) {
  return d?.user || d?.profile || d?.data?.user || d?.data?.profile || null;
}

function money(v) {
  const n = Number(v ?? 0);
  return Number.isFinite(n) ? n.toFixed(2) : "0.00";
}

function alertUser(msg) {
  try { tg?.showAlert ? tg.showAlert(msg) : alert(msg); }
  catch(e) { alert(msg); }
}

async function load() {
  try {
    const d = await api("/api/me");
    const u = getUser(d);
    if (!u) throw new Error("Сервер не вернул данные профиля");

    const balance = u.balance ?? d.balance ?? 0;
    const el = document.querySelector("#balance");
    if (el) el.textContent = `$${money(balance)}`;

    const games = document.querySelector("#games");
    if (games && u.games !== undefined) games.textContent = u.games;

    const turnover = document.querySelector("#turnover");
    if (turnover && u.turnover !== undefined) turnover.textContent = `$${money(u.turnover)}`;

    const wins = document.querySelector("#wins");
    if (wins && u.wins !== undefined) wins.textContent = u.wins;
  } catch(e) {
    console.error("load:", e);
    alertUser(e.message);
  }
}

async function profile() {
  try {
    const d = await api("/api/me");
    const u = getUser(d);
    if (!u) throw new Error("Сервер не вернул данные профиля");

    const id = u.id ?? u.telegram_id ?? u.user_id ?? d.id ?? d.telegram_id ?? "—";
    const username = u.username ? `@${String(u.username).replace(/^@/,"")}` : "Без username";
    const name = u.first_name || u.name || "Игрок";
    const balance = u.balance ?? d.balance ?? 0;

    const set = (sel, val) => { const e = document.querySelector(sel); if (e) e.textContent = val; };
    set("#profileName", name);
    set("#profileUsername", username);
    set("#profileId", id);
    set("#profileBalance", `$${money(balance)}`);
    set("#profileGames", u.games ?? 0);
    set("#profileWins", u.wins ?? 0);
    set("#profileTurnover", `$${money(u.turnover ?? 0)}`);
  } catch(e) {
    console.error("profile:", e);
    alertUser(e.message);
  }
}

function showSection(name) {
  document.querySelectorAll("[data-section]").forEach(e => {
    e.style.display = e.dataset.section === name ? "" : "none";
  });
  document.querySelectorAll("[data-nav]").forEach(e => {
    e.classList.toggle("active", e.dataset.nav === name);
  });
  if (name === "profile") profile();
  if (name === "home") load();
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-nav]").forEach(e => {
    e.addEventListener("click", () => showSection(e.dataset.nav));
  });
  load();
});
