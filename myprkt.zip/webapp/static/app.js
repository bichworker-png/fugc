const tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;
if (tg) { tg.ready(); tg.expand(); }
const initData = tg ? (tg.initData || "") : "";

async function api(path, method="GET", body=null){
  const o={method,headers:{"Content-Type":"application/json","X-Telegram-Init-Data":initData}};
  if(body!==null)o.body=JSON.stringify(body);
  let lastErr=null;
  for(let attempt=0;attempt<3;attempt++){
    try{
      const r=await fetch(path,o);
      const d=await r.json().catch(()=>({error:"Ошибка сервера"}));
      if(!r.ok){
        let msg=d.error||"Ошибка сервера";
        if(Array.isArray(d.detail)) msg=d.detail.map(x=>x.msg||x.message||JSON.stringify(x)).join("; ");
        else if(d.detail) msg=typeof d.detail==="string"?d.detail:JSON.stringify(d.detail);
        if((r.status>=500 || r.status===502 || r.status===503 || r.status===504) && attempt<2){
          await new Promise(resolve=>setTimeout(resolve,350*(attempt+1)));
          continue;
        }
        throw new Error(msg);
      }
      return d;
    }catch(e){
      lastErr=e;
      if(attempt<2){await new Promise(resolve=>setTimeout(resolve,350*(attempt+1)));continue;}
    }
  }
  throw lastErr||new Error("Ошибка сервера");
}
function money(v){return "$"+Number(v||0).toFixed(2);}
function setText(id,v){const e=document.getElementById(id);if(e)e.textContent=v;}
function vipMarkup(vip, compact=false){
  const v=vip||{};
  const total=Number(v.total_deposits||0);
  const next=v.next_threshold==null?null:Number(v.next_threshold);
  const pct=Number(v.cashback_pct||0).toFixed(1).replace('.0','');
  const progress=next==null?100:Math.max(0,Math.min(100,(total/next)*100));
  const toNext=next==null?0:Math.max(0,next-total);
  return `<div class="vip-card${compact?' vip-compact':''}" id="vipCard${compact?'Activity':'Profile'}">
    <div class="vip-head"><div><div class="vip-caption">СТАТУС</div><div class="vip-name">${v.name||'👀 Зритель'}</div></div><div class="vip-cashback">КЭШБЕК <b>${pct}%</b></div></div>
    <div class="vip-line"><span>Пополнений</span><b>${money(total)}</b></div>
    ${next!=null?`<div class="vip-progress"><span style="width:${progress.toFixed(1)}%"></span></div><div class="vip-next">До следующего уровня: ${money(toNext)}</div>`:`<div class="vip-progress"><span style="width:100%"></span></div><div class="vip-next">Максимальный статус достигнут</div>`}
  </div>`;
}
function injectVipCard(sectionId, vip, compact=false){
  const section=document.getElementById(sectionId); if(!section)return;
  const id=compact?'vipCardActivity':'vipCardProfile';
  const old=document.getElementById(id); if(old)old.remove();
  section.insertAdjacentHTML('afterbegin',vipMarkup(vip,compact));
}
function ensureVipStyles(){
  if(document.getElementById('vipStyles'))return;
  const st=document.createElement('style'); st.id='vipStyles'; st.textContent=`.vip-card{margin:14px 0;padding:16px;border:1px solid #2b2b2b;border-radius:18px;background:linear-gradient(145deg,#121212,#0b0b0b);box-shadow:0 10px 30px rgba(0,0,0,.22)}.vip-head{display:flex;justify-content:space-between;gap:12px;align-items:center}.vip-caption{font-size:10px;letter-spacing:1.5px;color:#777}.vip-name{font-size:20px;font-weight:800;margin-top:3px}.vip-cashback{font-size:10px;color:#888;text-align:right}.vip-cashback b{display:block;color:#e8bb45;font-size:17px;margin-top:2px}.vip-line{display:flex;justify-content:space-between;margin-top:14px;color:#999;font-size:12px}.vip-line b{color:#fff}.vip-progress{height:6px;background:#222;border-radius:99px;overflow:hidden;margin-top:10px}.vip-progress span{display:block;height:100%;background:#e8bb45;border-radius:99px}.vip-next{font-size:10px;color:#666;margin-top:6px}.vip-compact{margin-bottom:12px}.vip-tiers-btn{width:100%;margin:2px 0 14px;padding:14px;border-radius:14px;border:1px solid #2b2b2b;background:#121212;color:#f2c35b;font-weight:800;font-size:14px}.vip-tiers-modal{padding:4px}.vip-tiers-title{font-size:22px;font-weight:900;margin-bottom:6px}.vip-tiers-sub{font-size:12px;color:#888;line-height:1.4;margin-bottom:14px}.vip-tier-row{display:flex;justify-content:space-between;align-items:center;padding:13px 4px;border-bottom:1px solid #242424}.vip-tier-last{border-bottom:0}.vip-tier-name{font-size:16px;font-weight:800}.vip-tier-threshold{font-size:11px;color:#777;margin-top:3px}.vip-tier-cb{text-align:right;font-size:17px;font-weight:900;color:#e8bb45}.vip-tier-cb span{display:block;font-size:9px;color:#777;font-weight:600}.vip-tiers-close{width:100%;margin-top:12px;padding:13px;border:0;border-radius:13px;background:#e8bb45;color:#111;font-weight:900}`; document.head.appendChild(st);
}
function applyVip(vip){
  ensureVipStyles();
  injectVipCard('profile',vip,false);
  injectVipCard('activity',vip,true);
  injectVipButton();
  hdInjectSettings();
}
function injectVipButton(){
  const section=document.getElementById('profile'); if(!section)return;
  let b=document.getElementById('vipTiersBtn');
  if(!b){
    b=document.createElement('button'); b.id='vipTiersBtn'; b.className='vip-tiers-btn';
    b.textContent='💎 Все VIP-статусы';
    b.onclick=showVipTiers;
    const vipCard=document.getElementById('vipCardProfile');
    if(vipCard && vipCard.parentElement===section) vipCard.insertAdjacentElement('afterend',b);
    else section.insertBefore(b, section.firstChild);
  }
}
async function showVipTiers(){
  try{
    const d=await api('/api/vip/tiers');
    const tiers=d.tiers||[];
    const rows=tiers.map((t,i)=>`<div class="vip-tier-row ${i===tiers.length-1?'vip-tier-last':''}">
      <div><div class="vip-tier-name">${t.name}</div><div class="vip-tier-threshold">от ${money(t.threshold)} пополнений</div></div>
      <div class="vip-tier-cb">${Number(t.cashback_pct).toFixed(1).replace('.0','')}%<span>кэшбэк</span></div>
    </div>`).join('');
    modal(`<div class="vip-tiers-modal"><div class="vip-tiers-title">💎 VIP-статусы</div><div class="vip-tiers-sub">Чем больше подтверждённых пополнений, тем выше статус и кэшбэк.</div>${rows}<button class="vip-tiers-close" onclick="closeModal()">ЗАКРЫТЬ</button></div>`);
  }catch(e){alert(e.message);}
}
function showSection(name){
  document.querySelectorAll(".section").forEach(s=>s.classList.remove("active"));
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.remove("active"));
  const s=document.getElementById(name), b=document.querySelector('.nav-btn[data-section="'+name+'"]');
  if(s)s.classList.add("active"); if(b)b.classList.add("active"); window.scrollTo(0,0);
  if(name==="profile")loadProfile(); if(name==="activity")load();
}
async function load(){
  try{const d=await api("/api/me"),u=d.user||{};
    setText("welcome","Привет, "+(u.first_name||"Игрок")+" 👋"); setText("homeWelcome","Добро пожаловать, "+(u.first_name||"Игрок")+"!");
    setText("balance",money(u.balance)); setText("profileId",u.id||"—"); setText("profileUsername",u.username?"@"+u.username:"—"); setText("profileName",u.first_name||"—"); setText("profileBalance",money(u.balance));
    applyVip(u.vip||{});
  }catch(e){console.error(e);}
}
function modal(x){const c=document.getElementById("content"),m=document.getElementById("modal");if(!c||!m)return;c.innerHTML=x;m.classList.remove("hidden");const fs=String(x).includes("rocket-wrap")||String(x).includes("game-fullscreen");m.classList.toggle("game-fullscreen",fs);if(fs){m.style.cssText="position:fixed;inset:0;width:100vw;height:100dvh;padding:0;margin:0;background:#000;display:block;z-index:9999;";}else{m.style.cssText="";}}
function closeModal(){const m=document.getElementById("modal");if(m){m.classList.add("hidden");m.classList.remove("game-fullscreen");m.style.cssText="";m.style.display="none";}try{if(tg&&tg.BackButton){tg.BackButton.hide();tg.BackButton.offClick(closeRocket);}}catch(e){}}
function closeRocket(){rocketStop();if(rocketState.stateTimer){clearInterval(rocketState.stateTimer);rocketState.stateTimer=null;}rocketState.roundId=null;rocketState.bet=0;rocketState.busy=false;closeModal();try{if(typeof load==='function')load();}catch(e){}}


// ===== HOT DICE PREMIUM SOUND + HAPTICS =====
const HD_PREFS_KEY="hotdice.preferences.v1";
const HD_DEFAULT_PREFS={sound:true,vibration:true};
function hdPrefs(){
  try{return Object.assign({},HD_DEFAULT_PREFS,JSON.parse(localStorage.getItem(HD_PREFS_KEY)||"{}"));}catch(e){return {...HD_DEFAULT_PREFS};}
}
function saveHdPrefs(p){localStorage.setItem(HD_PREFS_KEY,JSON.stringify(p));}
// Low-latency audio engine: decode once, play from AudioBuffer, keep HTMLAudio fallback.
const hdAudio={};
let hdAudioCtx=null;
let hdAudioBuffers={};
let hdAudioReady=false;
let hdAudioWarmStarted=false;

function hdGetAudioCtx(){
  if(hdAudioCtx)return hdAudioCtx;
  try{
    const C=window.AudioContext||window.webkitAudioContext;
    if(!C)return null;
    hdAudioCtx=new C({latencyHint:'interactive'});
  }catch(e){
    try{
      const C=window.AudioContext||window.webkitAudioContext;
      if(C)hdAudioCtx=new C();
    }catch(e2){}
  }
  return hdAudioCtx;
}

async function hdWarmAudio(){
  if(hdAudioWarmStarted)return;
  hdAudioWarmStarted=true;
  const ctx=hdGetAudioCtx();
  if(!ctx)return;
  try{if(ctx.state==='suspended')await ctx.resume();}catch(e){}
  const files=['click','win','loss','cashout','step','flip'];
  await Promise.all(files.map(async name=>{
    try{
      if(hdAudioBuffers[name])return;
      const r=await fetch('/static/audio/'+name+'.wav',{cache:'force-cache'});
      const b=await r.arrayBuffer();
      const decoded=await ctx.decodeAudioData(b);
      hdAudioBuffers[name]=decoded;
    }catch(e){}
  }));
  hdAudioReady=true;
}

function hdAudioFallback(name,volume){
  try{
    let a=hdAudio[name];
    if(!a){a=new Audio('/static/audio/'+name+'.wav');a.preload='auto';a.load();hdAudio[name]=a;}
    a.currentTime=0;
    a.volume=Math.max(0,Math.min(1,volume));
    const q=a.play(); if(q&&q.catch)q.catch(()=>{});
  }catch(e){}
}

function hdAudioPlay(name, volume=0.32){
  const p=hdPrefs(); if(!p.sound)return;
  try{
    const ctx=hdGetAudioCtx();
    const buffer=hdAudioBuffers[name];
    if(ctx&&buffer){
      if(ctx.state==='suspended')ctx.resume().catch(()=>{});
      const src=ctx.createBufferSource();
      const gain=ctx.createGain();
      gain.gain.value=Math.max(0,Math.min(1,volume));
      src.buffer=buffer;
      src.connect(gain);
      gain.connect(ctx.destination);
      src.start(0);
      return;
    }
  }catch(e){}
  hdAudioFallback(name,volume);
}

// Start decoding in the background so the first real game action is not delayed.
try{
  window.addEventListener('load',()=>{hdWarmAudio();},{once:true,passive:true});
  document.addEventListener('pointerdown',()=>{hdWarmAudio();},{once:true,passive:true});
  document.addEventListener('touchstart',()=>{hdWarmAudio();},{once:true,passive:true});
}catch(e){}
function hdVibrate(pattern=18){
  const p=hdPrefs(); if(!p.vibration)return;
  try{
    if(tg && tg.HapticFeedback){
      if(Array.isArray(pattern) && pattern.length>1) tg.HapticFeedback.impactOccurred('medium');
      else tg.HapticFeedback.impactOccurred('light');
    }
  }catch(e){}
  try{if(navigator.vibrate) navigator.vibrate(pattern);}catch(e){}
}
function hdFx(name, vibration=18, volume=.32){hdAudioPlay(name,volume);hdVibrate(vibration);}
function hdSoundToggle(){const p=hdPrefs();p.sound=!p.sound;saveHdPrefs(p);hdRenderSettings();if(p.sound)hdFx('click',12,.2);}
function hdVibrationToggle(){const p=hdPrefs();p.vibration=!p.vibration;saveHdPrefs(p);hdRenderSettings();if(p.vibration)hdVibrate(12);}
function hdRenderSettings(){
  const box=document.getElementById('hdSettingsBox'); if(!box)return;
  const p=hdPrefs();
  box.innerHTML=`<div class="hd-setting-row"><div><b>🔊 Звуки</b><small>Победа, проигрыш, забрать и игровые эффекты</small></div><button class="hd-toggle ${p.sound?'on':''}" onclick="hdSoundToggle()">${p.sound?'ВКЛ':'ВЫКЛ'}</button></div>
  <div class="hd-setting-row"><div><b>📳 Вибрации</b><small>Лёгкая тактильная отдача при действиях</small></div><button class="hd-toggle ${p.vibration?'on':''}" onclick="hdVibrationToggle()">${p.vibration?'ВКЛ':'ВЫКЛ'}</button></div>`;
}
function hdOpenSettings(){
  hdRenderSettings();
  const b=document.getElementById('hdSettingsBox');
  if(b)b.classList.toggle('hidden');
  hdFx('click',10,.18);
}
function hdInjectSettings(){
  if(document.getElementById('hdSettingsCard'))return;
  const section=document.getElementById('profile'); if(!section)return;
  const card=document.createElement('div');card.id='hdSettingsCard';card.className='hd-settings-card';
  card.innerHTML=`<button class="hd-settings-head" onclick="hdOpenSettings()"><span>⚙️ НАСТРОЙКИ</span><span>›</span></button><div id="hdSettingsBox" class="hd-settings-box hidden"></div>`;
  section.appendChild(card);
  hdRenderSettings();
}
function hdGameChoiceFx(){hdFx('click',12,.18);}
function hdGameWinFx(){hdFx('win',28,.28);}
function hdGameLossFx(){hdFx('loss',35,.24);}
function hdCashoutFx(){hdFx('cashout',[18,24],.34);}
function hdCoinFlipStepFx(){hdFx('step',24,.28);}
function hdCoinFlipFlipFx(){hdAudioPlay('flip',.12);hdVibrate(14);}
hdInjectSettings();

const GAME_OPTIONS={
 dice:[['higher','Больше 3'],['lower','Меньше 4'],['even','Чётное'],['odd','Нечётное'],...Array.from({length:6},(_,i)=>['exact:'+(i+1),'Число '+(i+1)])],
 bowling:[['strike','🎳 Страйк'],['miss','❌ Мимо'],... [2,3,4,5].map(n=>['pins:'+n,n+' кеглей'])],
 darts:[['bullseye','🎯 Яблочко'],['hit','📍 Любое место'],['miss','❌ Мимо']],
 football:[['goal','⚽ В ворота'],['miss','❌ Мимо ворот'],['corner','📐 В угол'],['post','🥅 От штанги']],
 basketball:[['clean','🏀 Чистый'],['stuck','🟠 Застрянет'],['miss','❌ Промах']]
};
const GAME_NAMES={dice:'🎲 Кубик',bowling:'🎳 Боулинг',darts:'🎯 Дартс',football:'⚽ Футбол',basketball:'🏀 Баскетбол'};

// ===== 🪙 COIN FLIP =====
const CF_MULTS=[1.90,3.61,6.86,13.03,24.76,47.04,89.38,169.82];
const cfState={roundId:null,bet:0,side:null,step:0,multiplier:1,history:[],busy:false};
function coinflipStyles(){
  if(document.getElementById('coinflipStyles'))return;
  const st=document.createElement('style');st.id='coinflipStyles';st.textContent=`
  .cf-wrap{padding:2px 0 8px}.cf-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}.cf-title{font-size:24px;font-weight:900;letter-spacing:.4px}.cf-bal{font-size:12px;color:#999}.cf-sub{font-size:11px;color:#777;text-align:center;margin:0 0 12px}
  .cf-coin-stage{height:190px;display:flex;align-items:center;justify-content:center;perspective:900px}.cf-coin{width:142px;height:142px;position:relative;transform-style:preserve-3d;transition:transform .45s cubic-bezier(.2,.75,.2,1);filter:drop-shadow(0 16px 22px rgba(0,0,0,.42))}.cf-coin.flipping{animation:cfSpin .9s cubic-bezier(.15,.7,.2,1)}
  .cf-face{position:absolute;inset:0;border-radius:50%;backface-visibility:hidden;display:flex;align-items:center;justify-content:center;border:5px solid #a8791e;background:radial-gradient(circle at 35% 28%,#f9dc77,#d9a52f 45%,#8c5c0c);box-shadow:inset 0 0 0 4px rgba(255,255,255,.16),inset 0 -16px 25px rgba(80,45,0,.25)}.cf-face span{width:105px;height:105px;border:2px solid rgba(80,45,0,.38);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:25px;font-weight:1000;color:#241704;letter-spacing:2px}.cf-back{transform:rotateY(180deg)}
  @keyframes cfSpin{0%{transform:rotateY(0deg) scale(1)}50%{transform:rotateY(900deg) scale(1.08)}100%{transform:rotateY(1800deg) scale(1)}}
  .cf-side-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin:4px 0 12px}.cf-side{padding:13px;border-radius:14px;border:1px solid #292929;background:#111;color:#aaa;font-weight:900}.cf-side.active{background:#e8bb45;color:#111;border-color:#e8bb45;box-shadow:0 8px 22px rgba(232,187,69,.12)}
  .cf-mults{display:flex;gap:6px;overflow:auto;padding:3px 0 10px;scrollbar-width:none}.cf-mult{min-width:58px;padding:8px 6px;text-align:center;border-radius:10px;border:1px solid #252525;background:#101010;color:#777;font-size:10px;font-weight:900}.cf-mult.active{border-color:#a8791e;color:#e8bb45;background:#17130a}.cf-mult.done{color:#d9d9d9;border-color:#343434}.cf-label{font-size:9px;color:#777;letter-spacing:1.3px;margin:6px 0}.cf-current{text-align:center;font-size:31px;font-weight:1000;color:#e8bb45;margin:5px 0 12px}.cf-history{display:flex;gap:6px;justify-content:center;min-height:28px;margin:4px 0 12px}.cf-dot{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:900;border:1px solid #303030;background:#141414;color:#aaa}.cf-dot.ok{background:#18180f;color:#e8bb45;border-color:#70551c}.cf-dot.bad{background:#211313;color:#e77777;border-color:#6b2929}.cf-note{text-align:center;color:#777;font-size:10px;line-height:1.35;margin:8px 0 12px}
  .cf-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px}.cf-main{width:100%;padding:14px;border:0;border-radius:14px;background:#e8bb45;color:#111;font-weight:1000}.cf-cash{width:100%;padding:14px;border:1px solid #8f6a21;border-radius:14px;background:#15120b;color:#e8bb45;font-weight:1000}.cf-result{padding:11px;border-radius:13px;background:#101010;border:1px solid #252525;text-align:center;margin-bottom:10px}.cf-result b{display:block;font-size:18px;margin-top:3px}.cf-win{color:#e8bb45}.cf-loss{color:#e77777}`;document.head.appendChild(st);
}
function cfSideLabel(side){return side==='hot'?'HOT':'DICE';}
function cfRenderMults(){return CF_MULTS.map((m,i)=>`<div class="cf-mult ${i+1<=cfState.step?'done':''} ${i+1===cfState.step+1?'active':''}">${i+1}<br><b>×${m.toFixed(2)}</b></div>`).join('');}
function cfRenderHistory(){return cfState.history.map(x=>`<div class="cf-dot ${x.correct?'ok':'bad'}">${x.result==='hot'?'H':'D'}</div>`).join('');}
function cfCoin(result=null){const rot=result==='dice'?'transform:rotateY(180deg)':'';return `<div class="cf-coin-stage"><div id="cfCoin" class="cf-coin" style="${rot}"><div class="cf-face cf-front"><span>HOT</span></div><div class="cf-face cf-back"><span>DICE</span></div></div></div>`;}
function openCoinFlip(){
  coinflipStyles();cfState.roundId=null;cfState.bet=0;cfState.side=null;cfState.step=0;cfState.multiplier=1;cfState.history=[];cfState.busy=false;
  modal(`<div class="cf-wrap"><div class="cf-head"><div class="cf-title">🪙 COIN FLIP</div><div class="cf-bal" id="cfBalance">Баланс: —</div></div><p class="cf-sub">HOT — решка · DICE — орёл</p>${cfCoin()}<div class="cf-side-grid"><button id="cfHot" class="cf-side" onclick="cfChoose('hot')">🔥 HOT</button><button id="cfDice" class="cf-side" onclick="cfChoose('dice')">💎 DICE</button></div><div class="cf-label">КОЭФФИЦИЕНТ ЗА ШАГ</div><div class="cf-mults">${cfRenderMults()}</div><input id="cfBet" class="input" type="number" min="1" max="100000" step="0.01" placeholder="Ставка, USDT"><button id="cfStart" class="cf-main" disabled onclick="cfStart()">🪙 НАЧАТЬ ИГРУ</button><div class="cf-note">После правильного шага можно продолжить или забрать выигрыш.</div></div>`);
  api('/api/coinflip/active').then(d=>{setText('cfBalance',`Баланс: ${money(d.balance)}`);if(d.active)cfResume(d);}).catch(()=>{});
}
function cfChoose(side){cfState.side=side;document.querySelectorAll('.cf-side').forEach(b=>b.classList.remove('active'));const b=document.getElementById(side==='hot'?'cfHot':'cfDice');if(b)b.classList.add('active');const s=document.getElementById('cfStart');if(s)s.disabled=false;hdGameChoiceFx();}
function cfResume(d){cfState.roundId=d.round_id;cfState.bet=Number(d.bet);cfState.side=d.side;cfState.step=Number(d.step);cfState.multiplier=Number(d.multiplier);cfState.history=d.history||[];cfRenderActive(Number(d.balance));}
async function cfStart(){try{const bet=Number(document.getElementById('cfBet')?.value||0);if(!cfState.side)throw new Error('Выберите HOT или DICE');if(!Number.isFinite(bet)||bet<=0)throw new Error('Введите корректную ставку');if(bet>100000)throw new Error('Максимальная ставка: 100000 USDT');const d=await api('/api/coinflip/start','POST',{bet,side:cfState.side});cfState.roundId=d.round_id;cfState.bet=Number(d.bet);cfState.step=0;cfState.multiplier=1;cfState.history=[];hdFx('click',12,.18);cfRenderActive(Number(d.balance));}catch(e){alert(e.message)}}
function cfRenderActive(balance,result=null){coinflipStyles();const side=cfState.side;modal(`<div class="cf-wrap"><div class="cf-head"><div class="cf-title">🪙 COIN FLIP</div><div class="cf-bal">Баланс: ${money(balance)}</div></div><p class="cf-sub">Ставка: <b>$${cfState.bet.toFixed(2)}</b> · выбирай сторону перед каждым броском</p>${cfCoin(result)}<div class="cf-side-grid"><button id="cfHot" class="cf-side ${side==='hot'?'active':''}" onclick="cfChoose('hot')">🔥 HOT</button><button id="cfDice" class="cf-side ${side==='dice'?'active':''}" onclick="cfChoose('dice')">💎 DICE</button></div><div class="cf-current">×${cfState.multiplier.toFixed(2)}</div><div class="cf-mults">${cfRenderMults()}</div><div class="cf-history">${cfRenderHistory()}</div><div id="cfResult" class="cf-result">${result?`Выпало: <b>${cfSideLabel(result)}</b>`:'Выбери сторону и подбрось монету'}</div><div class="cf-actions"><button id="cfFlipBtn" class="cf-main" onclick="cfStep()">🪙 ПОДБРОСИТЬ</button><button id="cfCashBtn" class="cf-cash" onclick="cfCashout()" ${cfState.step<1?'disabled':''}>💰 ЗАБРАТЬ</button></div><div class="cf-note">Каждый бросок случайный. После результата можно выбрать HOT или DICE заново.</div></div>`);}
async function cfStep(){if(!cfState.roundId||cfState.busy)return;cfState.busy=true;const btn=document.getElementById('cfFlipBtn');if(btn)btn.disabled=true;hdCoinFlipFlipFx();const coin=document.getElementById('cfCoin');if(coin)coin.classList.add('flipping');try{const d=await api('/api/coinflip/step','POST',{round_id:cfState.roundId,side:cfState.side});await new Promise(r=>setTimeout(r,650));cfState.step=Number(d.step);cfState.multiplier=Number(d.multiplier||1);cfState.history=d.history||cfState.history;setText('cfBalance',`Баланс: ${money(d.balance)}`);if(d.status==='lost'){hdGameLossFx();cfState.busy=false;modal(`<div class="cf-wrap"><div class="cf-head"><div class="cf-title">🪙 COIN FLIP</div><div class="cf-bal">Баланс: ${money(d.balance)}</div></div>${cfCoin()}<div class="cf-result cf-loss">❌ ПОРАЖЕНИЕ<b>Выпало: ${cfSideLabel(d.result)}</b><small>Кэшбэк: ${money(d.cashback||0)}</small></div><button class="cf-main" onclick="closeModal();load()">ПРОДОЛЖИТЬ</button></div>`);return;}if(d.status==='won'){hdGameWinFx();modal(`<div class="cf-wrap"><div class="cf-head"><div class="cf-title">🪙 COIN FLIP</div><div class="cf-bal">Баланс: ${money(d.balance)}</div></div>${cfCoin()}<div class="cf-result cf-win">🏆 МАКСИМАЛЬНЫЙ ШАГ<b>Выигрыш: ${money(d.payout)}</b></div><button class="cf-main" onclick="closeModal();load()">ЗАВЕРШИТЬ</button></div>`);return;}hdCoinFlipStepFx();cfRenderActive(Number(d.balance),d.result);const r=document.getElementById('cfResult');if(r)r.innerHTML=`✅ Выпало: <b>${cfSideLabel(d.result)}</b><br><small>Шаг ${d.step} · коэффициент ×${Number(d.multiplier).toFixed(2)}</small>`;}catch(e){alert(e.message)}finally{cfState.busy=false;}}
async function cfCashout(){if(!cfState.roundId||cfState.step<1||cfState.busy)return;cfState.busy=true;hdCashoutFx();try{const d=await api('/api/coinflip/cashout','POST',{round_id:cfState.roundId});modal(`<div class="cf-wrap"><div class="cf-head"><div class="cf-title">🪙 COIN FLIP</div><div class="cf-bal">Баланс: ${money(d.balance)}</div></div>${cfCoin()}<div class="cf-result cf-win">💰 ВЫИГРЫШ ЗАБРАН<b>${money(d.payout)}</b><small>Шаг ${d.step} · ×${Number(d.multiplier).toFixed(2)}</small></div><button class="cf-main" onclick="closeModal();load()">ПРОДОЛЖИТЬ</button></div>`);}catch(e){alert(e.message)}finally{cfState.busy=false;}}


function play(game){
  const options=GAME_OPTIONS[game]||[];
  const buttons=options.map(([v,l])=>`<button class="choice-btn" onclick="selectChoice('${game}','${v}',this)">${l}</button>`).join('');
  modal(`<div class="title">${GAME_NAMES[game]||'Игра'}</div><p class="hint">Сначала выбери исход, затем сумму ставки.</p><div id="choiceGrid" class="choice-grid">${buttons}</div><input id="bet" class="input" type="number" min="1" step="0.01" placeholder="Ставка, USDT"><div id="selectedChoice" class="selected-choice">Исход не выбран</div><button id="playButton" class="wide" disabled onclick="sendGame('${game}')">🎮 ИГРАТЬ</button>`);
}
function selectChoice(game,value,button){
  hdGameChoiceFx();
  document.querySelectorAll('.choice-btn').forEach(b=>b.classList.remove('selected')); button.classList.add('selected');
  const box=document.getElementById('selectedChoice'); if(box)box.textContent='Выбрано: '+button.textContent;
  const playBtn=document.getElementById('playButton'); if(playBtn){playBtn.disabled=false;playBtn.dataset.choice=value;playBtn.dataset.game=game;}
}
async function sendGame(game){
  try{
    const btn=document.getElementById('playButton'); const choice=btn&&btn.dataset.choice;
    const amount=Number(document.getElementById('bet')?.value||0);
    if(!choice)throw new Error('Выберите исход'); if(!Number.isFinite(amount)||amount<=0)throw new Error('Введите корректную ставку');
    btn.disabled=true; hdFx('click',16,.18); btn.textContent=game==='bowling'?'🎳 БРОСОК...':(game==='darts'?'🎯 БРОСОК...':(game==='football'?'⚽ УДАР...':(game==='basketball'?'🏀 БРОСОК...':'🎲 БРОСОК...')));
    const data=await api('/api/game','POST',{game,bet:amount,choice});
    data.win?hdGameWinFx():hdGameLossFx();
    modal(`<div class="title">${data.game_name||GAME_NAMES[game]}</div><div class="roll-animation">${data.emoji||'🎲'}</div><div class="result ${data.win?'win':'lose'}">${data.win?'🎉 ПОБЕДА':'😔 ПОРАЖЕНИЕ'}</div><div class="result-info"><b>Исход:</b> ${data.outcome}<br><b>Ставка:</b> ${data.choice}<br><b>Выигрыш:</b> ${money(data.payout)}</div><p class="hint" style="text-align:center">${data.message||''}</p><button class="wide" onclick="closeModal();load()">ПРОДОЛЖИТЬ</button>`);
    if(tg&&tg.HapticFeedback)tg.HapticFeedback.notificationOccurred(data.win?'success':'error');
  }catch(e){alert(e.message);const b=document.getElementById('playButton');if(b)b.disabled=false;}
}
const BANKS=[
 ['bank_sber','Сбер','SBER'],['bank_vtb','ВТБ','VTB'],['bank_gazprombank','Газпромбанк','GPB'],['bank_alfa','Альфа-Банк','ALFA'],['bank_psb','ПСБ','PSB'],['bank_rshb','Россельхозбанк','RSHB'],['bank_mkb','МКБ','MKB'],['bank_tbank','Т-Банк','T'],['bank_sovcombank','Совкомбанк','SK'],['bank_domrf','Банк ДОМ.РФ','DOM']
];
function payLogo(kind,label){return `<span class="pay-logo ${kind}">${label}</span>`;}
function paymentRows(items){return items.map(([v,n,l])=>`<button class="pay-row" onclick="chooseDepositProvider('${v}','${n}')">${payLogo(v.startsWith('bank_')?'bank':'crypto',l)}<span><b>${n}</b><small>Выбрать способ</small></span><span class="pay-arrow">›</span></button>`).join('');}
async function apiForm(path, form){
  const r=await fetch(path,{method:"POST",headers:{"X-Telegram-Init-Data":initData},body:form});
  const d=await r.json().catch(()=>({detail:"Ошибка сервера"}));
  if(!r.ok) throw new Error(d.detail||d.error||"Ошибка сервера");
  return d;
}
function deposit(){modal(`<style>
.pay-sheet{display:flex;flex-direction:column;gap:12px}.pay-stage{animation:paySlide .22s ease}.pay-back{background:transparent;border:0;color:#aaa;text-align:left;padding:4px 0;font-size:14px}.pay-list{display:flex;flex-direction:column;gap:8px;max-height:48vh;overflow:auto;padding-right:2px}.pay-row{display:flex;align-items:center;gap:12px;width:100%;padding:12px;border:1px solid #252525;border-radius:14px;background:#111;color:#fff;text-align:left}.pay-row:active{transform:scale(.99)}.pay-row span:nth-child(2){flex:1}.pay-row small{display:block;color:#777;margin-top:3px}.pay-arrow{color:#777;font-size:24px}.pay-logo{width:34px;height:34px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;background:#222;border:1px solid #333;flex:none}.pay-logo.crypto{font-size:15px}.pay-logo.bank{font-size:8px}.pay-amount{margin-top:4px}.qr-box{text-align:center;background:#fff;border-radius:16px;padding:14px;margin:12px auto;max-width:280px}.qr-box img{display:block;width:100%;height:auto}.pay-ok{font-size:18px;font-weight:800;text-align:center;margin:8px 0}.pay-muted{color:#888;text-align:center;font-size:13px}.details-box{white-space:pre-wrap;background:#111;border:1px solid #292929;border-radius:14px;padding:12px;color:#ddd;line-height:1.5;font-size:14px}.pay-actions{display:flex;gap:8px;flex-direction:column}.receipt-label{display:block;border:1px dashed #555;border-radius:14px;padding:14px;text-align:center;color:#ccc}.receipt-label input{display:none}@keyframes paySlide{from{opacity:0;transform:translateX(24px)}to{opacity:1;transform:none}}
</style><div class="pay-sheet"><div class="title">💳 Пополнение</div><div id="payStage" class="pay-stage"><p class="hint">Выбери способ оплаты.</p><div class="pay-list"><button class="pay-row" onclick="showManualPay('sbp')">${payLogo('bank','СБП')}<span><b>СБП</b><small>Перевод по реквизитам + чек</small></span><span class="pay-arrow">›</span></button><button class="pay-row" onclick="showManualPay('card')">${payLogo('bank','CARD')}<span><b>Банковская карта</b><small>Перевод по реквизитам + чек</small></span><span class="pay-arrow">›</span></button><button class="pay-row" onclick="chooseDepositProvider('cryptobot','CryptoBot')">${payLogo('crypto','CB')}<span><b>CryptoBot</b><small>USDT / автоматическое зачисление</small></span><span class="pay-arrow">›</span></button><button class="pay-row" onclick="chooseDepositProvider('xrocket','X Rocket')">${payLogo('crypto','XR')}<span><b>X Rocket</b><small>USDT / автоматическое зачисление</small></span><span class="pay-arrow">›</span></button></div></div></div>`);}
async function showManualPay(method){const st=document.getElementById('payStage');if(!st)return;const title=method==='sbp'?'СБП':'Банковская карта';let rateText='Курс: загружаем…';try{const r=await api('/api/payment/manual/rate');rateText=`Курс: 1 USDT ≈ ${Number(r.rate).toFixed(2)} ₽`;if(Number(r.markdown_pct)>0)rateText+=` · -${Number(r.markdown_pct).toFixed(2)}% от курса CryptoBot`;}catch(e){rateText='Курс временно недоступен';}st.innerHTML=`<button class="pay-back" onclick="deposit()">‹ Назад</button><p class="hint">Способ: <b>${title}</b><br>Сумма указывается в рублях.</p><div id="manualRate" class="pay-muted">${rateText}</div><input id="manualAmount" class="input pay-amount" type="number" min="100" step="1" placeholder="Сумма, ₽"><div id="manualUsdtPreview" class="pay-muted">Введите сумму</div><button class="wide" onclick="createManualDeposit('${method}')">ПОКАЗАТЬ РЕКВИЗИТЫ</button>`;const inp=document.getElementById('manualAmount');if(inp)inp.addEventListener('input',updateManualPreview);}
async function updateManualPreview(){const inp=document.getElementById('manualAmount');const out=document.getElementById('manualUsdtPreview');if(!inp||!out)return;const rub=Number(inp.value||0);if(rub<=0){out.textContent='Введите сумму';return;}try{const r=await api('/api/payment/manual/rate');out.textContent=`К зачислению после проверки: ≈ ${(rub/Number(r.rate)).toFixed(2)} USDT`;}catch(e){out.textContent='Курс временно недоступен';}}
async function createManualDeposit(method){try{const amount=Number(document.getElementById('manualAmount')?.value||0);if(!Number.isFinite(amount)||amount<100)throw new Error('Минимум 100 ₽');const d=await api('/api/payment/manual/create','POST',{amount,provider:method});const st=document.getElementById('payStage');if(!st)return;const qr=d.qr_url?`<div class="qr-box"><img src="${d.qr_url}" alt="QR СБП"></div>`:'';st.innerHTML=`<button class="pay-back" onclick="deposit()">‹ Назад</button><div class="pay-ok">Заявка #${d.id}</div><p class="pay-muted">Переведи <b>${Number(d.rub).toFixed(2)} ₽</b> → после проверки тебе будет зачислено <b>${Number(d.usdt).toFixed(2)} USDT</b>.</p><p class="pay-muted">Курс: <b>1 USDT ≈ ${Number(d.rate).toFixed(2)} ₽</b></p><div class="details-box"><b>${escapeHtml(d.name||'Реквизиты')}</b>
${escapeHtml(d.details||'Реквизиты пока не указаны.')}</div>${qr}<p class="pay-muted">${escapeHtml(d.note||'После перевода отправь чек.')}</p><label id="receiptLabel" class="receipt-label">📎 Выбрать чек<input id="manualReceipt" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onchange="receiptSelected(this)"></label><button id="sendReceiptBtn" class="wide" disabled onclick="sendManualReceipt(${d.id})">ОТПРАВИТЬ ЧЕК</button><div id="manualStatus" class="pay-muted">Чек ещё не выбран.</div>`;pollManual(d.id);}catch(e){alert(e.message);}}
function receiptSelected(input){const label=document.getElementById('receiptLabel');const btn=document.getElementById('sendReceiptBtn');const status=document.getElementById('manualStatus');const f=input?.files?.[0];if(!f){if(label)label.firstChild.textContent='📎 Выбрать чек';if(btn)btn.disabled=true;return;}if(label)label.firstChild.textContent='✅ '+f.name;if(btn)btn.disabled=false;if(status)status.textContent='Чек выбран. Нажми «ОТПРАВИТЬ ЧЕК».';}
function showPaymentSuccess(){const m=document.getElementById('modal');if(!m)return;m.classList.remove('hidden');m.innerHTML=`<div style="position:fixed;inset:0;background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;padding:24px;z-index:9999"><div style="width:min(420px,100%);background:#111;border:1px solid #333;border-radius:22px;padding:28px;text-align:center;box-shadow:0 20px 80px rgba(0,0,0,.6)"><div style="font-size:48px">✅</div><div style="font-size:22px;font-weight:800;margin:10px 0">Чек отправлен</div><div style="color:#aaa;line-height:1.5">Ожидайте сообщения в боте после проверки оплаты.</div></div></div>`;setTimeout(()=>{closeModal();load();},1800);}
async function sendManualReceipt(id){const btn=document.getElementById('sendReceiptBtn');try{const f=document.getElementById('manualReceipt')?.files?.[0];if(!f)throw new Error('Выбери чек');if(btn){btn.disabled=true;btn.textContent='ОТПРАВЛЯЕМ…';}const fd=new FormData();fd.append('receipt',f);await apiForm('/api/payment/manual/'+id+'/receipt',fd);showPaymentSuccess();}catch(e){if(btn){btn.disabled=false;btn.textContent='ОТПРАВИТЬ ЧЕК';}alert(e.message);}}
async function pollManual(id){let tries=0;const timer=setInterval(async()=>{tries++;try{const d=await api('/api/payment/manual/status/'+id);if(d.credited){clearInterval(timer);load();return;}if(d.status==='rejected'){clearInterval(timer);return;}}catch(e){}if(tries>=200)clearInterval(timer);},3000);}
function chooseDepositProvider(provider,name){const st=document.getElementById('payStage');if(!st)return;st.innerHTML=`<button class="pay-back" onclick="deposit()">‹ Назад</button><p class="hint">Выбрано: <b>${name}</b></p><input id="amount" class="input pay-amount" type="number" min="0.01" step="0.01" placeholder="Сумма, USDT"><button class="wide" onclick="createDeposit('${provider}')">СОЗДАТЬ СЧЁТ</button>`;}
async function createDeposit(provider){try{const amount=Number(document.getElementById('amount')?.value||0);if(amount<=0)throw new Error('Введите корректную сумму');const d=await api('/api/payment/crypto/create','POST',{amount,provider});const st=document.getElementById('payStage');if(!st)return;st.innerHTML=`<button class="pay-back" onclick="deposit()">‹ Назад</button><div class="pay-ok">${provider==='cryptobot'?'CryptoBot':'X Rocket'} · ${Number(d.amount).toFixed(2)} USDT</div><p class="pay-muted">Оплати счёт по кнопке ниже. После подтверждения баланс обновится автоматически.</p><a class="wide" style="display:block;text-decoration:none;text-align:center" href="${d.pay_url}" target="_blank">💳 ОПЛАТИТЬ СЧЁТ</a>${d.test_mode?`<button class="wide" onclick="testCreditDeposit(${d.id})">🧪 ТЕСТ: ЗАЧИСЛИТЬ БЕЗ ОПЛАТЫ</button><div class="pay-muted">Тестовый режим включён только для администратора.</div>`:''}<div id="cryptoStatus" class="pay-muted">Ожидание оплаты…</div>`;pollCrypto(d.id);}catch(e){alert(e.message);}}
async function testCreditDeposit(id){try{const d=await api('/api/payment/crypto/test-credit/'+id,'POST');setText('cryptoStatus','🧪 Тестовое зачисление выполнено. Баланс пополнен.');load();}catch(e){alert(e.message);}}
async function pollCrypto(id){let tries=0;const timer=setInterval(async()=>{tries++;try{const d=await api('/api/payment/crypto/status/'+id);if(d.credited){clearInterval(timer);setText('cryptoStatus','✅ Оплата получена. Баланс пополнен.');load();return;}if(d.status==='failed'||d.status==='expired'){clearInterval(timer);setText('cryptoStatus','❌ Счёт недействителен.');return;}}catch(e){}if(tries>=200)clearInterval(timer);},3000);}
function escapeHtml(s){return String(s??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','\"':'&quot;'}[m]));}

const WITHDRAW_BANKS=[
 ['bank_sber','Сбер','SBER'],['bank_vtb','ВТБ','VTB'],['bank_gazprombank','Газпромбанк','GPB'],['bank_alfa','Альфа-Банк','ALFA'],['bank_psb','ПСБ','PSB'],['bank_rshb','Россельхозбанк','RSHB'],['bank_mkb','МКБ','MKB'],['bank_tbank','Т-Банк','T'],['bank_sovcombank','Совкомбанк','SK'],['bank_domrf','Банк ДОМ.РФ','DOM']
];
function withdrawRow(v,n,l){return `<button class="pay-row" onclick="chooseWithdrawProvider('${v}','${n}')">${payLogo(v.startsWith('bank_')?'bank':'crypto',l)}<span><b>${n}</b><small>Выбрать способ</small></span><span class="pay-arrow">›</span></button>`;}
function withdraw(){modal(`<style>
.pay-sheet{display:flex;flex-direction:column;gap:12px}.pay-stage{animation:paySlide .22s ease}.pay-back{background:transparent;border:0;color:#aaa;text-align:left;padding:4px 0;font-size:14px}.pay-list{display:flex;flex-direction:column;gap:8px;max-height:48vh;overflow:auto;padding-right:2px}.pay-row{display:flex;align-items:center;gap:12px;width:100%;padding:12px;border:1px solid #252525;border-radius:14px;background:#111;color:#fff;text-align:left}.pay-row:active{transform:scale(.99)}.pay-row span:nth-child(2){flex:1}.pay-row small{display:block;color:#777;margin-top:3px}.pay-arrow{color:#777;font-size:24px}.pay-logo{width:34px;height:34px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;background:#222;border:1px solid #333;flex:none}.pay-logo.crypto{font-size:17px}.pay-logo.bank{font-size:8px}.pay-amount{margin-top:4px}@keyframes paySlide{from{opacity:0;transform:translateX(24px)}to{opacity:1;transform:none}}
</style><div class="pay-sheet"><div class="title">↗ Вывод</div><div id="withdrawStage" class="pay-stage"><p class="hint">Сначала выбери способ вывода.</p><div class="pay-list"><button class="pay-row" onclick="showWithdrawCrypto()">${payLogo('crypto','₿')}<span><b>Crypto</b><small>CryptoBot или X Rocket</small></span><span class="pay-arrow">›</span></button><button class="pay-row" onclick="showWithdrawBanks()">${payLogo('bank','₽')}<span><b>Bank</b><small>10 популярных банков</small></span><span class="pay-arrow">›</span></button></div></div></div>`);}
function showWithdrawCrypto(){const st=document.getElementById('withdrawStage');if(!st)return;st.innerHTML=`<button class="pay-back" onclick="withdraw()">‹ Назад</button><p class="hint">Выбери криптосервис.</p><div class="pay-list"><button class="pay-row" onclick="chooseWithdrawProvider('cryptobot','CryptoBot')">${payLogo('crypto','CB')}<span><b>CryptoBot</b><small>USDT / криптовыплата</small></span><span class="pay-arrow">›</span></button><button class="pay-row" onclick="chooseWithdrawProvider('xrocket','X Rocket')">${payLogo('crypto','XR')}<span><b>X Rocket</b><small>USDT / криптовыплата</small></span><span class="pay-arrow">›</span></button></div>`;}
function showWithdrawBanks(){const st=document.getElementById('withdrawStage');if(!st)return;st.innerHTML=`<button class="pay-back" onclick="withdraw()">‹ Назад</button><p class="hint">Выбери банк для вывода.</p><div class="pay-list">${WITHDRAW_BANKS.map(([v,n,l])=>withdrawRow(v,n,l)).join('')}</div>`;}
function chooseWithdrawProvider(provider,name){const st=document.getElementById('withdrawStage');if(!st)return;const crypto=provider==='cryptobot'||provider==='xrocket';const placeholder=crypto?'Кошелёк / username / реквизиты':'Номер карты / счёта / реквизиты';st.innerHTML=`<button class="pay-back" onclick="${crypto?'showWithdrawCrypto()':'showWithdrawBanks()'}">‹ Назад</button><p class="hint">Выбрано: <b>${name}</b></p><input id="wa" class="input pay-amount" type="number" min="1" step="0.01" placeholder="Сумма"><input id="addr" class="input" placeholder="${placeholder}"><button class="wide" onclick="createWithdraw('${provider}')">ОТПРАВИТЬ ЗАЯВКУ</button>`;}
async function createWithdraw(provider){try{const amount=Number(document.getElementById('wa')?.value||0),address=(document.getElementById('addr')?.value||'').trim();if(amount<=0)throw new Error('Введите корректную сумму');if(!address)throw new Error('Введите реквизиты');const d=await api('/api/withdraw','POST',{amount,address,provider});alert(d.message||'Заявка отправлена');closeModal();load();}catch(e){alert(e.message);}}
async function loadProfile(){try{const d=await api('/api/me'),u=d.user||{};setText('profileId',u.id||'—');setText('profileUsername',u.username?'@'+u.username:'—');setText('profileName',u.first_name||'—');setText('profileBalance',money(u.balance));applyVip(u.vip||{});}catch(e){alert(e.message);}}
document.addEventListener('DOMContentLoaded',load);

// ===== PREMIUM REFERRAL SYSTEM =====
let referralPeriod='all';
function refStyles(){
  if(document.getElementById('refStyles'))return;
  const s=document.createElement('style');s.id='refStyles';s.textContent=`
  .ref-card{margin:12px 0;padding:17px;border:1px solid #2b2b2b;border-radius:18px;background:linear-gradient(145deg,#141414,#0a0a0a);box-shadow:0 10px 30px rgba(0,0,0,.22)}
  .ref-title{font-size:18px;font-weight:900;letter-spacing:.2px}.ref-sub{color:#777;font-size:10px;letter-spacing:1.3px;margin-top:3px}.ref-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px}.ref-stat{padding:11px;border:1px solid #252525;border-radius:13px;background:#101010}.ref-stat span{display:block;color:#777;font-size:10px}.ref-stat b{display:block;margin-top:5px;font-size:16px;color:#fff}.ref-stat b.gold{color:#e8bb45}.ref-mono{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;letter-spacing:.3px}.ref-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}.ref-btn{width:100%;padding:13px;border-radius:13px;border:1px solid #303030;background:#151515;color:#f0c35b;font-weight:900}.ref-btn.primary{background:#e8bb45;color:#111;border-color:#e8bb45}.ref-link{margin-top:12px;padding:11px;border-radius:12px;background:#0f0f0f;border:1px solid #242424;color:#aaa;font-size:11px;word-break:break-all}.ref-rank{margin-top:12px;padding:12px;border-radius:13px;background:#101010;border:1px solid #242424}.ref-rank-top{display:flex;justify-content:space-between;gap:10px}.ref-progress{height:5px;background:#222;border-radius:99px;overflow:hidden;margin-top:9px}.ref-progress i{display:block;height:100%;background:#e8bb45}.ref-modal h3{margin:0 0 8px;font-size:20px}.ref-tabs{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin:12px 0}.ref-tab{padding:10px 5px;border-radius:10px;border:1px solid #292929;background:#111;color:#888;font-weight:800}.ref-tab.active{color:#111;background:#e8bb45;border-color:#e8bb45}.ref-row{display:flex;justify-content:space-between;gap:12px;padding:12px 2px;border-bottom:1px solid #222}.ref-row:last-of-type{border-bottom:0}.ref-level{font-weight:900}.ref-level small{display:block;color:#777;margin-top:3px;font-weight:600}.ref-value{font-weight:900;color:#fff}.ref-close{width:100%;padding:13px;margin-top:10px;border:0;border-radius:12px;background:#222;color:#fff;font-weight:900}`;document.head.appendChild(s);
}
function refButton(){
  refStyles(); const section=document.getElementById('profile'); if(!section)return;
  let b=document.getElementById('refSystemBtn');
  if(!b){b=document.createElement('button');b.id='refSystemBtn';b.className='ref-btn primary';b.textContent='🎫 РЕФЕРАЛЬНАЯ СИСТЕМА';b.onclick=showReferral;}
  const card=document.getElementById('refCard'); if(card)card.remove();
  const vipBtn=document.getElementById('vipTiersBtn');
  if(vipBtn)vipBtn.insertAdjacentElement('afterend',b); else section.appendChild(b);
}
function renderReferralCard(d){
  const section=document.getElementById('profile');if(!section)return;refStyles();
  const old=document.getElementById('refCard');if(old)old.remove();
  const next=d.next_threshold!=null?Number(d.next_threshold):null, turn=Number(d.turnover||0); const prog=next?Math.min(100,turn/next*100):100;
  const el=document.createElement('div');el.id='refCard';el.className='ref-card';
  el.innerHTML=`<div class="ref-title">🎫 Реферальный баланс</div><div class="ref-stat" style="margin-top:11px"><span>ДОСТУПНО</span><b class="gold">${money(d.balance)}</b></div><div class="ref-actions"><button class="ref-btn primary" onclick="showReferral()">🎫 ОТКРЫТЬ</button><button class="ref-btn" onclick="withdrawReferral()">💸 ВЫВОД</button></div>`;
  const vipBtn=document.getElementById('vipTiersBtn'); if(vipBtn)vipBtn.insertAdjacentElement('afterend',el); else section.appendChild(el);
}
async function bindStartReferral(){
  try{const p=(tg&&tg.initDataUnsafe&&tg.initDataUnsafe.start_param)||'';if(p.startsWith('ref_')){const id=Number(p.slice(4));if(id)await api('/api/referral/bind','POST',{referrer_id:id});}}catch(e){console.log('ref bind',e.message);}
}
async function loadReferralCard(){try{await bindStartReferral();const d=await api('/api/referral');renderReferralCard(d);}catch(e){console.log('referral',e.message);}}
async function showReferral(){
  try{const d=await api('/api/referral?period='+referralPeriod);refStyles();const rows=(d.levels||[]).map(x=>`<div class="ref-row"><div class="ref-level">${x.level===1?'🥉':x.level===2?'🥈':'🥇'} ${x.level} УРОВЕНЬ<small>${x.pct.toFixed(1).replace('.0','')}% с оборота</small></div><div class="ref-value"><span class="ref-mono">${x.refs}</span> шт<br><span class="ref-mono">${money(x.earned)}</span></div></div>`).join('');
  const next=d.next_threshold!=null?Number(d.next_threshold):null,turn=Number(d.turnover||0),prog=next?Math.min(100,turn/next*100):100;
  modal(`<div class="ref-modal"><h3>🎫 Реферальная система 🎫</h3><div class="ref-grid"><div class="ref-stat"><span>ДОХОД С ОБОРОТА</span><b class="gold">${Number(d.income_pct).toFixed(1).replace('.0','')}%</b></div><div class="ref-stat"><span>ЗАРАБОТАНО</span><b>${money(d.earned)}</b></div><div class="ref-stat"><span>РЕФЕРАЛЫ</span><b class="ref-mono">${d.refs}</b></div><div class="ref-stat"><span>КОЛ-ВО ИГР</span><b class="ref-mono">${d.levels.reduce((a,x)=>a+Number(x.refs||0),0)}</b></div></div><div class="ref-rank"><div class="ref-rank-top"><span>Ранг: <b>${d.rank}</b></span><span class="ref-mono">${turn.toFixed(2)}${next?'/'+next.toFixed(2)+'$':''}</span></div><div class="ref-progress"><i style="width:${prog}%"></i></div></div><div class="ref-link">🔗 ${d.invite_link}</div><button class="ref-btn primary" style="margin-top:8px" onclick="inviteReferral('${encodeURIComponent(d.invite_link)}')">🤝 ПРИГЛАСИТЬ</button><div class="ref-tabs"><button class="ref-tab ${referralPeriod==='today'?'active':''}" onclick="setReferralPeriod('today')">Сегодня</button><button class="ref-tab ${referralPeriod==='month'?'active':''}" onclick="setReferralPeriod('month')">Месяц</button><button class="ref-tab ${referralPeriod==='all'?'active':''}" onclick="setReferralPeriod('all')">Всё время</button></div><div class="ref-sub">📊 СТАТИСТИКА · ${d.period==='all'?'Всё время':d.period==='today'?'Сегодня':'Месяц'}</div>${rows}<div class="ref-actions"><button class="ref-btn" onclick="copyReferral('${encodeURIComponent(d.invite_link)}')">📋 КОПИРОВАТЬ</button><button class="ref-btn primary" onclick="withdrawReferral()">💸 ВЫВОД</button></div><button class="ref-close" onclick="closeModal()">ЗАКРЫТЬ</button></div>`);
  }catch(e){alert(e.message);}
}
async function setReferralPeriod(p){referralPeriod=p;await showReferral();}
function inviteReferral(encoded){const link=decodeURIComponent(encoded);const share='https://t.me/share/url?url='+encodeURIComponent(link)+'&text='+encodeURIComponent('🎫 Присоединяйся к HOT DICE 👑');if(tg&&tg.openTelegramLink)tg.openTelegramLink(share);else window.open(share,'_blank');}
async function copyReferral(encoded){const link=decodeURIComponent(encoded);try{await navigator.clipboard.writeText(link);alert('🔗 Ссылка скопирована');}catch(e){alert(link);}}
async function withdrawReferral(){try{const d=await api('/api/referral');const amount=prompt('💸 Сумма вывода на игровой баланс\nДоступно: '+money(d.balance),Number(d.balance).toFixed(2));if(amount===null)return;const n=Number(amount);if(!Number.isFinite(n)||n<=0)throw new Error('Введите корректную сумму');const r=await api('/api/referral/withdraw','POST',{amount:n});alert('✅ '+r.message);closeModal();load();loadReferralCard();}catch(e){alert(e.message);}}

const _oldLoad=load;
load=async function(){await _oldLoad();loadReferralCard();};


(function hdEnsureStyles(){
  if(document.getElementById('hdAudioStyles'))return;
  const s=document.createElement('style');s.id='hdAudioStyles';s.textContent=`
  .hd-settings-card{margin:12px 0 18px;border:1px solid #292929;border-radius:18px;background:linear-gradient(145deg,#131313,#090909);overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.2)}
  .hd-settings-head{width:100%;display:flex;justify-content:space-between;align-items:center;padding:15px 16px;background:transparent;border:0;color:#eee;font-weight:900;font-size:13px}
  .hd-settings-head span:last-child{color:#e8bb45;font-size:22px}
  .hd-settings-box{padding:0 14px 12px;border-top:1px solid #222}.hd-settings-box.hidden{display:none}
  .hd-setting-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 2px;border-bottom:1px solid #222}
  .hd-setting-row:last-child{border-bottom:0}.hd-setting-row b{display:block;font-size:13px}.hd-setting-row small{display:block;color:#777;margin-top:3px;font-size:10px;line-height:1.35}
  .hd-toggle{min-width:66px;padding:8px 11px;border-radius:999px;border:1px solid #333;background:#171717;color:#777;font-weight:900;font-size:10px}
  .hd-toggle.on{background:#e8bb45;border-color:#e8bb45;color:#111}
  `;
  document.head.appendChild(s);
})();

// ===== 💣 MINES =====
const minesState={roundId:null,mines:3,bet:0,opened:new Set(),busy:false};
function minesStyles(){
 if(document.getElementById('minesStyles'))return;
 const s=document.createElement('style');s.id='minesStyles';s.textContent=`
 .mines-wrap{padding:4px 0}.mines-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}.mines-title{font-size:24px;font-weight:900}.mines-bal{font-size:12px;color:#999}.mines-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin:16px 0}.mine-cell{aspect-ratio:1;border:1px solid #292929;border-radius:13px;background:linear-gradient(145deg,#191919,#0d0d0d);color:#d9aa3d;font-size:23px;font-weight:900}.mine-cell:active{transform:scale(.96)}.mine-cell.safe{background:linear-gradient(145deg,#241f12,#15120b);border-color:#9b7427}.mine-cell.mine{background:#271313;border-color:#6f2929}.mine-controls{display:flex;gap:8px}.mine-controls .input{flex:1}.mine-mines{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0 14px}.mine-count{padding:8px 11px;border-radius:10px;border:1px solid #292929;background:#111;color:#aaa;font-weight:800}.mine-count.selected{background:#e8bb45;color:#111;border-color:#e8bb45}.mine-info{display:flex;justify-content:space-between;color:#888;font-size:12px;margin:8px 0}.mine-mult{font-size:28px;font-weight:900;color:#e8bb45;text-align:center;margin:6px 0}.mine-cash{width:100%;padding:14px;border:0;border-radius:14px;background:#e8bb45;color:#111;font-weight:900}.mine-start{width:100%;padding:14px;border:0;border-radius:14px;background:#e8bb45;color:#111;font-weight:900}
 `;
 document.head.appendChild(s);
}
function openMines(){
 minesStyles(); minesState.roundId=null; minesState.opened=new Set();
 modal(`<div class="mines-wrap"><div class="mines-head"><div class="mines-title">💣 MINES</div><div class="mines-bal" id="mineBalance">Баланс: —</div></div>
 <div class="mine-info"><span>Количество мин</span><b id="mineCountLabel">3</b></div>
 <div class="mine-mines">${[1,3,5,7,10,15].map(n=>`<button class="mine-count ${n===3?'selected':''}" onclick="mineSelect(${n},this)">${n}</button>`).join('')}</div>
 <input id="mineBet" class="input" type="number" min="0.01" step="0.01" placeholder="Ставка, USDT">
 <button class="mine-start" onclick="mineStart()">💣 НАЧАТЬ ИГРУ</button></div>`);
}
function mineSelect(n,b){document.querySelectorAll('.mine-count').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');minesState.mines=n;setText('mineCountLabel',n);}
async function mineStart(){
 const bet=Number(document.getElementById('mineBet')?.value||0);if(!Number.isFinite(bet)||bet<=0)return alert('Введите ставку');
 try{const d=await api('/api/mines/start','POST',{bet,mines:minesState.mines});minesState.roundId=d.round_id;minesState.bet=bet;minesState.opened=new Set();hdFx('click',12,.18);renderMinesBoard(d);}
 catch(e){alert(e.message);}
}
function renderMinesBoard(d,done=false){
 const cells=Array.from({length:25},(_,i)=>`<button id="mineCell${i}" class="mine-cell" onclick="mineOpen(${i})">?</button>`).join('');
 modal(`<div class="mines-wrap"><div class="mines-head"><div class="mines-title">💣 MINES</div><div class="mines-bal">Баланс: ${money(d.balance)}</div></div>
 <div class="mine-info"><span>Безопасных клеток: <b id="mineSafe">${d.safe_count||0}</b></span><span>Мин: <b>${minesState.mines}</b></span></div>
 <div class="mine-mult" id="mineMult">×${Number(d.multiplier||1).toFixed(2)}</div><div class="mines-grid">${cells}</div>
 <button id="mineCash" class="mine-cash" onclick="mineCashout()" disabled>💰 ЗАБРАТЬ</button></div>`);
}
async function mineOpen(cell){
 if(!minesState.roundId||minesState.busy||minesState.opened.has(cell))return;
 minesState.busy=true;hdFx('click',10,.15);
 try{
  const d=await api('/api/mines/open','POST',{round_id:minesState.roundId,cell});
  if(d.status==='lost'){
   (d.mine_cells||[]).forEach(i=>{const e=document.getElementById('mineCell'+i);if(e){e.textContent='💣';e.classList.add('mine');}});
   const e=document.getElementById('mineCell'+cell);if(e){e.textContent='💥';e.classList.add('mine');}
   hdGameLossFx();alert('💥 Мина! Кэшбэк: '+money(d.cashback||0));closeModal();load();return;
  }
  const e=document.getElementById('mineCell'+cell);if(e){e.textContent='💎';e.classList.add('safe');e.disabled=true;}
  minesState.opened.add(cell);setText('mineSafe',d.safe_count);setText('mineMult','×'+Number(d.multiplier).toFixed(2));
  if(d.status==='won'){hdGameWinFx();alert('🏆 Все безопасные клетки открыты! Выигрыш: '+money(d.payout));closeModal();load();return;}
  const cash=document.getElementById('mineCash');if(cash)cash.disabled=false;hdFx('step',18,.22);
 }catch(e){alert(e.message)}finally{minesState.busy=false;}
}
async function mineCashout(){
 if(!minesState.roundId)return;hdCashoutFx();
 try{const d=await api('/api/mines/cashout','POST',{round_id:minesState.roundId});alert('💰 Забрано: '+money(d.payout));closeModal();load();}catch(e){alert(e.message)}
}


(function minesCardStyle(){
 if(document.getElementById('minesCardStyle'))return;
 const s=document.createElement('style');s.id='minesCardStyle';s.textContent=`
 .mines-game-card{display:flex!important;align-items:center;justify-content:flex-start;gap:14px;width:100%;min-height:92px;padding:16px 18px!important;margin-top:12px;border:1px solid #2f2f2f!important;border-radius:18px!important;background:linear-gradient(145deg,#151515,#0b0b0b)!important;color:#fff!important;text-align:left}
 .mines-game-card .game-icon{font-size:42px;line-height:1}
 .mines-game-card b{display:block;font-size:17px;letter-spacing:1px}
 .mines-game-card small{display:block;margin-top:5px;color:#888;font-size:11px}
 `;
 document.head.appendChild(s);
})();

(function injectMinesCard(){
 minesStyles();
 const add=()=>{
  if(document.getElementById('minesGameCard'))return;

  // Find the real Games section/grid used by the existing Mini App.
  let sec=document.getElementById('games')
    || document.querySelector('[data-section="games"]')
    || document.querySelector('.games-section');

  if(!sec){
    const candidates=[...document.querySelectorAll('.section, main, section, div')];
    const heading=candidates.find(el=>{
      const t=(el.textContent||'').trim();
      return t.includes('ИГРЫ') && t.length<2500;
    });
    if(heading) sec=heading.closest('.section')||heading.closest('section')||heading.parentElement;
  }

  if(!sec)return;

  const grid=sec.querySelector('.games-grid, .game-grid, .games-list, .cards-grid') || sec;
  const b=document.createElement('button');
  b.id='minesGameCard';
  b.type='button';
  b.className='game-card mines-game-card';
  b.innerHTML='<span class="game-icon">💣</span><span><b>MINES</b><small>Мины · множитель · забрать</small></span>';
  b.onclick=openMines;
  grid.appendChild(b);
 };

 const run=()=>{add(); if(!document.getElementById('minesGameCard')) setTimeout(add,250);};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();
 try{
   const obs=new MutationObserver(()=>add());
   obs.observe(document.body,{childList:true,subtree:true});
   setTimeout(()=>obs.disconnect(),5000);
 }catch(e){}
})();


// ===== 🚀 ROCKET / CRASH — SHARED ROOM =====
const ROCKET_PREFS_KEY='rocket.preferences.v4';
const rocketState={roomId:null,roundId:null,bet:0,pendingBet:0,launchPending:false,startedAt:0,busy:false,running:false,timer:null,stateTimer:null,waitUntil:0,autoCashout:false,autoTarget:2,autoTriggered:false,cashedOut:false,lastMultiplier:1,lastStatus:'waiting',toastTimer:null};
function rocketPrefs(){try{return Object.assign({autoCashout:false,autoTarget:2},JSON.parse(localStorage.getItem(ROCKET_PREFS_KEY)||'{}'));}catch(e){return {autoCashout:false,autoTarget:2};}}
function saveRocketPrefs(){try{localStorage.setItem(ROCKET_PREFS_KEY,JSON.stringify({autoCashout:rocketState.autoCashout,autoTarget:rocketState.autoTarget}));}catch(e){}}
function rocketStyles(){
 if(document.getElementById('rocketStyles'))return;
 const s=document.createElement('style');s.id='rocketStyles';s.textContent=`
 .rocket-wrap{position:fixed;inset:0;z-index:99999;display:flex;flex-direction:column;box-sizing:border-box;height:100dvh;min-height:100dvh;padding:calc(8px + env(safe-area-inset-top)) 14px calc(8px + env(safe-area-inset-bottom));background:#090a0f;color:#fff;overflow:hidden;font-family:inherit}
 .rocket-top{display:grid;grid-template-columns:56px 1fr auto;align-items:center;gap:9px;flex:0 0 auto;height:48px}.rocket-back{width:56px;height:42px;border:1px solid #555b60;border-radius:15px;background:linear-gradient(180deg,#4a4f52,#363a3d);color:#fff;font-size:28px;line-height:1;box-shadow:inset 0 1px rgba(255,255,255,.25)}.rocket-brand{font-size:18px;font-weight:900;text-align:center;letter-spacing:.4px;color:#f1f1f1}.rocket-bal{padding:11px 14px;border:1px solid #555b60;border-radius:15px;background:linear-gradient(180deg,#484d50,#363a3d);color:#fff;font-size:15px;font-weight:900;white-space:nowrap;box-shadow:inset 0 1px rgba(255,255,255,.22)}
 .rocket-meta{display:grid;grid-template-columns:118px 1fr;gap:10px;align-items:center;margin:8px 0 8px;flex:0 0 auto}.rocket-players{height:54px;box-sizing:border-box;display:flex;align-items:center;justify-content:center;padding:0 10px;border:1px solid #555b60;border-radius:17px;background:linear-gradient(180deg,#4b5053,#373b3e);color:#fff;font-size:18px;font-weight:900}.rocket-history{height:54px;box-sizing:border-box;display:flex;gap:5px;align-items:center;padding:5px 7px;border:1px solid #555b60;border-radius:17px;background:linear-gradient(180deg,#4b5053,#373b3e);overflow-x:auto;scrollbar-width:none}.rocket-history::-webkit-scrollbar{display:none}.rocket-history-item{min-width:62px;height:42px;box-sizing:border-box;display:flex;align-items:center;justify-content:center;border-radius:13px;color:#c9ffff;font-size:15px;font-weight:900;white-space:nowrap}.rocket-history-item.mid{color:#ffb77e}.rocket-history-item.big{color:#ffe66e}.rocket-history-item.hot{color:#7ff7ff}.rocket-history-item.latest{background:linear-gradient(180deg,#b36cff,#8e42d7);color:#fff;box-shadow:0 4px 18px rgba(160,83,240,.45)}
 .rocket-stage{position:relative;flex:1 1 auto;min-height:0;overflow:hidden;border-radius:30px;background:radial-gradient(circle at 50% 54%,rgba(84,123,255,.12),transparent 27%),radial-gradient(circle at 25% 50%,rgba(255,190,80,.08),transparent 30%),#070910;box-shadow:inset 0 0 110px rgba(0,0,0,.88);border:1px solid #11151d}.rocket-stars{position:absolute;inset:0;overflow:hidden}.rocket-star{position:absolute;width:2px;height:2px;border-radius:50%;background:#fff;box-shadow:0 0 8px #fff;opacity:.7;animation:rocketTwinkle 1.8s ease-in-out infinite}.rocket-speedlines{position:absolute;inset:-35%;opacity:0;background:repeating-linear-gradient(145deg,transparent 0 55px,rgba(255,255,255,.9) 56px 58px,transparent 59px 92px);transform:rotate(-7deg);mask-image:linear-gradient(180deg,transparent 0,#fff 20%,#fff 80%,transparent 100%)}.rocket-stage.running .rocket-speedlines{opacity:.72;animation:rocketSpeed 1.05s linear infinite}.rocket-glow{position:absolute;left:50%;top:52%;width:260px;height:260px;transform:translate(-50%,-50%);background:radial-gradient(circle,rgba(91,150,255,.15),transparent 65%);filter:blur(12px)}
 .rocket-mult{position:absolute;z-index:10;top:29%;left:0;right:0;text-align:center;font-size:clamp(58px,16vw,92px);line-height:1;font-weight:950;color:#f4f6ff;text-shadow:0 0 28px rgba(170,200,255,.24);letter-spacing:-3px}.rocket-stage.running .rocket-mult{color:#f2f5ff}.rocket-sub{position:absolute;z-index:10;top:45%;left:0;right:0;text-align:center;font-size:14px;font-weight:900;letter-spacing:1.6px;color:#b8bcc5;text-transform:uppercase}.rocket-stage.waiting .rocket-mult{top:38%;font-size:clamp(64px,19vw,96px);color:#eff3ff;text-shadow:0 0 28px rgba(205,180,255,.35)}.rocket-stage.waiting .rocket-sub{top:53%;color:#9b9eaa}.rocket-stage.crashed .rocket-mult{color:#f4f4f4}.rocket-stage.crashed .rocket-sub{color:#ffb06b}
 .rocket-flight{position:absolute;inset:0;z-index:5;pointer-events:none}.rocket-ship{position:absolute;z-index:12;width:150px;height:100px;left:50%;bottom:42%;transform-origin:50% 50%;filter:drop-shadow(0 16px 25px rgba(53,180,255,.28));will-change:left,bottom,transform}.rocket-body{position:absolute;left:24px;top:20px;width:104px;height:58px;border-radius:58% 50% 42% 50%;transform:rotate(-8deg);background:linear-gradient(160deg,#fbffff 0 26%,#bfc8d1 42%,#f8ffff 57%,#7f8b95 100%);box-shadow:inset -9px -7px 10px rgba(0,0,0,.25),inset 7px 5px 12px rgba(255,255,255,.8)}.rocket-body:before{content:'';position:absolute;left:44px;top:-7px;width:38px;height:30px;border-radius:55% 55% 40% 40%;background:linear-gradient(145deg,#f8ffff,#8ed9f4 48%,#355a8a);border:4px solid #dbe8ee;box-shadow:0 0 12px rgba(76,196,255,.4)}.rocket-body:after{content:'';position:absolute;right:-10px;top:14px;width:28px;height:31px;background:linear-gradient(145deg,#f9ffff,#9ba8b0);clip-path:polygon(0 0,100% 50%,0 100%)}.rocket-nose{position:absolute;left:110px;top:33px;width:30px;height:25px;background:linear-gradient(145deg,#f5ffff,#a8b3bc);clip-path:polygon(0 0,100% 50%,0 100%)}.rocket-fin{position:absolute;width:33px;height:27px;background:linear-gradient(145deg,#dbe7ec,#80909a);bottom:12px;border-radius:5px}.rocket-fin.left{left:39px;transform:skewY(18deg)}.rocket-fin.right{left:78px;transform:skewY(-18deg)}.rocket-nozzle{position:absolute;left:13px;top:42px;width:22px;height:24px;border-radius:50%;background:#4d5962}.rocket-flame{position:absolute;z-index:11;width:72px;height:72px;left:10%;bottom:39%;border-radius:50%;background:radial-gradient(circle,#fff 0 8%,#fff4a0 16%,#ffb82f 36%,#ff6a16 56%,rgba(255,50,0,0) 74%);filter:blur(5px);transform:translateX(-50%);opacity:0}.rocket-core{position:absolute;z-index:13;width:42px;height:42px;left:10%;bottom:40%;border-radius:50%;background:radial-gradient(circle,#fff 0 10%,#ffe66d 25%,#ff8c1f 60%,transparent 75%);filter:blur(2px);opacity:0}.rocket-stage.running .rocket-flame,.rocket-stage.running .rocket-core{opacity:1;animation:rocketFlame .09s ease-in-out infinite alternate}.rocket-trail{position:absolute;width:150px;height:70px;left:0;bottom:0;border-radius:50%;background:linear-gradient(90deg,rgba(255,245,180,.65),rgba(255,150,20,.25),transparent);filter:blur(12px);transform-origin:right center;opacity:0}.rocket-stage.running .rocket-trail{opacity:.85}.rocket-smoke{position:absolute;width:18px;height:18px;border-radius:50%;background:radial-gradient(circle,rgba(220,220,220,.42),rgba(80,80,80,0) 72%);filter:blur(4px);opacity:.4}
 .rocket-wait-ring{position:absolute;z-index:9;left:50%;top:47%;width:190px;height:190px;transform:translate(-50%,-50%);border:2px solid rgba(213,190,255,.85);border-radius:50%;box-shadow:0 0 25px rgba(174,122,255,.25),inset 0 0 20px rgba(174,122,255,.08)}.rocket-wait-ring:after{content:'';position:absolute;inset:-2px;border-radius:50%;border:3px solid transparent;border-top-color:#b77aff;border-right-color:#8eeaff;animation:rocketRing 1.4s linear infinite}.rocket-wait-label{position:absolute;z-index:10;left:0;right:0;top:calc(47% + 112px);text-align:center;color:#aeb1bc;font-size:12px;font-weight:900;letter-spacing:1.4px}
 .rocket-controls{flex:0 0 auto;padding-top:9px}.rocket-status{text-align:center;min-height:22px;color:#a7abb4;font-size:13px;margin:0 0 7px}.rocket-bet{width:100%;height:52px;box-sizing:border-box;background:#353b3f!important;border:1px solid #8a9093!important;border-radius:17px!important;color:#fff!important;font-size:16px!important;padding:0 18px!important}.rocket-start,.rocket-cash{width:100%;height:57px;margin-top:8px;border:1px solid rgba(255,255,255,.15);border-radius:17px;font-weight:950;font-size:17px;letter-spacing:.2px;background:linear-gradient(180deg,#b66cff,#8c46d6);color:#fff;box-shadow:0 8px 25px rgba(142,70,214,.28)}.rocket-start:disabled,.rocket-cash:disabled{opacity:.55}.rocket-auto{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 4px 0}.rocket-auto-main{display:flex;align-items:center;gap:9px;font-size:13px;font-weight:900}.rocket-check{appearance:none;width:22px;height:22px;border-radius:7px;border:1px solid #8a9093;background:#222;display:grid;place-items:center}.rocket-check:checked{background:#b66cff;border-color:#b66cff}.rocket-check:checked:after{content:'✓';font-weight:1000;color:#fff}.rocket-target{width:92px;height:36px;box-sizing:border-box;border-radius:10px;border:1px solid #666;background:#2d3134;color:#eadbff;text-align:center;font-weight:900}.rocket-target:disabled{opacity:.35}.rocket-auto-note{font-size:9px;color:#666;text-align:right;margin-top:2px}
 .rocket-toast{position:absolute;z-index:80;left:50%;top:74px;transform:translate(-50%,-16px) scale(.96);min-width:240px;max-width:calc(100% - 28px);padding:12px 18px;border-radius:18px;background:linear-gradient(180deg,#ffd84c,#d9a700);color:#171717;font-size:16px;font-weight:950;text-align:center;box-shadow:0 10px 35px rgba(255,205,35,.3);opacity:0;pointer-events:none;animation:rocketToast .45s ease forwards}.rocket-toast b{font-size:19px}.rocket-stage.explode{animation:rocketShake .42s ease}.rocket-explosion{position:absolute;z-index:30;left:50%;top:50%;width:54px;height:54px;border-radius:50%;background:radial-gradient(circle,#fff 0 10%,#ffe26d 18%,#ff9b24 38%,#ed4316 54%,transparent 72%);transform:translate(-50%,-50%) scale(.2);animation:rocketBoom .72s ease-out forwards;box-shadow:0 0 55px rgba(255,146,20,.9)}
 @keyframes rocketTwinkle{0%,100%{opacity:.2}50%{opacity:1}}@keyframes rocketSpeed{from{transform:translateY(-120px) rotate(-7deg)}to{transform:translateY(120px) rotate(-7deg)}}@keyframes rocketFlame{from{transform:scale(.82);filter:blur(5px)}to{transform:scale(1.12);filter:blur(3px)}}@keyframes rocketRing{to{transform:rotate(360deg)}}@keyframes rocketShake{0%,100%{transform:translate(0)}20%{transform:translate(-5px,2px)}40%{transform:translate(5px,-2px)}60%{transform:translate(-4px,-1px)}80%{transform:translate(4px,1px)}}@keyframes rocketBoom{0%{transform:translate(-50%,-50%) scale(.2);opacity:0}20%{opacity:1}100%{transform:translate(-50%,-50%) scale(7);opacity:0}}@keyframes rocketToast{to{opacity:1;transform:translate(-50%,0) scale(1)}}
 
 .rocket-stage.running .rocket-stars{animation:rocketStarsDrift 2.4s linear infinite}
 .rocket-stage.running .rocket-speedlines{animation:rocketLinesDrift .72s linear infinite}
 .rocket-mult{top:22%!important}
 .rocket-sub{top:37%!important}
 .rocket-stage.waiting .rocket-mult{top:39%!important}
 .rocket-stage.waiting .rocket-sub{top:54%!important}
 .rocket-stage.running .rocket-flight{display:block}
 .rocket-stage.waiting .rocket-flight,.rocket-stage.crashed .rocket-flight{display:none}
 .rocket-ship{left:27%!important;bottom:31%!important;transform:translate(-50%,50%) rotate(-8deg) scale(.92)!important}
 @keyframes rocketStarsDrift{from{transform:translateX(-18px)}to{transform:translateX(70px)}}
 @keyframes rocketLinesDrift{from{transform:rotate(-7deg) translateX(-180px)}to{transform:rotate(-7deg) translateX(180px)}}

/* ROCKET V2 OVERRIDES */
.rocket-wrap{padding:0 12px calc(6px + env(safe-area-inset-bottom))!important;gap:0!important}
.rocket-top{height:58px!important;margin-top:calc(4px + env(safe-area-inset-top))!important}
.rocket-meta{margin:7px 0 8px!important}
.rocket-stage{flex:1 1 0!important;min-height:0!important;height:100%!important;border-radius:28px!important}
#rocketSceneHost{flex:1 1 0!important;min-height:220px!important;display:flex!important;flex-direction:column!important;overflow:hidden!important}
#rocketSceneHost>.rocket-stage{flex:1 1 auto!important;min-height:0!important;width:100%!important}
.rocket-stage.waiting{display:block!important}
.rocket-stage.waiting .rocket-wait-ring{display:flex!important}
.rocket-stage.waiting .rocket-wait-number{position:absolute!important;left:0!important;top:0!important;right:0!important;bottom:0!important;margin:0!important;display:flex!important;align-items:center!important;justify-content:center!important}
.rocket-stage.waiting .rocket-wait-label{display:block!important}
.rocket-stage.running .rocket-stars{animation:rocketStarsDrift 1.7s linear infinite!important}
.rocket-stage.running .rocket-speedlines{opacity:.58!important;animation:rocketSpeed .58s linear infinite!important}
.rocket-mult{top:7%!important;font-size:clamp(66px,18vw,112px)!important;line-height:.95!important;letter-spacing:-4px!important}
.rocket-sub{top:18%!important;font-size:12px!important;letter-spacing:2px!important;opacity:.82!important}
.rocket-stage.waiting .rocket-mult,.rocket-stage.waiting .rocket-sub{display:none!important}
.rocket-wait-ring{position:absolute!important;z-index:20!important;left:50%!important;top:46%!important;width:min(230px,52vw)!important;height:min(230px,52vw)!important;transform:translate(-50%,-50%)!important;display:flex!important;align-items:center!important;justify-content:center!important;box-sizing:border-box!important}
.rocket-wait-number{position:relative!important;inset:auto!important;display:flex!important;align-items:center!important;justify-content:center!important;width:100%!important;height:100%!important;font-size:clamp(68px,19vw,96px)!important;font-weight:950!important;color:#fff!important;line-height:1!important;z-index:2!important;text-shadow:0 0 25px rgba(180,140,255,.3)!important}
.rocket-wait-label{top:calc(46% + min(130px,30vw))!important;font-size:13px!important;letter-spacing:1.8px!important}
.rocket-flight{inset:0!important;display:block!important}
.rocket-ship{left:50%!important;bottom:43%!important;width:210px!important;height:140px!important;transform:translate(-50%,50%) rotate(-4deg)!important;animation:rocketFloatV2 1.15s ease-in-out infinite alternate!important;filter:drop-shadow(0 18px 28px rgba(60,190,255,.32))!important}
.rocket-body{left:34px!important;top:28px!important;width:142px!important;height:78px!important;border-radius:58% 48% 44% 52%!important;background:linear-gradient(155deg,#fff 0 18%,#dce7ee 30%,#aab8c2 47%,#f7fbfd 60%,#71818d 100%)!important;box-shadow:inset -14px -10px 16px rgba(0,0,0,.25),inset 10px 7px 16px rgba(255,255,255,.9),0 0 24px rgba(140,220,255,.18)!important}
.rocket-body:before{left:56px!important;top:-10px!important;width:48px!important;height:38px!important;border-width:5px!important;background:linear-gradient(145deg,#e9fbff,#75c8ed 48%,#264b78)!important}
.rocket-body:after{right:-15px!important;top:20px!important;width:40px!important;height:40px!important}
.rocket-nose{left:150px!important;top:45px!important;width:42px!important;height:34px!important}
.rocket-fin{width:44px!important;height:36px!important;bottom:13px!important}.rocket-fin.left{left:53px!important}.rocket-fin.right{left:104px!important}
.rocket-nozzle{left:13px!important;top:55px!important;width:28px!important;height:30px!important}
.rocket-flame{left:calc(50% - 102px)!important;bottom:39%!important;width:118px!important;height:118px!important;transform:translateX(-50%)!important;opacity:1!important;background:radial-gradient(ellipse at 65% 50%,#fff 0 8%,#fff6a0 15%,#ffc331 32%,#ff6a13 55%,rgba(255,50,0,0) 74%)!important;filter:blur(4px)!important}
.rocket-core{left:calc(50% - 101px)!important;bottom:40%!important;width:62px!important;height:70px!important;opacity:1!important}
.rocket-stage.running .rocket-flame,.rocket-stage.running .rocket-core{animation:rocketFlameV2 .11s ease-in-out infinite alternate!important}
.rocket-controls{padding-top:7px!important;flex:0 0 auto!important}.rocket-status{min-height:20px!important;margin:0 0 4px!important;font-size:13px!important}.rocket-bet{height:48px!important}.rocket-start,.rocket-cash{height:58px!important;margin-top:6px!important;border-radius:18px!important;font-size:18px!important}.rocket-auto{padding:6px 4px 0!important}.rocket-auto-note{display:none!important}
@keyframes rocketFloatV2{from{margin-top:0;transform:translate(-50%,50%) rotate(-4deg)}to{margin-top:-12px;transform:translate(-50%,50%) rotate(-2deg)}}
@keyframes rocketFlameV2{from{transform:translateX(-50%) scale(.86);filter:blur(4px)}to{transform:translateX(-50%) scale(1.14);filter:blur(2px)}}
`;document.head.appendChild(s);
}
function rocketHistoryHtml(items){return (items||[]).map((x,i)=>{const m=Number(x.multiplier||0);const cls=m>=10?'big':m>=2?'mid':'hot';return `<div class="rocket-history-item ${cls} ${i===0?'latest':''}">${m.toFixed(2)}×</div>`}).join('');}
function rocketStarsHtml(){let h='';for(let i=0;i<46;i++){const l=(i*47)%98,t=(i*67)%94,d=(i%7)*.19;h+=`<i class="rocket-star" style="left:${l}%;top:${t}%;animation-delay:${d}s"></i>`;}return h;}
function rocketScene(mult=1,phase='waiting',countdown=0){const m=Number(mult||1),running=phase==='running',crashed=phase==='crashed',waiting=phase==='waiting';return `<div class="rocket-stage ${running?'running':''} ${crashed?'crashed':''} ${waiting?'waiting':''}" id="rocketStage"><div class="rocket-stars">${rocketStarsHtml()}</div><div class="rocket-speedlines"></div><div class="rocket-glow"></div>${waiting?`<div class="rocket-wait-ring"><div class="rocket-wait-number" id="rocketWaitNumber">${Math.max(0,Math.ceil(Number(countdown||0)))}</div></div><div class="rocket-wait-label">СЛЕДУЮЩИЙ РАУНД</div>`:''}<div class="rocket-mult" id="rocketMult">${m.toFixed(2)}×</div><div class="rocket-sub" id="rocketSub">${crashed?'💥 РАКЕТА ВЗОРВАЛАСЬ':'РАКЕТА В ПОЛЁТЕ'}</div>${running?`<div class="rocket-flight"><div class="rocket-trail" id="rocketTrail"></div><div class="rocket-ship" id="rocketShip"><div class="rocket-nose"></div><div class="rocket-body"></div><div class="rocket-fin left"></div><div class="rocket-fin right"></div><div class="rocket-nozzle"></div></div><div class="rocket-flame" id="rocketFlame"></div><div class="rocket-core" id="rocketCore"></div></div>`:''}</div>`;}
function rocketAutoHtml(){return `<div class="rocket-auto"><label class="rocket-auto-main"><input id="rocketAuto" class="rocket-check" type="checkbox" onchange="rocketAutoChanged()"><span>Авто Cash Out</span></label><input id="rocketTarget" class="rocket-target" type="number" min="1.01" max="1000" step="0.01" value="2.00" onchange="rocketTargetChanged()"></div><div class="rocket-auto-note">Автоматически забрать при выбранном коэффициенте</div>`;}
function rocketSyncAutoUI(){const p=rocketPrefs();const cb=document.getElementById('rocketAuto'),t=document.getElementById('rocketTarget');if(cb)cb.checked=!!rocketState.autoCashout;if(t){t.value=Number(rocketState.autoTarget||p.autoTarget||2).toFixed(2);t.disabled=!rocketState.autoCashout;}}
function rocketAutoChanged(){const cb=document.getElementById('rocketAuto');rocketState.autoCashout=!!cb?.checked;saveRocketPrefs();rocketSyncAutoUI();}
function rocketTargetChanged(){const el=document.getElementById('rocketTarget');let v=Number(el?.value||2);if(!Number.isFinite(v))v=2;v=Math.min(1000,Math.max(1.01,v));rocketState.autoTarget=Number(v.toFixed(2));saveRocketPrefs();}
function rocketShowToast(amount){const old=document.querySelector('.rocket-toast');if(old)old.remove();const el=document.createElement('div');el.className='rocket-toast';el.innerHTML=`🪙 Вы выиграли <b>${money(amount)}</b>`;document.querySelector('.rocket-wrap')?.appendChild(el);setTimeout(()=>el.remove(),2600);}
async function openRocket(){rocketStyles();rocketStop();try{if(tg&&tg.BackButton){tg.BackButton.offClick(closeRocket);tg.BackButton.onClick(closeRocket);tg.BackButton.show();}}catch(e){}const p=rocketPrefs();rocketState.autoCashout=!!p.autoCashout;rocketState.autoTarget=Number(p.autoTarget)||2;rocketState.roomId=null;rocketState.roundId=null;rocketState.bet=0;rocketState.pendingBet=0;rocketState.launchPending=false;rocketState.running=false;rocketState.cashedOut=false;rocketState.autoTriggered=false;rocketState.lastStatus='';try{const d=await api('/api/crash/active');rocketApply(d,true);if(!rocketState.stateTimer)rocketState.stateTimer=setInterval(rocketPollOnce,250);}catch(e){alert(e.message)}}
function rocketRenderControls(d){const bet=Number(d.bet||0);const phase=(d.active===false?'waiting':(d.room_status||d.status||'waiting'));const waiting=phase==='waiting';const running=phase==='running';const hasBet=!!d.round_id;const cashed=d.bet_status==='cashout'||d.status==='cashout'||rocketState.cashedOut;let html='';if(waiting){const sec=Math.max(0,Math.ceil(Number(d.countdown||0)));if(rocketState.pendingBet>0){html+=`<div class="rocket-status">Ставка <b>${money(rocketState.pendingBet)}</b> принята · запуск через <b>${sec}с</b></div><button class="rocket-start" disabled>✓ СТАВКА ПРИНЯТА</button>${rocketAutoHtml()}`;}else{html+=`<div class="rocket-status">${sec>0?`Следующий раунд через <b>${sec}с</b> · ставку можно сделать сейчас`:'Сделайте ставку до запуска ракеты'}</div><input id="rocketBet" class="input rocket-bet" type="number" inputmode="decimal" min="0.01" step="0.01" placeholder="Ставка, USDT"><button type="button" class="rocket-start" onclick="rocketStart()">СДЕЛАТЬ СТАВКУ</button>${rocketAutoHtml()}`;}}else if(running){if(hasBet&&!cashed){html+=`<div class="rocket-status">Ставка: <b>${money(bet)}</b> · коэффициент растёт</div><button id="rocketCash" class="rocket-cash" onclick="rocketCashout()">ЗАБРАТЬ · ×${Number(d.multiplier||1).toFixed(2)}</button>`;}else if(cashed){html+=`<div class="rocket-status" id="rocketStatus">Вы уже забрали выигрыш · ракета продолжает полёт</div>`;}else{html+=`<div class="rocket-status">Ставки закрыты · дождитесь следующего раунда</div>`;}}else{html+=`<div class="rocket-status">Раунд завершён · новый запуск скоро</div>`;}return html;}
function renderRocket(d){let el=document.getElementById('rocketWrap');if(!el){modal(`<div class="rocket-wrap" id="rocketWrap"></div>`);el=document.getElementById('rocketWrap');}if(!el)return;const active=d.active!==false;const phase=d.status==='lost'?'crashed':(active?(d.room_status||d.status||'running'):'waiting');const m=Number(d.multiplier||1);rocketState.roomId=d.room_id||rocketState.roomId;rocketState.roundId=d.round_id||null;rocketState.bet=Number(d.bet||0);rocketState.startedAt=d.started_at?Date.parse(d.started_at):rocketState.startedAt;rocketState.lastStatus=phase;rocketState.cashedOut=rocketState.cashedOut||d.bet_status==='cashout'||d.status==='cashout';el.innerHTML=`<div class="rocket-top"><button class="rocket-back" onclick="closeRocket()">←</button><div class="rocket-brand">🚀 ROCKET</div><div class="rocket-bal" id="rocketBal">${money(d.balance)}</div></div><div class="rocket-meta"><div class="rocket-players" id="rocketPlayers">👥 ${Number(d.players||0)}</div><div class="rocket-history" id="rocketHistory">${rocketHistoryHtml(d.history)}</div></div><div id="rocketSceneHost">${rocketScene(m,phase,Number(d.countdown||0))}</div><div class="rocket-controls" id="rocketControls">${rocketRenderControls(d)}</div></div>`;rocketSyncAutoUI();if(phase==='running')rocketSetMultiplier(m);if(phase==='crashed')rocketExplode();}
function rocketApply(d,initial=false){if(!d)return;if(d.balance!=null){const b=document.getElementById('rocketBal');if(b)b.textContent=money(d.balance);}if(d.active===false){rocketState.roundId=null;rocketState.bet=0;rocketState.running=false;rocketState.cashedOut=false;rocketState.autoTriggered=false;if(!rocketState.waitUntil||rocketState.waitUntil<Date.now())rocketState.waitUntil=Date.now()+10000;renderRocket({...d,status:'waiting',countdown:Math.max(0,(rocketState.waitUntil-Date.now())/1000)});rocketStartWaitingLoop();return;}rocketState.waitUntil=0;rocketState.roomId=d.room_id||rocketState.roomId;rocketState.roundId=d.round_id||rocketState.roundId;rocketState.bet=Number(d.bet||rocketState.bet||0);if(d.started_at)rocketState.startedAt=Date.parse(d.started_at);const phase=d.status==='lost'?'crashed':(d.room_status||d.status||'running');if(phase!==rocketState.lastStatus||initial)renderRocket(d);if(phase==='running'){if(!rocketState.running)rocketRun();}else rocketStop();rocketState.lastStatus=phase;}
async function rocketStart(){const input=document.getElementById('rocketBet');const bet=Number(input?.value||0);try{input?.blur();if(document.activeElement&&typeof document.activeElement.blur==='function')document.activeElement.blur();}catch(e){}if(!Number.isFinite(bet)||bet<=0)return alert('Введите сумму ставки');rocketTargetChanged();if(rocketState.pendingBet>0||rocketState.roundId)return;const remaining=Math.max(0,rocketState.waitUntil?rocketState.waitUntil-Date.now():0);if(remaining>0){rocketState.pendingBet=bet;rocketState.launchPending=true;renderRocket({active:false,balance:document.getElementById('rocketBal')?.textContent?null:null,history:[],status:'waiting',countdown:remaining/1000});rocketStartWaitingLoop();return;}await rocketLaunchBet(bet);}
async function rocketLaunchBet(bet){if(rocketState.busy)return;rocketState.busy=true;try{const d=await api('/api/crash/start','POST',{bet});rocketState.roomId=d.room_id;rocketState.roundId=d.round_id;rocketState.bet=Number(d.bet);rocketState.pendingBet=0;rocketState.launchPending=false;rocketState.startedAt=Date.parse(d.started_at);rocketState.cashedOut=false;rocketState.autoTriggered=false;hdFx('click',14,.2);renderRocket({...d,active:true,status:'running'});rocketSyncAutoUI();rocketState.running=true;rocketRun();}catch(e){rocketState.pendingBet=0;rocketState.launchPending=false;renderRocket({active:false,balance:null,history:[],status:'waiting',countdown:0});alert(e.message)}finally{rocketState.busy=false;}}
function rocketSetMultiplier(m){const n=Number(m||1);rocketState.lastMultiplier=n;const e=document.getElementById('rocketMult');if(e)e.textContent=n.toFixed(2)+'×';const cash=document.getElementById('rocketCash');if(cash&&!rocketState.cashedOut)cash.textContent='ЗАБРАТЬ · ×'+n.toFixed(2);}
function rocketStop(){if(rocketState.timer){cancelAnimationFrame(rocketState.timer);rocketState.timer=null;}if(rocketState.stateTimer){clearInterval(rocketState.stateTimer);rocketState.stateTimer=null;}rocketState.running=false;}
function rocketRun(){if(rocketState.timer)cancelAnimationFrame(rocketState.timer);if(rocketState.stateTimer)clearInterval(rocketState.stateTimer);rocketState.running=true;const tick=()=>{if(!rocketState.running)return;const m=Math.exp(.22*Math.max(0,(Date.now()-rocketState.startedAt)/1000));rocketSetMultiplier(m);if(rocketState.autoCashout&&!rocketState.autoTriggered&&!rocketState.cashedOut&&m>=rocketState.autoTarget){rocketState.autoTriggered=true;rocketCashout(true);return;}rocketState.timer=requestAnimationFrame(tick);};rocketState.timer=requestAnimationFrame(tick);rocketState.stateTimer=setInterval(rocketPollOnce,250);}
async function rocketPollOnce(){if(!document.getElementById('rocketWrap'))return;try{const d=await api('/api/crash/state');if(d.balance!=null){const b=document.getElementById('rocketBal');if(b)b.textContent=money(d.balance);}if(d.active===false){rocketStop();rocketState.roundId=null;rocketState.bet=0;rocketState.cashedOut=false;if(!rocketState.waitUntil||rocketState.waitUntil<Date.now())rocketState.waitUntil=Date.now()+10000;renderRocket({...d,status:'waiting',countdown:Math.max(0,(rocketState.waitUntil-Date.now())/1000)});rocketStartWaitingLoop();return;}const phase=d.status==='lost'?'crashed':(d.room_status||d.status||'running');rocketState.roomId=d.room_id||rocketState.roomId;rocketState.roundId=d.round_id||rocketState.roundId;if(d.started_at)rocketState.startedAt=Date.parse(d.started_at);if(phase==='running'){rocketState.lastStatus='running';if(!rocketState.running){renderRocket(d);rocketState.running=true;rocketRun();}else rocketSetMultiplier(Number(d.multiplier||rocketState.lastMultiplier||1));}else if(phase==='crashed'){rocketStop();rocketState.lastStatus='crashed';renderRocket(d);rocketExplode();rocketState.waitUntil=Date.now()+10000;setTimeout(()=>{if(document.getElementById('rocketWrap')){rocketState.waitUntil=Date.now()+10000;renderRocket({active:false,balance:d.balance,history:d.history||[],status:'waiting',countdown:10});rocketStartWaitingLoop();}},1400);}}catch(e){}}
function rocketStartWaitingLoop(){if(rocketState.stateTimer)clearInterval(rocketState.stateTimer);const tick=async()=>{if(!document.getElementById('rocketWrap')){clearInterval(rocketState.stateTimer);rocketState.stateTimer=null;return;}const sec=Math.max(0,(rocketState.waitUntil-Date.now())/1000);const n=document.getElementById('rocketWaitNumber');if(n)n.textContent=String(Math.ceil(sec));const bet=document.getElementById('rocketBet');const btn=document.querySelector('.rocket-start');if(bet)bet.disabled=false;if(btn&&!rocketState.pendingBet)btn.disabled=false;const st=document.querySelector('.rocket-status');if(st&&!rocketState.pendingBet)st.innerHTML=sec<=0?'Запуск ракеты…':`Следующий раунд через <b>${Math.ceil(sec)}с</b> · ставку можно сделать сейчас`;if(sec<=0){clearInterval(rocketState.stateTimer);rocketState.stateTimer=null;if(rocketState.pendingBet&&!rocketState.roundId){await rocketLaunchBet(rocketState.pendingBet);}else if(!rocketState.roundId){rocketState.waitUntil=0;renderRocket({active:false,balance:null,history:[],status:'waiting',countdown:0});}}};tick();rocketState.stateTimer=setInterval(tick,100);}
function rocketExplode(){const st=document.getElementById('rocketStage');if(!st||st.classList.contains('explode'))return;st.classList.add('explode');const ex=document.createElement('div');ex.className='rocket-explosion';st.appendChild(ex);setTimeout(()=>ex.remove(),800);}
async function rocketCashout(isAuto=false){if(!rocketState.roundId||rocketState.busy||rocketState.cashedOut)return;rocketState.busy=true;if(!isAuto)hdCashoutFx();try{const target=rocketState.autoCashout?rocketState.autoTarget:null;const d=await api('/api/crash/cashout','POST',{round_id:rocketState.roundId,target_multiplier:target});if(d.status==='lost'){rocketState.cashedOut=false;rocketStop();rocketState.roundId=null;rocketState.waitUntil=Date.now()+10000;renderRocket({...d,active:false,status:'waiting',countdown:10});rocketStartWaitingLoop();return;}if(d.status==='cashout'){rocketState.cashedOut=true;if(Number(d.payout)>0)rocketShowToast(d.payout);const cash=document.getElementById('rocketCash');if(cash)cash.disabled=true;const st=document.getElementById('rocketStatus');if(st)st.textContent=`Вы выиграли ${money(d.payout)} · ракета продолжает полёт`;if(isAuto)hdFx('cashout',20,.28);else hdGameWinFx();}}catch(e){rocketState.autoTriggered=false;const msg=String(e?.message||'');if(/заверш|finished|active/i.test(msg)){rocketState.roundId=null;rocketState.cashedOut=false;rocketStop();rocketState.waitUntil=Date.now()+10000;renderRocket({active:false,balance:null,history:[],status:'waiting',countdown:10});rocketStartWaitingLoop();}else alert(e.message)}finally{rocketState.busy=false;}}